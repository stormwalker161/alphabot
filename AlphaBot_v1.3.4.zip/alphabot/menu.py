"""AlphaBot GUI Menu Launcher - complete rewrite"""
import tkinter as tk
from tkinter import messagebox, scrolledtext, filedialog
import subprocess, threading, sys, os, json
from datetime import datetime

BG,PANEL,BORDER = "#0d1117","#161b22","#30363d"
GREEN,RED,YELLOW,BLUE = "#1D9E75","#D85A30","#EF9F27","#378ADD"
TEXT,MUTED = "#e6edf3","#8b949e"
FONT,FONT_SM,FONT_H = ("Consolas",10),("Consolas",9),("Consolas",11,"bold")


class AlphaBotLauncher:
    def __init__(self, root):
        self.root = root
        self.root.title("AlphaBot - AI Trading Bot")
        self.root.geometry("820x660")
        self.root.configure(bg=BG)
        self.root.resizable(True, True)
        self.root.minsize(700, 500)
        self.process = None
        self.running = False
        self._build_ui()
        self._load_status()
        self.root.protocol("WM_DELETE_WINDOW", self.quit_app)

    def _get_version(self):
        try:
            if os.path.exists("VERSION.json"):
                with open("VERSION.json") as f:
                    return json.load(f).get("version","1.0.0")
        except Exception:
            pass
        return "1.0.0"

    def _build_ui(self):
        hdr = tk.Frame(self.root, bg=BG, pady=10)
        hdr.pack(fill="x", padx=20)
        tk.Label(hdr, text="ALPHA", font=("Consolas",22,"bold"), fg=TEXT, bg=BG).pack(side="left")
        tk.Label(hdr, text="BOT",   font=("Consolas",22,"bold"), fg=GREEN, bg=BG).pack(side="left")
        tk.Label(hdr, text="  AI Trading System", font=("Consolas",11), fg=MUTED, bg=BG).pack(side="left", pady=4)
        tk.Label(hdr, text=f"v{self._get_version()}", font=("Consolas",9), fg=MUTED, bg=BG).pack(side="left", padx=8)
        self.mode_label = tk.Label(hdr, text="STOPPED", font=FONT, fg=RED, bg=BG)
        self.mode_label.pack(side="right")
        tk.Frame(self.root, bg=BORDER, height=1).pack(fill="x", padx=20)

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=20, pady=12)

        left = tk.Frame(body, bg=BG, width=225)
        left.pack(side="left", fill="y", padx=(0,12))
        left.pack_propagate(False)
        self._status_card(left)

        self._sec(left, "TRADING")
        self._btn(left, ">>  Start Paper Trading",   GREEN,  self.start_paper,  "Safe - no real money")
        self._btn(left, "!!  Start Live Trading",    RED,    self.start_live,   "Real money - confirm first")
        self._btn(left, "[]  Stop Bot",              BORDER, self.stop_bot,     "Stop the running bot")
        self.mode_btn = self._btn(left, "[M] Mode: CONSERVATIVE", BLUE, self.toggle_mode, "Switch trading aggressiveness")

        self._sec(left, "TOOLS")
        self._btn(left, "[B] Train ML Model",        BLUE,   self.train_model,  "Learn from historical data")
        self._btn(left, "[S] Scan for Stocks",       YELLOW, self.run_scan,     "Find new opportunities")
        self._btn(left, "[T] Run Backtest",          MUTED,  self.run_backtest, "Test strategy on 90 days")
        self._btn(left, "[?] Check Live Readiness",  MUTED,  self.check_readiness, "Ready for real money?")

        self._sec(left, "SETTINGS")
        self._btn(left, "[C] Edit Config",           MUTED,  self.edit_config,    "Add API keys, watchlist")
        self._btn(left, "[W] View Watchlist",        MUTED,  self.view_watchlist, "See tracked stocks")
        self._btn(left, "[H] View Trade History",    MUTED,  self.view_trades,    "See past trades")

        self._sec(left, "UPDATES")
        self._btn(left, "[U] Check for Updates",     GREEN,  self.check_for_updates,  "Download & install latest")
        self._btn(left, "[Z] Apply Update ZIP",      MUTED,  self.apply_update,       "Install update from local ZIP")
        self._btn(left, "[R] Restore Backup",        MUTED,  self.restore_backup_ui,  "Roll back to older version")

        tk.Frame(left, bg=BORDER, height=1).pack(fill="x", pady=8)
        self._btn(left, "[X] Close AlphaBot",        RED,    self.quit_app, "Stop bot and close")

        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)
        ch = tk.Frame(right, bg=BG)
        ch.pack(fill="x", pady=(0,6))
        tk.Label(ch, text="OUTPUT", font=FONT_H, fg=MUTED, bg=BG).pack(side="left")
        tk.Button(ch, text="Clear", font=FONT_SM, fg=MUTED, bg=PANEL, relief="flat",
                  activebackground=BORDER, command=self.clear_output, cursor="hand2").pack(side="right")
        self.console = scrolledtext.ScrolledText(
            right, font=FONT_SM, bg=PANEL, fg=TEXT, insertbackground=TEXT,
            relief="flat", borderwidth=1, highlightthickness=1,
            highlightbackground=BORDER, state="disabled", wrap="word")
        self.console.pack(fill="both", expand=True)
        for tag,col in [("green",GREEN),("red",RED),("yellow",YELLOW),("blue",BLUE),("muted",MUTED)]:
            self.console.tag_config(tag, foreground=col)

        bar = tk.Frame(self.root, bg=PANEL, pady=5)
        bar.pack(fill="x", side="bottom")
        self.statusbar = tk.Label(bar, text="Ready", font=FONT_SM, fg=MUTED, bg=PANEL)
        self.statusbar.pack(side="left", padx=16)
        tk.Label(bar, text="AlphaBot  |  Paper trading mode", font=FONT_SM, fg=MUTED, bg=PANEL).pack(side="right", padx=16)

    def _sec(self, parent, text):
        tk.Label(parent, text=text, font=("Consolas",8), fg=MUTED, bg=BG, anchor="w").pack(fill="x", pady=(10,2))

    def _btn(self, parent, text, color, command, tip=None):
        f = tk.Frame(parent, bg=BG)
        f.pack(fill="x", pady=2)
        tk.Frame(f, bg=color, width=3).pack(side="left", fill="y")
        b = tk.Button(f, text=text, font=FONT, fg=TEXT, bg=PANEL, relief="flat",
                      bd=0, anchor="w", padx=10, pady=6,
                      activebackground=BORDER, activeforeground=TEXT,
                      command=command, cursor="hand2")
        b.pack(side="left", fill="x", expand=True)
        if tip:
            b.bind("<Enter>", lambda e: self.statusbar.config(text=tip))
            b.bind("<Leave>", lambda e: self.statusbar.config(text="Ready"))

    def _status_card(self, parent):
        card = tk.Frame(parent, bg=PANEL, pady=8, padx=10,
                        highlightthickness=1, highlightbackground=BORDER)
        card.pack(fill="x", pady=(0,8))
        tk.Label(card, text="STATUS", font=("Consolas",8), fg=MUTED, bg=PANEL).pack(anchor="w")
        self.lbl_model    = tk.Label(card, text="ML Model: -",   font=FONT, fg=TEXT, bg=PANEL)
        self.lbl_positions= tk.Label(card, text="Positions: -",  font=FONT, fg=TEXT, bg=PANEL)
        self.lbl_trades   = tk.Label(card, text="Trades: -",     font=FONT, fg=TEXT, bg=PANEL)
        self.lbl_winrate  = tk.Label(card, text="Win rate: -",   font=FONT, fg=TEXT, bg=PANEL)
        for lbl in [self.lbl_model, self.lbl_positions, self.lbl_trades, self.lbl_winrate]:
            lbl.pack(anchor="w")
        tk.Button(card, text="Refresh", font=FONT_SM, fg=MUTED, bg=PANEL,
                  relief="flat", cursor="hand2", activebackground=BORDER,
                  command=self._load_status).pack(anchor="e", pady=(4,0))

    def _refresh_mode_btn(self):
        """Update mode button label to match config."""
        try:
            aggressive = self._is_aggressive()
            label = "[M] Mode: AGGRESSIVE" if aggressive else "[M] Mode: CONSERVATIVE"
            color = "#D85A30" if aggressive else "#378ADD"
            if hasattr(self, "mode_btn"):
                self.mode_btn.config(text=label, bg=color)
        except Exception:
            pass

    def _load_status(self):
        self._refresh_mode_btn()
        try:
            trained = os.path.exists("models/alphabot_model.pkl")
            self.lbl_model.config(text="ML Model: Trained" if trained else "ML Model: not trained",
                                  fg=GREEN if trained else YELLOW)
            if os.path.exists("trades/history.json"):
                with open("trades/history.json") as f:
                    h = json.load(f)
                closed = [t for t in h if t.get("status")=="closed"]
                wins   = [t for t in closed if t.get("return_pct",0)>0]
                wr     = len(wins)/len(closed) if closed else 0
                pnl    = sum(t.get("pnl",0) for t in closed)
                openp  = len([t for t in h if t.get("status")=="open"])
                self.lbl_positions.config(text=f"Positions: {openp} open")
                self.lbl_trades.config(text=f"Trades: {len(closed)}  ${pnl:+,.0f}")
                self.lbl_winrate.config(text=f"Win rate: {wr:.1%}",
                                        fg=GREEN if wr>=0.52 else (YELLOW if wr>=0.45 else RED))
            else:
                self.lbl_positions.config(text="Positions: none yet")
                self.lbl_trades.config(text="Trades: none yet")
        except Exception:
            pass
        self.root.after(30000, self._load_status)

    def log(self, text, tag=None):
        self.console.configure(state="normal")
        ts = datetime.now().strftime("%H:%M:%S")
        self.console.insert("end", f"[{ts}] ", "muted")
        self.console.insert("end", text+"\n", tag or "")
        self.console.see("end")
        self.console.configure(state="disabled")

    def clear_output(self):
        self.console.configure(state="normal")
        self.console.delete("1.0","end")
        self.console.configure(state="disabled")

    def _set_status(self, text, color=None):
        self.mode_label.config(text=text, fg=color or MUTED)

    def _python(self):
        p = os.path.join("venv","Scripts","python.exe")
        return p if os.path.exists(p) else sys.executable

    def _run_command(self, args, label="Running..."):
        if self.running:
            self.log("Another process is already running. Stop it first.", "yellow")
            return
        self.running = True
        self.log(f">> {label}", "green")
        self._set_status(f"● {label}", GREEN)
        def worker():
            try:
                self.process = subprocess.Popen(
                    [self._python()] + args,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, bufsize=1, encoding="utf-8", errors="replace",
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name=="nt" else 0)
                for line in self.process.stdout:
                    line = line.rstrip()
                    if not line: continue
                    tag = None
                    if any(w in line for w in ["ERROR","error","failed","FAIL"]): tag="red"
                    elif any(w in line for w in ["trained","success","PASS","OK"]): tag="green"
                    elif any(w in line for w in ["WARNING","warning"]): tag="yellow"
                    elif any(w in line for w in ["ADDED","REMOVED","Scanner"]): tag="blue"
                    self.root.after(0, self.log, line, tag)
                self.process.wait()
            except Exception as e:
                self.root.after(0, self.log, f"Error: {e}", "red")
            finally:
                self.running = False
                self.process = None
                self.root.after(0, self._set_status, "STOPPED", RED)
                self.root.after(0, self._load_status)
        threading.Thread(target=worker, daemon=True).start()

    def start_paper(self):
        self._run_command(["bot.py","--mode","paper"], "Paper trading (no real money)")

    def start_live(self):
        if messagebox.askyesno("WARNING - Real Money",
            "LIVE TRADING MODE\n\nThis will use REAL money.\n\n"
            "Only proceed if you have paper traded 30+ days and checked readiness.\n\nContinue?",
            icon="warning"):
            self._run_command(["bot.py","--mode","live"], "LIVE trading - real money")

    def stop_bot(self):
        if self.process:
            self.process.terminate()
            self.running = False
            self.log("Bot stopped.", "yellow")
            self._set_status("STOPPED", RED)
        else:
            self.log("No bot is currently running.", "muted")

    def train_model(self):
        if self.running:
            self.log("Stop the bot before retraining.", "yellow"); return
        self.log("Training ML model - fetching data from Yahoo Finance...", "blue")
        self._run_command(["bot.py","--mode","paper","--retrain","--backtest"], "Training ML model...")

    def run_scan(self):
        if self.running:
            self.log("Stop the bot before scanning.", "yellow"); return
        self.log("Scanning 100+ stocks...", "blue")
        def worker():
            try:
                self.running = True
                self._set_status("Scanning...", YELLOW)
                proc = subprocess.Popen(
                    [self._python(),"bot.py","--scan"],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    stdin=subprocess.PIPE, text=True, bufsize=1, encoding="utf-8", errors="replace",
                    creationflags=subprocess.CREATE_NO_WINDOW if os.name=="nt" else 0)
                try:
                    proc.stdin.write("y\n"); proc.stdin.flush()
                except Exception: pass
                for line in proc.stdout:
                    line = line.rstrip()
                    if not line: continue
                    tag = "blue" if any(w in line for w in ["ADDED","REMOVED"]) else None
                    self.root.after(0, self.log, line, tag)
                proc.wait()
            except Exception as e:
                self.root.after(0, self.log, f"Scan error: {e}", "red")
            finally:
                self.running = False
                self.root.after(0, self._set_status, "STOPPED", RED)
                self.root.after(0, self._load_status)
        threading.Thread(target=worker, daemon=True).start()

    def run_backtest(self):
        if self.running:
            self.log("Stop the bot first.", "yellow"); return
        self.log("Running 90-day backtest...", "blue")
        self._run_command(["bot.py","--backtest","--backtest-days","90"], "Running backtest...")

    def check_readiness(self):
        if self.running:
            self.log("Stop the bot first.", "yellow"); return
        try:
            if not os.path.exists("trades/history.json"):
                self.log("No trade history yet. Run paper trading first.", "yellow"); return
            with open("trades/history.json") as f:
                h = json.load(f)
            closed = [t for t in h if t.get("status")=="closed"]
            if not closed:
                self.log("No closed trades yet. Keep paper trading!", "yellow"); return
            import numpy as np
            returns = [t.get("return_pct",0) for t in closed]
            wr = len([r for r in returns if r>0])/len(returns)
            arr = np.array(returns)
            sharpe = float((arr.mean()/(arr.std()+1e-9))*(252**0.5)) if len(arr)>1 else 0
            try:
                days = (datetime.now()-datetime.fromisoformat(closed[0].get("timestamp",""))).days
            except Exception:
                days = 0
            self.log("-"*42)
            self.log("  LIVE TRADING READINESS")
            self.log("-"*42)
            self.log(f"  Days trading:  {days}  (need 30+)",  "green" if days>=30 else "red")
            self.log(f"  Total trades:  {len(closed)}  (need 50+)", "green" if len(closed)>=50 else "red")
            self.log(f"  Win rate:      {wr:.1%}  (need 52%+)", "green" if wr>=0.52 else "red")
            self.log(f"  Sharpe:        {sharpe:.2f}  (need 1.0+)", "green" if sharpe>=1.0 else "red")
            self.log("-"*42)
            checks = [days>=30, len(closed)>=50, wr>=0.52, sharpe>=1.0]
            self.log("  READY for live trading!" if all(checks) else f"  NOT ready - {sum(1 for c in checks if not c)} criteria unmet",
                     "green" if all(checks) else "red")
        except Exception as e:
            self.log(f"Error: {e}", "red")

    def edit_config(self):
        if not os.path.exists("config.json"):
            self.log("config.json not found.", "red"); return
        subprocess.Popen(["notepad.exe","config.json"])

    def view_watchlist(self):
        try:
            with open("config.json") as f:
                wl = json.load(f).get("watchlist",[])
            self.log(f"--- WATCHLIST ({len(wl)} stocks) ---")
            row = ""
            for i,s in enumerate(wl):
                row += f"  {s:<8}"
                if (i+1)%5==0: self.log(row); row=""
            if row: self.log(row)
        except Exception as e:
            self.log(f"Error: {e}", "red")

    def view_trades(self):
        try:
            if not os.path.exists("trades/history.json"):
                self.log("No trade history yet.", "yellow"); return
            with open("trades/history.json") as f:
                h = json.load(f)
            closed = [t for t in h if t.get("status")=="closed"]
            openp  = [t for t in h if t.get("status")=="open"]
            self.log(f"--- TRADE HISTORY  ({len(closed)} closed, {len(openp)} open) ---")
            self.log(f"  {'Symbol':<8} {'Side':<6} {'Entry':>8} {'Exit':>8} {'Ret':>7} {'PnL':>9}")
            for t in closed[-20:]:
                ret = t.get("return_pct",0)*100
                pnl = t.get("pnl",0)
                self.log(f"  {t.get('symbol',''):<8} {t.get('side',''):<6} "
                         f"${t.get('entry_price',0):>7.2f} ${t.get('exit_price',0):>7.2f} "
                         f"{ret:>+6.1f}% ${pnl:>+8.2f}", "green" if pnl>0 else "red")
            total = sum(t.get("pnl",0) for t in closed)
            self.log(f"  Total PnL: ${total:+,.2f}", "green" if total>=0 else "red")
        except Exception as e:
            self.log(f"Error: {e}", "red")

    def _is_aggressive(self):
        try:
            with open("config.json") as f:
                import json
                cfg = json.load(f)
            return cfg.get("aggressive_mode", {}).get("enabled", False)
        except Exception:
            return False

    def toggle_mode(self):
        try:
            from core.config import Config
            cfg = Config("config.json")
            current = cfg.get("aggressive_mode.enabled", False)
            cfg.set("aggressive_mode.enabled", not current)
            new_mode = "AGGRESSIVE" if not current else "CONSERVATIVE"
            label = f"[M] Mode: {new_mode}"
            color = "#D85A30" if not current else "#378ADD"
            self.mode_btn.config(text=label, bg=color)
            self.log(f"Switched to {new_mode} mode. Restart bot to apply.", "yellow")
            if not current:
                self.log("  AGGRESSIVE: confidence 55%, take profit 5%, 12 max positions", "yellow")
            else:
                self.log("  CONSERVATIVE: confidence 62%, take profit 10%, 8 max positions", "yellow")
        except Exception as e:
            self.log(f"Could not toggle mode: {e}", "red")

    def check_for_updates(self):
        self.log("Checking for updates...", "yellow")
        def worker():
            try:
                from core.updater import check_for_update, download_and_apply_update
                available, manifest, msg = check_for_update()
                self.root.after(0, self.log, msg, "green" if available else "muted")
                if not available:
                    return
                # Ask user
                if not messagebox.askyesno("Update Available",
                    f"{msg}\n\nDownload and install now?\n"
                    "A backup will be created. config.json and trades will NOT be touched."):
                    self.root.after(0, self.log, "Update skipped.", "muted")
                    return
                # Stop bot if running
                if self.running and self.process:
                    self.root.after(0, self.log, "Stopping bot before update...", "yellow")
                    self.process.terminate()
                    self.process = None
                    self.running = False
                def progress(msg):
                    self.root.after(0, self.log, msg, "yellow")
                success, result_msg = download_and_apply_update(manifest, progress_callback=progress)
                for line in result_msg.split("\n"):
                    if line.strip():
                        self.root.after(0, self.log, line.strip(), "green" if success else "red")
                if success:
                    self.root.after(0, self.log, "Update applied - restarting now...", "green")
                    self.root.after(1500, self._restart_app)
                else:
                    self.root.after(0, messagebox.showerror, "Update Failed", result_msg)
            except Exception as e:
                self.root.after(0, self.log, f"Update error: {e}", "red")
        threading.Thread(target=worker, daemon=True).start()

    def apply_update(self):
        zip_path = filedialog.askopenfilename(
            title="Select AlphaBot update ZIP",
            filetypes=[("ZIP files","*.zip"),("All files","*.*")])
        if not zip_path:
            self.log("Update cancelled.", "muted"); return
        if not messagebox.askyesno("Apply Update",
            f"Apply update from:\n{os.path.basename(zip_path)}\n\n"
            "A backup will be created first.\nconfig.json, trades, and models will NOT be touched.\n\nContinue?"):
            self.log("Update cancelled.", "muted"); return

        # Stop the bot if it's running before we overwrite files
        if self.running and self.process:
            self.log("Stopping bot before update...", "yellow")
            self.process.terminate()
            self.process = None
            self.running = False

        self.log(f"Applying update: {os.path.basename(zip_path)}", "yellow")

        def worker():
            try:
                from core.updater import apply_zip_update
                success, msg = apply_zip_update(zip_path)
                for line in msg.split("\n"):
                    if line.strip():
                        self.root.after(0, self.log, line.strip(), "green" if success else "red")
                if success:
                    self.root.after(0, self.log, "✓ Update applied — restarting AlphaBot now...", "green")
                    self.root.after(1500, self._restart_app)
                else:
                    self.root.after(0, messagebox.showerror, "Update Failed", msg)
            except Exception as e:
                self.root.after(0, self.log, f"Update error: {e}", "red")
        threading.Thread(target=worker, daemon=True).start()

    def _restart_app(self):
        """Launch a fresh copy of menu.py then close this one."""
        try:
            python = self._python()
            script = os.path.abspath("menu.py")
            # On Windows use CREATE_NEW_CONSOLE so the new window is independent
            flags = subprocess.CREATE_NEW_CONSOLE if os.name == "nt" else 0
            subprocess.Popen([python, script],
                             creationflags=flags,
                             cwd=os.path.dirname(script) or ".")
        except Exception as e:
            messagebox.showerror("Restart Failed",
                f"Could not restart automatically:\n{e}\n\nPlease close and reopen AlphaBot manually.")
            return
        self.root.destroy()

    def restore_backup_ui(self):
        try:
            from core.updater import list_backups, restore_backup
        except ImportError:
            self.log("Updater module not found.", "red"); return
        backups = list_backups()
        if not backups:
            messagebox.showinfo("No Backups",
                "No backups found yet.\nBackups are created automatically when you apply updates.")
            return
        win = tk.Toplevel(self.root)
        win.title("Restore Backup")
        win.geometry("480x300")
        win.configure(bg=BG)
        win.grab_set()
        tk.Label(win, text="Select backup to restore:", font=FONT_H, fg=TEXT, bg=BG).pack(padx=16,pady=(16,8),anchor="w")
        lb = tk.Listbox(win, font=FONT_SM, bg=PANEL, fg=TEXT,
                        selectbackground=GREEN, relief="flat",
                        highlightthickness=1, highlightbackground=BORDER)
        lb.pack(fill="both", expand=True, padx=16)
        for b in backups:
            lb.insert("end", f"  {b['date']}  ({b['size_kb']} KB)")
        lb.selection_set(0)
        def do_restore():
            idx = lb.curselection()
            if not idx: return
            b = backups[idx[0]]
            if messagebox.askyesno("Confirm Restore",
                f"Restore from:\n{b['file']}\n\nconfig.json and trades will be preserved.\n\nContinue?"):
                ok, msg = restore_backup(b["path"])
                win.destroy()
                self.log(msg, "green" if ok else "red")
                if ok: messagebox.showinfo("Restored", f"{msg}\n\nPlease restart AlphaBot.")
        bf = tk.Frame(win, bg=BG)
        bf.pack(fill="x", padx=16, pady=12)
        tk.Button(bf, text="Restore Selected", font=FONT, fg=TEXT, bg=GREEN, relief="flat",
                  padx=12, pady=6, cursor="hand2", command=do_restore).pack(side="left")
        tk.Button(bf, text="Cancel", font=FONT, fg=MUTED, bg=PANEL, relief="flat",
                  padx=12, pady=6, cursor="hand2", command=win.destroy).pack(side="left", padx=8)

    def quit_app(self):
        if self.running and self.process:
            if not messagebox.askyesno("Bot is running",
                "The bot is currently running.\n\nStop it and close AlphaBot?"):
                return
            self.stop_bot()
        self.root.after(400, self.root.destroy)


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    root = tk.Tk()
    app = AlphaBotLauncher(root)
    app.log("Welcome to AlphaBot!", "green")
    app.log("-"*45, "muted")
    app.log("  1. Edit Config -> add your Alpaca API keys", "muted")
    app.log("  2. Train ML Model -> learn from data", "muted")
    app.log("  3. Scan for Stocks -> find opportunities", "muted")
    app.log("  4. Start Paper Trading -> run safely first", "muted")
    app.log("  5. After 30+ days check Live Readiness", "muted")
    app.log("-"*45, "muted")
    root.mainloop()

if __name__ == "__main__":
    main()
