"""
AlphaBot Intelligence Orchestrator
==================================
A single facade that wires the four signal layers together so engine.py
only needs one object and one call to factor every intelligence source
into its trade decisions:

    macro     -> core/macro_intelligence.py        (rate regime, calendar)
    earnings  -> core/earnings_intelligence.py     (earnings risk + filings)
    sentiment -> core/sentiment_engine.py          (news + reddit)
    (ml is already wired directly in engine.py via ml_engine.predict)

Usage in engine.py:

    from core.intelligence import IntelligenceHub

    self.intel = IntelligenceHub(config, watchlist=self.watchlist)
    self.intel.start()
    ...
    # in execute_signals(), after risk_manager.get_position_size:
    shares = self.intel.adjust_position_size(shares, symbol)
    if shares < 1:
        continue
    ...
    # in scan_for_signals():
    threshold = self.ml_engine.confidence_threshold + self.intel.confidence_adjustment()
    ...
    # in shutdown():
    self.intel.stop()

Every layer is independently optional and degrades gracefully if its
dependencies are missing or its data sources are unreachable.
"""

import logging
from datetime import datetime

logger = logging.getLogger("alphabot.intelligence")

# All three layers live in core/. They are intentionally optional - if any one
# fails to import, the hub still works using whichever layers are available.
try:
    from core.macro_intelligence import MacroIntelligence
    HAS_MACRO = True
except Exception as e:
    HAS_MACRO = False
    logger.warning(f"MacroIntelligence unavailable: {e}")

try:
    from core.earnings_intelligence import EarningsIntelligence
    HAS_EARNINGS = True
except Exception as e:
    HAS_EARNINGS = False
    logger.warning(f"EarningsIntelligence unavailable: {e}")

try:
    from core.sentiment_engine import CombinedIntelligence
    HAS_SENTIMENT = True
except Exception as e:
    HAS_SENTIMENT = False
    logger.warning(f"Sentiment engine unavailable: {e}")


class IntelligenceHub:
    """
    Single point of contact for engine.py to get a holistic position-size
    and confidence adjustment across all intelligence layers.

    Order of operations in adjust_position_size:
        1. Macro veto + size cut       (RISK_OFF can zero out high-beta names)
        2. Earnings veto + size cut    (in-window or fresh filing)
        3. Sentiment skew              (strong bearish -50%, strong bullish +10%)
    Each step operates on the *output* of the previous step, so vetoes
    cascade naturally.
    """

    def __init__(self, config, watchlist=None):
        self.config = config
        self.watchlist = list(watchlist) if watchlist else (
            config.get("watchlist", []) if config else []
        )

        self.macro     = MacroIntelligence(config) if HAS_MACRO else None
        self.earnings  = (EarningsIntelligence(config, watchlist=self.watchlist)
                          if HAS_EARNINGS else None)

        # Sentiment engine has a different constructor signature
        self.sentiment = None
        if HAS_SENTIMENT:
            try:
                # CombinedIntelligence takes (config) and uses watch_tickers()
                self.sentiment = CombinedIntelligence(config=config)
                if self.watchlist:
                    self.sentiment.watch_tickers(self.watchlist)
            except Exception as e:
                logger.warning(f"Could not init sentiment engine: {e}")

    # -----------------------------------------------------------------------
    # Lifecycle
    # -----------------------------------------------------------------------
    def start(self):
        if self.macro:
            try:
                self.macro.start()
            except Exception as e:
                logger.error(f"macro.start failed: {e}")
        if self.earnings:
            try:
                self.earnings.start()
            except Exception as e:
                logger.error(f"earnings.start failed: {e}")
        if self.sentiment:
            try:
                self.sentiment.start()
            except Exception as e:
                logger.error(f"sentiment.start failed: {e}")
        logger.info("IntelligenceHub started "
                    f"(macro={bool(self.macro)}, "
                    f"earnings={bool(self.earnings)}, "
                    f"sentiment={bool(self.sentiment)})")

    def stop(self):
        for layer in (self.macro, self.earnings, self.sentiment):
            if layer:
                try:
                    layer.stop()
                except Exception:
                    pass
        logger.info("IntelligenceHub stopped")

    def update_watchlist(self, watchlist):
        """Forward watchlist updates to layers that care."""
        self.watchlist = list(watchlist)
        if self.earnings and hasattr(self.earnings, "update_watchlist"):
            self.earnings.update_watchlist(watchlist)
        if self.sentiment and hasattr(self.sentiment, "watch_tickers"):
            try:
                self.sentiment.watch_tickers(watchlist)
            except Exception:
                pass

    # -----------------------------------------------------------------------
    # Sizing
    # -----------------------------------------------------------------------
    def adjust_position_size(self, base_shares, symbol, allow_earnings_play=False):
        """
        Cascade base_shares through every available intelligence layer.
        Returns the final integer share count (0 means do not trade).
        """
        if base_shares is None or base_shares <= 0:
            return 0

        shares = int(base_shares)

        # 1. Macro
        if self.macro:
            try:
                shares = self.macro.adjust_position_size(shares, symbol)
            except Exception as e:
                logger.warning(f"macro.adjust_position_size failed for {symbol}: {e}")
        if shares < 1:
            return 0

        # 2. Earnings
        if self.earnings:
            try:
                shares = self.earnings.adjust_position_size(
                    shares, symbol, allow_earnings_play=allow_earnings_play
                )
            except Exception as e:
                logger.warning(f"earnings.adjust_position_size failed for {symbol}: {e}")
        if shares < 1:
            return 0

        # 3. Sentiment
        if self.sentiment:
            try:
                score = self.sentiment.get_combined_score(symbol)
                signal = (score or {}).get("combined_signal", "neutral")
                if signal == "bearish":
                    new_shares = int(shares * 0.5)
                    logger.info(f"Sentiment drag: {symbol} bearish, "
                                f"sized {shares} -> {new_shares}")
                    shares = new_shares
                elif signal == "bullish":
                    new_shares = int(shares * 1.1)
                    if new_shares != shares:
                        logger.info(f"Sentiment tailwind: {symbol} bullish, "
                                    f"sized {shares} -> {new_shares}")
                    shares = new_shares
                # 'momentum_spike' and 'neutral' -> no change
            except Exception as e:
                logger.debug(f"sentiment lookup failed for {symbol}: {e}")

        return max(0, int(shares))

    # -----------------------------------------------------------------------
    # Confidence threshold
    # -----------------------------------------------------------------------
    def confidence_adjustment(self):
        """
        Aggregate confidence-threshold delta. The engine adds this to its
        ML confidence_threshold. RISK_OFF makes us pickier; RISK_ON loosens.
        """
        delta = 0.0
        if self.macro:
            try:
                delta += self.macro.get_confidence_adjustment()
            except Exception:
                pass
        return delta

    # -----------------------------------------------------------------------
    # Status snapshots (for the menu UI)
    # -----------------------------------------------------------------------
    def get_status(self):
        """Single dict summarizing every layer for display."""
        out = {
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "macro": None,
            "earnings": None,
            "sentiment": None,
        }
        if self.macro:
            try:
                out["macro"] = self.macro.get_macro_context()
            except Exception as e:
                out["macro"] = {"error": str(e)}
        if self.earnings:
            try:
                out["earnings"] = self.earnings.get_summary()
            except Exception as e:
                out["earnings"] = {"error": str(e)}
        if self.sentiment:
            try:
                # CombinedIntelligence exposes news.get_market_sentiment()
                if hasattr(self.sentiment, "news"):
                    out["sentiment"] = self.sentiment.news.get_market_sentiment()
                else:
                    out["sentiment"] = {"status": "running"}
            except Exception as e:
                out["sentiment"] = {"error": str(e)}
        return out
