"""
EarningsIntelligence - Earnings risk + post-earnings signal layer for AlphaBot
==============================================================================
Detects upcoming and recent earnings events for every ticker in the watchlist
and exposes a clean per-ticker status the trading engine can query.

Three concerns, one module:

  1. Earnings calendar - pulls next-earnings-date for every watched ticker via
     yfinance (free, no key). Anything within 3 days is flagged as
     "earnings_risk" so the engine can shrink or skip those positions.

  2. Post-earnings surprise - after a release, computes EPS surprise vs
     consensus and assigns one of:
        BEAT_STRONG, BEAT_MILD, NEUTRAL, MISS_MILD, MISS_STRONG

  3. SEC EDGAR filings - polls EDGAR's free JSON API for new 8-K (material
     events), 10-Q, and 10-K filings and raises a filing_flag for ~24 hours
     after a fresh filing appears.

Refreshes earnings calendar every 6 hours, EDGAR every 30 minutes.
Pure stdlib + yfinance + requests. No API keys. Windows-safe. Background thread.
"""

import os
import json
import time
import logging
import threading
import urllib.request
import urllib.error
from datetime import datetime, timedelta, date
from collections import defaultdict

logger = logging.getLogger("alphabot.earnings")

# Optional dep - same graceful-degrade pattern the rest of AlphaBot uses
try:
    import yfinance as yf
    HAS_YF = True
except ImportError:
    HAS_YF = False
    logger.warning("yfinance not installed - earnings calendar disabled")

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
CACHE_FILE = "models/earnings_cache.json"

CALENDAR_REFRESH_HOURS = 6     # earnings dates rarely change
EDGAR_REFRESH_MINUTES  = 30    # 8-Ks can land any time during trading hours
HTTP_TIMEOUT = 12
MAX_RETRIES = 3
RETRY_BACKOFF_SEC = 2

EARNINGS_RISK_DAYS = 3         # within 3 calendar days = risk window
FILING_FLAG_HOURS  = 24        # how long a fresh 8-K stays "hot"

# SEC EDGAR endpoints (free, no key, but they require a real User-Agent)
EDGAR_TICKER_MAP = "https://www.sec.gov/files/company_tickers.json"
EDGAR_SUBMISSIONS = "https://data.sec.gov/submissions/CIK{cik}.json"

# SEC requires a contact-style UA. Edit this to your real contact if you want
# to be a good citizen, but the format below is what the SEC asks for.
SEC_USER_AGENT = "AlphaBot Research stormwalker161@gmail.com"

# Surprise thresholds (percent vs consensus)
STRONG_BEAT_PCT = 10.0   # >= +10% = BEAT_STRONG
MILD_BEAT_PCT   = 2.0    # >= +2%  = BEAT_MILD
MILD_MISS_PCT   = -2.0   # <= -2%  = MISS_MILD
STRONG_MISS_PCT = -10.0  # <= -10% = MISS_STRONG

# Filing types we care about
WATCHED_FILING_TYPES = {"8-K", "10-Q", "10-K"}


# ---------------------------------------------------------------------------
# EarningsIntelligence
# ---------------------------------------------------------------------------
class EarningsIntelligence:
    """
    Background earnings + filings monitor.

    Usage:
        ei = EarningsIntelligence(config, watchlist=["AAPL","MSFT",...])
        ei.start()
        status = ei.get_earnings_status("AAPL")
        if status["earnings_risk"]:
            shares = int(shares * 0.5)   # or skip entirely
    """

    def __init__(self, config=None, watchlist=None):
        self.config = config
        # Watchlist can be passed in directly or pulled from config
        self.watchlist = list(watchlist) if watchlist else (
            config.get("watchlist", []) if config else []
        )

        self._lock = threading.Lock()
        self._thread = None
        self._running = False

        # Per-ticker state.
        # earnings[ticker] = {
        #   "next_earnings_date":   "YYYY-MM-DD" or None,
        #   "last_earnings_date":   "YYYY-MM-DD" or None,
        #   "last_eps_actual":      float or None,
        #   "last_eps_estimate":    float or None,
        #   "last_eps_surprise_pct":float or None,
        #   "signal":               "BEAT_STRONG"|...|"NEUTRAL"|"UNKNOWN",
        # }
        self.earnings = defaultdict(dict)

        # filings[ticker] = {"last_filing": {...}, "flag_until": "ISO"}
        self.filings = defaultdict(dict)

        # Ticker -> CIK lookup (cached after first fetch)
        self.cik_map = {}

        self.last_calendar_refresh = None
        self.last_edgar_refresh = None

        os.makedirs("models", exist_ok=True)
        self._load_cache()

    # -----------------------------------------------------------------------
    # Persistence
    # -----------------------------------------------------------------------
    def _load_cache(self):
        if not os.path.exists(CACHE_FILE):
            return
        try:
            with open(CACHE_FILE, "r") as f:
                data = json.load(f)
            self.earnings = defaultdict(dict, data.get("earnings", {}))
            self.filings  = defaultdict(dict, data.get("filings", {}))
            self.cik_map  = data.get("cik_map", {})
            cal_ts = data.get("last_calendar_refresh")
            edg_ts = data.get("last_edgar_refresh")
            if cal_ts:
                self.last_calendar_refresh = datetime.fromisoformat(cal_ts)
            if edg_ts:
                self.last_edgar_refresh = datetime.fromisoformat(edg_ts)
            logger.info(f"Loaded earnings cache: {len(self.earnings)} tickers, "
                        f"{len(self.filings)} with filings")
        except Exception as e:
            logger.warning(f"Could not load earnings cache: {e}")

    def _save_cache(self):
        try:
            data = {
                "earnings": dict(self.earnings),
                "filings":  dict(self.filings),
                "cik_map":  self.cik_map,
                "last_calendar_refresh": (
                    self.last_calendar_refresh.isoformat() if self.last_calendar_refresh else None
                ),
                "last_edgar_refresh": (
                    self.last_edgar_refresh.isoformat() if self.last_edgar_refresh else None
                ),
            }
            with open(CACHE_FILE, "w") as f:
                json.dump(data, f, indent=2, default=str)
        except Exception as e:
            logger.warning(f"Could not save earnings cache: {e}")

    # -----------------------------------------------------------------------
    # HTTP helper with retry / backoff
    # -----------------------------------------------------------------------
    def _http_get(self, url, headers=None, timeout=HTTP_TIMEOUT, retries=MAX_RETRIES):
        """GET with exponential backoff. Returns body string or None."""
        hdrs = {"User-Agent": SEC_USER_AGENT, "Accept": "application/json"}
        if headers:
            hdrs.update(headers)

        for attempt in range(retries):
            try:
                req = urllib.request.Request(url, headers=hdrs)
                with urllib.request.urlopen(req, timeout=timeout) as resp:
                    return resp.read().decode("utf-8", errors="replace")
            except urllib.error.HTTPError as e:
                # 429 / 5xx - retryable. 4xx other - give up.
                if e.code in (429, 500, 502, 503, 504) and attempt < retries - 1:
                    wait = RETRY_BACKOFF_SEC * (2 ** attempt)
                    logger.info(f"HTTP {e.code} on {url}, retrying in {wait}s")
                    time.sleep(wait)
                    continue
                logger.warning(f"HTTP {e.code} on {url}: {e.reason}")
                return None
            except urllib.error.URLError as e:
                if attempt < retries - 1:
                    time.sleep(RETRY_BACKOFF_SEC * (2 ** attempt))
                    continue
                logger.warning(f"HTTP error on {url}: {e.reason}")
                return None
            except Exception as e:
                logger.warning(f"HTTP unexpected error on {url}: {e}")
                return None
        return None

    # -----------------------------------------------------------------------
    # Earnings calendar (yfinance)
    # -----------------------------------------------------------------------
    def _safe_float(self, v):
        try:
            if v is None:
                return None
            f = float(v)
            if f != f:  # NaN
                return None
            return f
        except (TypeError, ValueError):
            return None

    def _fetch_earnings_for_ticker(self, ticker):
        """
        Pull next earnings date and last earnings surprise from yfinance.
        Returns dict (possibly partial) or None on failure.
        """
        if not HAS_YF:
            return None

        result = {}
        try:
            t = yf.Ticker(ticker)

            # --- next earnings date ---
            # yfinance exposes this in a couple of inconsistent shapes
            # depending on version. Try both, swallow exceptions.
            next_date = None
            try:
                cal = t.calendar
                if isinstance(cal, dict):
                    ed = cal.get("Earnings Date")
                    if ed:
                        if isinstance(ed, (list, tuple)) and ed:
                            next_date = ed[0]
                        else:
                            next_date = ed
                elif HAS_PANDAS and hasattr(cal, "loc"):
                    # Older yfinance returned a DataFrame
                    try:
                        next_date = cal.loc["Earnings Date"].iloc[0]
                    except Exception:
                        pass
            except Exception:
                pass

            if next_date is not None:
                try:
                    if hasattr(next_date, "strftime"):
                        result["next_earnings_date"] = next_date.strftime("%Y-%m-%d")
                    else:
                        result["next_earnings_date"] = str(next_date)[:10]
                except Exception:
                    pass

            # --- last earnings surprise ---
            # earnings_dates returns a DataFrame with EPS Estimate /
            # Reported EPS / Surprise(%)
            try:
                edf = t.earnings_dates
                if HAS_PANDAS and edf is not None and not edf.empty:
                    now = datetime.now()
                    # Drop tz-info for comparison
                    try:
                        idx = edf.index.tz_localize(None) if edf.index.tz is not None else edf.index
                    except Exception:
                        idx = edf.index

                    # Most recent date that's already passed
                    past = [(i, d) for i, d in enumerate(idx) if d <= now]
                    if past:
                        last_idx, last_dt = past[-1]
                        row = edf.iloc[last_idx]

                        result["last_earnings_date"] = last_dt.strftime("%Y-%m-%d")

                        eps_est      = self._safe_float(row.get("EPS Estimate"))
                        eps_act      = self._safe_float(row.get("Reported EPS"))
                        surprise_pct = self._safe_float(row.get("Surprise(%)"))

                        if eps_est is not None:
                            result["last_eps_estimate"] = eps_est
                        if eps_act is not None:
                            result["last_eps_actual"] = eps_act

                        # Use yfinance's surprise % if present, else compute
                        if surprise_pct is not None:
                            result["last_eps_surprise_pct"] = round(surprise_pct, 2)
                        elif eps_est not in (None, 0) and eps_act is not None:
                            pct = (eps_act - eps_est) / abs(eps_est) * 100
                            result["last_eps_surprise_pct"] = round(pct, 2)
            except Exception as e:
                logger.debug(f"{ticker}: earnings_dates lookup failed: {e}")

            return result if result else None

        except Exception as e:
            logger.debug(f"yfinance fetch failed for {ticker}: {e}")
            return None

    def _classify_signal(self, eps_surprise_pct):
        """Map an EPS surprise % to one of the named signal buckets."""
        if eps_surprise_pct is None:
            return "UNKNOWN"
        if eps_surprise_pct >= STRONG_BEAT_PCT:
            return "BEAT_STRONG"
        if eps_surprise_pct >= MILD_BEAT_PCT:
            return "BEAT_MILD"
        if eps_surprise_pct <= STRONG_MISS_PCT:
            return "MISS_STRONG"
        if eps_surprise_pct <= MILD_MISS_PCT:
            return "MISS_MILD"
        return "NEUTRAL"

    def refresh_calendar(self):
        """Refresh earnings calendar for every ticker in the watchlist."""
        if not HAS_YF:
            logger.warning("Cannot refresh earnings calendar - yfinance not installed")
            return
        if not self.watchlist:
            logger.info("Earnings refresh: empty watchlist, nothing to do")
            return

        logger.info(f"Refreshing earnings calendar for {len(self.watchlist)} tickers...")
        updated = 0
        with_next = 0

        for i, ticker in enumerate(self.watchlist):
            if not self._running and self._thread is not None:
                # Allow fast shutdown mid-loop
                break
            if i and i % 25 == 0:
                logger.info(f"  Earnings calendar progress: {i}/{len(self.watchlist)}")

            data = self._fetch_earnings_for_ticker(ticker)
            if not data:
                continue

            with self._lock:
                # Merge new fields without nuking existing ones
                self.earnings[ticker].update(data)
                if "last_eps_surprise_pct" in data:
                    self.earnings[ticker]["signal"] = self._classify_signal(
                        data["last_eps_surprise_pct"]
                    )
            if "next_earnings_date" in data:
                with_next += 1
            updated += 1

            # Be polite to Yahoo - small delay between calls
            time.sleep(0.15)

        self.last_calendar_refresh = datetime.now()
        self._save_cache()
        logger.info(f"Earnings calendar refresh complete: "
                    f"{updated}/{len(self.watchlist)} updated, "
                    f"{with_next} with next-earnings dates")

    # -----------------------------------------------------------------------
    # SEC EDGAR
    # -----------------------------------------------------------------------
    def _load_cik_map(self):
        """One-time fetch of SEC's full ticker -> CIK mapping."""
        if self.cik_map:
            return  # already loaded

        body = self._http_get(EDGAR_TICKER_MAP)
        if not body:
            logger.warning("Could not fetch SEC ticker->CIK map")
            return

        try:
            data = json.loads(body)
            # Format: {"0": {"cik_str": 320193, "ticker": "AAPL", "title": "..."}, ...}
            for entry in data.values():
                ticker = entry.get("ticker", "").upper()
                cik = entry.get("cik_str")
                if ticker and cik is not None:
                    # CIK must be zero-padded to 10 digits for the submissions endpoint
                    self.cik_map[ticker] = str(cik).zfill(10)
            logger.info(f"Loaded SEC CIK map: {len(self.cik_map)} tickers")
            self._save_cache()
        except Exception as e:
            logger.warning(f"Failed parsing SEC ticker map: {e}")

    def _fetch_recent_filings(self, ticker):
        """
        Fetch the most recent 8-K/10-Q/10-K filing for a ticker from EDGAR.
        Returns dict {form, filing_date, accession} or None.
        """
        cik = self.cik_map.get(ticker.upper())
        if not cik:
            return None

        url = EDGAR_SUBMISSIONS.format(cik=cik)
        body = self._http_get(url)
        if not body:
            return None

        try:
            data = json.loads(body)
            recent = data.get("filings", {}).get("recent", {})
            forms        = recent.get("form", [])
            filing_dates = recent.get("filingDate", [])
            accessions   = recent.get("accessionNumber", [])

            # Walk newest-first looking for the first matching form type
            for form, fdate, acc in zip(forms, filing_dates, accessions):
                if form in WATCHED_FILING_TYPES:
                    return {
                        "form": form,
                        "filing_date": fdate,
                        "accession": acc,
                    }
            return None
        except Exception as e:
            logger.debug(f"EDGAR parse failed for {ticker}: {e}")
            return None

    def refresh_edgar(self):
        """Check EDGAR for new 8-K/10-Q/10-K filings on watchlist tickers."""
        if not self.watchlist:
            return

        if not self.cik_map:
            self._load_cik_map()
        if not self.cik_map:
            logger.warning("EDGAR refresh skipped - no CIK map available")
            return

        logger.info(f"Checking EDGAR for new filings on {len(self.watchlist)} tickers...")
        new_filings = 0
        cutoff = datetime.now() - timedelta(hours=FILING_FLAG_HOURS)

        for i, ticker in enumerate(self.watchlist):
            if not self._running and self._thread is not None:
                break
            if ticker.upper() not in self.cik_map:
                continue

            filing = self._fetch_recent_filings(ticker)
            if not filing:
                continue

            try:
                fdate = datetime.strptime(filing["filing_date"], "%Y-%m-%d")
            except Exception:
                continue

            if fdate < cutoff:
                # Old news - clear any stale flag but remember the filing
                with self._lock:
                    self.filings[ticker] = {
                        "last_filing": filing,
                        "flag_until": None,
                    }
                continue

            # Fresh filing - flag for FILING_FLAG_HOURS from filing date
            flag_until = fdate + timedelta(hours=FILING_FLAG_HOURS)
            with self._lock:
                prev = self.filings.get(ticker, {}).get("last_filing", {}) or {}
                if prev.get("accession") != filing["accession"]:
                    new_filings += 1
                    logger.info(f"  NEW FILING: {ticker} {filing['form']} "
                                f"on {filing['filing_date']}")
                self.filings[ticker] = {
                    "last_filing": filing,
                    "flag_until": flag_until.isoformat(),
                }

            # SEC fair-use limit is 10 req/sec; we go much slower
            time.sleep(0.12)

        self.last_edgar_refresh = datetime.now()
        self._save_cache()
        logger.info(f"EDGAR refresh complete: {new_filings} new filings flagged")

    # -----------------------------------------------------------------------
    # Background loop
    # -----------------------------------------------------------------------
    def start(self):
        """Start background refresh thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._background_loop,
                                        daemon=True, name="EarningsIntelligence")
        self._thread.start()
        logger.info(f"EarningsIntelligence started "
                    f"(calendar={CALENDAR_REFRESH_HOURS}h, edgar={EDGAR_REFRESH_MINUTES}m)")

    def stop(self):
        self._running = False
        logger.info("EarningsIntelligence stopping")

    def _needs_calendar_refresh(self):
        if self.last_calendar_refresh is None:
            return True
        hours = (datetime.now() - self.last_calendar_refresh).total_seconds() / 3600
        return hours >= CALENDAR_REFRESH_HOURS

    def _needs_edgar_refresh(self):
        if self.last_edgar_refresh is None:
            return True
        mins = (datetime.now() - self.last_edgar_refresh).total_seconds() / 60
        return mins >= EDGAR_REFRESH_MINUTES

    def _background_loop(self):
        # Initial run on startup
        try:
            if self._needs_calendar_refresh():
                self.refresh_calendar()
        except Exception as e:
            logger.error(f"Initial earnings calendar refresh failed: {e}")
        try:
            if self._needs_edgar_refresh():
                self.refresh_edgar()
        except Exception as e:
            logger.error(f"Initial EDGAR refresh failed: {e}")

        # Poll every 5 minutes; each task self-checks its own interval
        while self._running:
            try:
                if self._needs_calendar_refresh():
                    self.refresh_calendar()
                if self._needs_edgar_refresh():
                    self.refresh_edgar()
            except Exception as e:
                logger.error(f"Earnings background error: {e}")

            for _ in range(5 * 60):
                if not self._running:
                    return
                time.sleep(1)

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------
    def update_watchlist(self, watchlist):
        """Swap in a new watchlist (e.g. after the auto-scanner runs)."""
        with self._lock:
            self.watchlist = list(watchlist)
        logger.info(f"Earnings watchlist updated: {len(self.watchlist)} tickers")

    def get_earnings_status(self, ticker):
        """
        Return the canonical per-ticker status dict expected by TradingEngine.

        Keys:
            ticker                 : str
            days_to_earnings       : int or None  (negative = already happened)
            next_earnings_date     : "YYYY-MM-DD" or None
            last_earnings_date     : "YYYY-MM-DD" or None
            last_eps_surprise_pct  : float or None
            signal                 : "BEAT_STRONG"|"BEAT_MILD"|"NEUTRAL"|
                                     "MISS_MILD"|"MISS_STRONG"|"UNKNOWN"
            filing_flag            : bool   (fresh 8-K/10-Q/10-K within 24h)
            last_filing            : dict or None
            earnings_risk          : bool   (within EARNINGS_RISK_DAYS)
        """
        ticker = ticker.upper()
        with self._lock:
            edata = dict(self.earnings.get(ticker, {}))
            fdata = dict(self.filings.get(ticker, {}))

        # Compute days_to_earnings
        days_to = None
        next_date = edata.get("next_earnings_date")
        if next_date:
            try:
                nd = datetime.strptime(next_date[:10], "%Y-%m-%d").date()
                days_to = (nd - date.today()).days
            except Exception:
                pass

        earnings_risk = (
            days_to is not None and 0 <= days_to <= EARNINGS_RISK_DAYS
        )

        # Compute filing flag
        filing_flag = False
        flag_until = fdata.get("flag_until")
        if flag_until:
            try:
                if datetime.fromisoformat(flag_until) > datetime.now():
                    filing_flag = True
            except Exception:
                pass

        return {
            "ticker": ticker,
            "days_to_earnings":      days_to,
            "next_earnings_date":    next_date,
            "last_earnings_date":    edata.get("last_earnings_date"),
            "last_eps_surprise_pct": edata.get("last_eps_surprise_pct"),
            "signal":                edata.get("signal", "UNKNOWN"),
            "filing_flag":           filing_flag,
            "last_filing":           fdata.get("last_filing"),
            "earnings_risk":         earnings_risk,
        }

    # -----------------------------------------------------------------------
    # Trading integration hooks
    # -----------------------------------------------------------------------
    def adjust_position_size(self, base_shares, ticker, allow_earnings_play=False):
        """
        Apply earnings risk to a base share count.

          earnings_risk + filing_flag      -> 0 (skip entirely)
          earnings_risk + no flag          -> 50% size, or 0 if allow_earnings_play=False
          filing_flag only                 -> 70% size (extra caution)
          post-earnings BEAT_STRONG (<=5d) -> +10% size (momentum tailwind)
          post-earnings MISS_STRONG (<=5d) -> 50% size
          otherwise                        -> unchanged
        """
        if base_shares is None or base_shares <= 0:
            return 0

        status = self.get_earnings_status(ticker)
        adjusted = int(base_shares)

        # Hard veto: filing landed during earnings risk window
        if status["earnings_risk"] and status["filing_flag"]:
            logger.info(f"Earnings veto: {ticker} has fresh filing in earnings window")
            return 0

        # Earnings risk window
        if status["earnings_risk"]:
            if not allow_earnings_play:
                logger.info(f"Earnings veto: {ticker} reports in {status['days_to_earnings']}d")
                return 0
            adjusted = int(adjusted * 0.5)
            logger.info(f"Earnings play: {ticker} sized to {adjusted} (50%)")
            return max(0, adjusted)

        # Fresh filing (no earnings window) - extra caution
        if status["filing_flag"]:
            adjusted = int(adjusted * 0.7)
            logger.info(f"Filing flag: {ticker} sized to {adjusted} (70%)")

        # Post-earnings momentum/recovery adjustment - only within 5 days
        last_date_str = status.get("last_earnings_date")
        if last_date_str:
            try:
                last_dt = datetime.strptime(last_date_str[:10], "%Y-%m-%d").date()
                days_since = (date.today() - last_dt).days
                if 0 <= days_since <= 5:
                    sig = status["signal"]
                    if sig == "BEAT_STRONG":
                        adjusted = int(adjusted * 1.1)
                        logger.info(f"Earnings tailwind: {ticker} BEAT_STRONG, "
                                    f"sized to {adjusted} (+10%)")
                    elif sig == "MISS_STRONG":
                        adjusted = int(adjusted * 0.5)
                        logger.info(f"Earnings drag: {ticker} MISS_STRONG, "
                                    f"sized to {adjusted} (50%)")
            except Exception:
                pass

        return max(0, adjusted)

    def should_trade_symbol(self, ticker, allow_earnings_play=False):
        """Boolean convenience wrapper around adjust_position_size."""
        return self.adjust_position_size(100, ticker, allow_earnings_play) > 0

    def get_summary(self):
        """Snapshot summary for logging or the menu UI."""
        with self._lock:
            n_tickers = len(self.earnings)
            n_with_dates = sum(1 for e in self.earnings.values()
                               if e.get("next_earnings_date"))
        n_flagged = sum(1 for t in self.watchlist
                        if self.get_earnings_status(t)["earnings_risk"])
        n_filings = sum(1 for t in self.watchlist
                        if self.get_earnings_status(t)["filing_flag"])
        return {
            "tickers_tracked":     n_tickers,
            "with_earnings_dates": n_with_dates,
            "in_earnings_window":  n_flagged,
            "fresh_filings":       n_filings,
            "last_calendar_refresh": (
                self.last_calendar_refresh.isoformat() if self.last_calendar_refresh else None
            ),
            "last_edgar_refresh": (
                self.last_edgar_refresh.isoformat() if self.last_edgar_refresh else None
            ),
        }


# ---------------------------------------------------------------------------
# Standalone self-test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    test_watchlist = ["AAPL", "MSFT", "NVDA", "TSLA", "SPY"]
    ei = EarningsIntelligence(watchlist=test_watchlist)
    ei.refresh_calendar()
    ei.refresh_edgar()

    print("\n=== EARNINGS STATUS ===")
    for t in test_watchlist:
        s = ei.get_earnings_status(t)
        print(f"  {t:<6} d2e={s['days_to_earnings']!s:<6} "
              f"signal={s['signal']:<12} "
              f"surprise={s['last_eps_surprise_pct']!s:<8} "
              f"risk={s['earnings_risk']!s:<6} "
              f"filing={s['filing_flag']}")
    print("\n=== SUMMARY ===")
    for k, v in ei.get_summary().items():
        print(f"  {k:<22} {v}")
