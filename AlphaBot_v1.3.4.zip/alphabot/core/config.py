"""
Configuration management for AlphaBot
"""

import json
import os


DEFAULT_CONFIG = {
    "alpaca_api_key": "YOUR_ALPACA_API_KEY",
    "alpaca_secret_key": "YOUR_ALPACA_SECRET_KEY",
    "strategy": "combined",
    "markets": ["stocks"],
    "watchlist": [
        "AAPL", "MSFT", "NVDA", "GOOGL", "AMZN",
        "TSLA", "SPY", "QQQ", "META", "AMD"
    ],
    "risk": {
        "max_position_pct": 0.05,
        "max_portfolio_risk_pct": 0.20,
        "risk_per_trade_pct": 0.02,
        "max_open_positions": 8,
        "stop_loss_pct": 0.05,
        "take_profit_pct": 0.10,
        "trailing_stop_pct": 0.03
    },
    "ml": {
        "retrain_interval_hours": 24,
        "min_training_samples": 500,
        "confidence_threshold": 0.62,
        "lookback_days": 120,
        "features": [
            "rsi", "macd", "bbands", "volume_ratio",
            "momentum", "atr", "vwap_distance", "trend_strength"
        ]
    },
    "trading": {
        "check_interval_seconds": 60,
        "market_open_buffer_minutes": 15,
        "market_close_buffer_minutes": 30,
        "allow_short": False,
        "allow_options": False,
        "paper_to_live_min_days": 30,
        "paper_to_live_min_sharpe": 1.0,
        "paper_to_live_min_winrate": 0.52
    },
    "aggressive_mode": {
        "enabled": False,
        "confidence_threshold": 0.55,
        "take_profit_pct": 0.05,
        "stop_loss_pct": 0.04,
        "trailing_stop_pct": 0.02,
        "max_open_positions": 12,
        "risk_per_trade_pct": 0.03
    },
    "notifications": {
        "enabled": False,
        "email": "",
        "smtp_server": "",
        "smtp_port": 587,
        "smtp_user": "",
        "smtp_password": ""
    }
}


class Config:
    def __init__(self, config_path="config.json"):
        self.config_path = config_path
        self.data = {}
        self._load()

    def _load(self):
        if os.path.exists(self.config_path):
            with open(self.config_path, "r") as f:
                loaded = json.load(f)
            # Deep merge with defaults
            self.data = self._merge(DEFAULT_CONFIG.copy(), loaded)
        else:
            self.data = DEFAULT_CONFIG.copy()
            self._save()
            print(f"✓ Created default config: {self.config_path}")
            print(f"  → Edit {self.config_path} to add your Alpaca API keys\n")

    def _merge(self, base, override):
        for k, v in override.items():
            if k in base and isinstance(base[k], dict) and isinstance(v, dict):
                self._merge(base[k], v)
            else:
                base[k] = v
        return base

    def _save(self):
        with open(self.config_path, "w") as f:
            json.dump(self.data, f, indent=2)

    def get(self, key, default=None):
        keys = key.split(".")
        val = self.data
        for k in keys:
            if isinstance(val, dict):
                val = val.get(k, default)
            else:
                return default
        return val if val is not None else default

    def set(self, key, value):
        keys = key.split(".")
        d = self.data
        for k in keys[:-1]:
            d = d.setdefault(k, {})
        d[keys[-1]] = value
        self._save()

    def __getitem__(self, key):
        return self.data[key]

    def __contains__(self, key):
        return key in self.data
