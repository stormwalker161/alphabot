"""
Alpaca Markets broker interface
Handles all order execution, account info, and market data
"""

import requests
import logging
from datetime import datetime, timedelta
import time

logger = logging.getLogger("alphabot.broker")


class AlpacaBroker:
    def __init__(self, config, paper=True):
        self.config = config
        self.paper = paper
        self.api_key = config.get("alpaca_api_key", "")
        self.secret_key = config.get("alpaca_secret_key", "")

        if paper:
            self.base_url = "https://paper-api.alpaca.markets"
        else:
            self.base_url = "https://api.alpaca.markets"

        self.data_url = "https://data.alpaca.markets"
        self.headers = {
            "APCA-API-KEY-ID": self.api_key,
            "APCA-API-SECRET-KEY": self.secret_key,
            "Content-Type": "application/json"
        }

    def _get(self, url, params=None):
        try:
            r = requests.get(url, headers=self.headers, params=params, timeout=10)
            r.raise_for_status()
            return r.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"GET {url} failed: {e}")
            return None

    def _post(self, url, data):
        try:
            r = requests.post(url, headers=self.headers, json=data, timeout=10)
            r.raise_for_status()
            return r.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"POST {url} failed: {e}")
            return None

    def _delete(self, url):
        try:
            r = requests.delete(url, headers=self.headers, timeout=10)
            r.raise_for_status()
            return True
        except requests.exceptions.RequestException as e:
            logger.error(f"DELETE {url} failed: {e}")
            return False

    def test_connection(self):
        if not self.api_key or self.api_key == "YOUR_ALPACA_API_KEY":
            return False
        result = self._get(f"{self.base_url}/v2/account")
        return result is not None

    def get_account(self):
        result = self._get(f"{self.base_url}/v2/account")
        return result or {}

    def get_positions(self):
        result = self._get(f"{self.base_url}/v2/positions")
        return result or []

    def get_position(self, symbol):
        result = self._get(f"{self.base_url}/v2/positions/{symbol}")
        return result

    def get_orders(self, status="open"):
        result = self._get(f"{self.base_url}/v2/orders", {"status": status, "limit": 100})
        return result or []

    def submit_order(self, symbol, qty, side, order_type="market",
                     limit_price=None, stop_price=None,
                     time_in_force="day", take_profit=None, stop_loss=None):
        data = {
            "symbol": symbol,
            "qty": str(qty),
            "side": side,
            "type": order_type,
            "time_in_force": time_in_force
        }
        if limit_price:
            data["limit_price"] = str(round(limit_price, 2))
        if stop_price:
            data["stop_price"] = str(round(stop_price, 2))

        # Bracket order (take profit + stop loss together)
        if take_profit or stop_loss:
            data["order_class"] = "bracket"
            if take_profit:
                data["take_profit"] = {"limit_price": str(round(take_profit, 2))}
            if stop_loss:
                data["stop_loss"] = {"stop_price": str(round(stop_loss, 2))}

        logger.info(f"Submitting {side} {order_type} order: {qty} {symbol}")
        result = self._post(f"{self.base_url}/v2/orders", data)
        if result:
            logger.info(f"Order submitted: {result.get('id', 'unknown')}")
        return result

    def cancel_order(self, order_id):
        return self._delete(f"{self.base_url}/v2/orders/{order_id}")

    def cancel_all_orders(self):
        return self._delete(f"{self.base_url}/v2/orders")

    def close_position(self, symbol):
        result = self._delete(f"{self.base_url}/v2/positions/{symbol}")
        if result:
            logger.info(f"Closed position: {symbol}")
        return result

    def close_all_positions(self):
        return self._delete(f"{self.base_url}/v2/positions")

    def get_bars(self, symbol, timeframe="1Day", limit=200, start=None):
        params = {"symbols": symbol, "timeframe": timeframe, "limit": limit}
        if start:
            params["start"] = start
        result = self._get(f"{self.data_url}/v2/stocks/bars", params)
        if result and "bars" in result:
            return result["bars"].get(symbol, [])
        return []

    def get_multi_bars(self, symbols, timeframe="1Day", limit=200):
        params = {
            "symbols": ",".join(symbols),
            "timeframe": timeframe,
            "limit": limit
        }
        result = self._get(f"{self.data_url}/v2/stocks/bars", params)
        if result and "bars" in result:
            return result["bars"]
        return {}

    def get_latest_quote(self, symbol):
        result = self._get(f"{self.data_url}/v2/stocks/{symbol}/quotes/latest")
        if result and "quote" in result:
            return result["quote"]
        return None

    def get_latest_trade(self, symbol):
        result = self._get(f"{self.data_url}/v2/stocks/{symbol}/trades/latest")
        if result and "trade" in result:
            return result["trade"]
        return None

    def get_latest_price(self, symbol):
        trade = self.get_latest_trade(symbol)
        if trade:
            return float(trade.get("p", 0))
        return None

    def is_market_open(self):
        result = self._get(f"{self.base_url}/v2/clock")
        if result:
            return result.get("is_open", False)
        return False

    def get_clock(self):
        return self._get(f"{self.base_url}/v2/clock") or {}

    def get_portfolio_history(self, period="1M", timeframe="1D"):
        result = self._get(f"{self.base_url}/v2/account/portfolio/history",
                           {"period": period, "timeframe": timeframe})
        return result or {}

    def get_asset_info(self, symbol):
        result = self._get(f"{self.base_url}/v2/assets/{symbol}")
        return result or {}

    def is_tradable(self, symbol):
        asset = self.get_asset_info(symbol)
        return asset.get("tradable", False) and asset.get("status") == "active"
