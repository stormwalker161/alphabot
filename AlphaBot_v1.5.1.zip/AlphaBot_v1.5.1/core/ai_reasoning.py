"""
AIReasoning - LLM second-opinion layer for high-stakes AlphaBot trades
======================================================================
Invokes Claude (claude-sonnet-4-20250514) or GPT-4o as a structured
second-opinion when a trade signal is Strong Buy / Strong Sell AND the
position would exceed 8% of total portfolio value.

The LLM receives a concise snapshot of every data layer the bot has
(signal breakdown, news, social, macro, open positions) and returns
one of three verdicts:

    APPROVE       — proceed with the trade as-is
    REJECT        — skip the trade entirely (with reason)
    REDUCE_SIZE   — proceed at a reduced size (with multiplier, e.g. 0.5)

Timeout: 8 seconds. If the LLM doesn't respond in time, the module
falls back to the rule-based signal alone (no veto, no resize).

API keys are loaded from config.json (never hardcoded). Both providers
are supported; the user picks one via config:

    "ai_reasoning": {
        "enabled": true,
        "provider": "anthropic",          // "anthropic" or "openai"
        "anthropic_api_key": "sk-ant-...",
        "openai_api_key":    "sk-...",
        "model_anthropic":   "claude-sonnet-4-20250514",
        "model_openai":      "gpt-4o",
        "timeout_seconds":   8,
        "position_threshold_pct": 8.0,
        "enabled_actions":   ["STRONG_BUY", "STRONG_SELL"]
    }

Integration with engine.py
--------------------------
In TradingEngine.__init__:
    from core.ai_reasoning import AIReasoning
    self.ai_reasoning = AIReasoning(config)

In TradingEngine.execute_signals(), after position sizing:
    verdict = self.ai_reasoning.evaluate_trade(
        ticker=symbol,
        price=price,
        signal=trade_signal,             # TradeSignal from SignalEngine
        position_value=shares * price,
        portfolio_equity=account_equity,
        news_headlines=last_3_headlines,  # list[str]
        social_summary=social_dict,       # from CombinedIntelligence
        macro_context=macro_dict,         # from MacroIntelligence
        open_positions=positions,         # list[dict] from broker
    )
    if verdict["decision"] == "REJECT":
        logger.info(f"AI REJECT {symbol}: {verdict['reason']}")
        continue
    if verdict["decision"] == "REDUCE_SIZE":
        shares = int(shares * verdict["size_multiplier"])
        logger.info(f"AI REDUCE {symbol}: {verdict['size_multiplier']}x -> {shares}")

Pure stdlib + requests. No async runtime required (uses threading for
timeout). Windows-safe. All output via logger.info().
"""

from __future__ import annotations

import json
import logging
import re
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("alphabot.ai_reasoning")

# Optional dep — requests is already in AlphaBot's requirements
try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    logger.warning("requests not installed — AIReasoning disabled")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
DEFAULT_TIMEOUT = 8            # seconds — hard ceiling for LLM round-trip
POSITION_THRESHOLD_PCT = 8.0   # only invoke LLM above this % of portfolio
ENABLED_ACTIONS = frozenset({"STRONG_BUY", "STRONG_SELL"})

ANTHROPIC_API_URL = "https://api.anthropic.com/v1/messages"
OPENAI_API_URL    = "https://api.openai.com/v1/chat/completions"

# Max tokens for the LLM response — we only need a short structured reply
MAX_RESPONSE_TOKENS = 350


# ---------------------------------------------------------------------------
# Prompt template
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """\
You are AlphaBot's risk-review layer. You receive a structured snapshot of a \
proposed stock trade and all supporting data the bot has collected. Your job \
is to apply common-sense risk judgment and return a single JSON verdict.

You MUST respond with ONLY a JSON object (no markdown, no backticks, no \
preamble). The JSON must have exactly these keys:

{
  "decision": "APPROVE" | "REJECT" | "REDUCE_SIZE",
  "size_multiplier": <float 0.1-1.0, required only when decision is REDUCE_SIZE>,
  "reason": "<1-2 sentence explanation>"
}

Decision guidelines:
- APPROVE if the data paints a consistent picture and risk is manageable.
- REJECT if you see a clear red flag: conflicting signals across layers, \
  extreme negative news, earnings within 24h, macro RISK_OFF with a high-beta \
  name, portfolio already over-concentrated in the same sector, or any pattern \
  that suggests the trade is more likely to lose money than make it.
- REDUCE_SIZE if the thesis is sound but the size is aggressive given the \
  risk factors. Provide a multiplier between 0.1 and 0.9 (e.g. 0.5 = half \
  the proposed size).

Be decisive. Do not hedge. Pick exactly one of the three decisions.\
"""

TRADE_PROMPT_TEMPLATE = """\
=== PROPOSED TRADE ===
Ticker:          {ticker}
Action:          {action}
Current Price:   ${price:.2f}
Proposed Size:   {proposed_shares} shares (${position_value:,.2f})
Portfolio Value: ${portfolio_equity:,.2f}
Position as %:   {position_pct:.1f}% of portfolio

=== SIGNAL BREAKDOWN ===
Composite Score: {composite_score:.1f}/100
Direction:       {dominant_direction} ({direction_agreement}/5 sources agree)

  Technical:  {technical_score:.1f}/100 (weight {tech_weight:.0%})
  Momentum:   {momentum_score:.1f}/100 (weight {mom_weight:.0%})
  News:       {news_score:.1f}/100 (weight {news_weight:.0%})
  Social:     {social_score:.1f}/100 (weight {social_weight:.0%})
  Macro:      {macro_score:.1f}/100 (weight {macro_weight:.0%})

=== LAST 3 NEWS HEADLINES ===
{news_block}

=== SOCIAL SENTIMENT ===
{social_block}

=== MACRO REGIME ===
{macro_block}

=== CURRENT OPEN POSITIONS ({n_positions} total) ===
{positions_block}
Total Exposure: ${total_exposure:,.2f} ({exposure_pct:.1f}% of equity)

Based on all the above, should this trade proceed?\
"""


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------
@dataclass
class AIVerdict:
    """Structured result from the AI reasoning layer."""
    decision:        str   = "APPROVE"     # APPROVE | REJECT | REDUCE_SIZE
    size_multiplier: float = 1.0           # 0.1-1.0, only meaningful for REDUCE_SIZE
    reason:          str   = ""
    provider:        str   = ""            # "anthropic" | "openai" | "fallback"
    latency_ms:      int   = 0
    raw_response:    str   = ""
    error:           str   = ""

    def to_dict(self) -> dict:
        return {
            "decision":        self.decision,
            "size_multiplier": self.size_multiplier,
            "reason":          self.reason,
            "provider":        self.provider,
            "latency_ms":      self.latency_ms,
            "error":           self.error,
        }


# ---------------------------------------------------------------------------
# AIReasoning
# ---------------------------------------------------------------------------
class AIReasoning:
    """
    LLM second-opinion layer for high-stakes trades.

    Usage:
        ai = AIReasoning(config)
        verdict = ai.evaluate_trade(
            ticker="NVDA", price=135.20, signal=trade_signal,
            position_value=10800, portfolio_equity=100000,
            news_headlines=[...], social_summary={...},
            macro_context={...}, open_positions=[...],
        )
        if verdict["decision"] == "REJECT":
            skip the trade
    """

    def __init__(self, config=None):
        self.config = config
        self._lock = threading.Lock()

        # Load settings from config (with safe defaults)
        ai_cfg = {}
        if config is not None:
            try:
                ai_cfg = config.get("ai_reasoning") or {}
                if not isinstance(ai_cfg, dict):
                    ai_cfg = {}
            except Exception:
                ai_cfg = {}

        self.enabled = bool(ai_cfg.get("enabled", False))
        self.provider = str(ai_cfg.get("provider", "anthropic")).lower().strip()

        # API keys — NEVER hardcoded
        self._anthropic_key = str(ai_cfg.get("anthropic_api_key", "")).strip()
        self._openai_key    = str(ai_cfg.get("openai_api_key", "")).strip()

        # Model names
        self.model_anthropic = str(ai_cfg.get("model_anthropic", "claude-sonnet-4-20250514"))
        self.model_openai    = str(ai_cfg.get("model_openai", "gpt-4o"))

        # Thresholds
        self.timeout = int(ai_cfg.get("timeout_seconds", DEFAULT_TIMEOUT))
        self.position_threshold_pct = float(
            ai_cfg.get("position_threshold_pct", POSITION_THRESHOLD_PCT)
        )
        self.enabled_actions = set(
            ai_cfg.get("enabled_actions", list(ENABLED_ACTIONS))
        )

        # Stats
        self._call_count = 0
        self._approve_count = 0
        self._reject_count = 0
        self._reduce_count = 0
        self._timeout_count = 0
        self._error_count = 0

        # Validate config
        if self.enabled:
            if self.provider == "anthropic" and not self._anthropic_key:
                logger.warning("AIReasoning enabled but anthropic_api_key is empty — "
                               "will fall back to rule-based on every call")
            elif self.provider == "openai" and not self._openai_key:
                logger.warning("AIReasoning enabled but openai_api_key is empty — "
                               "will fall back to rule-based on every call")
            elif self.provider not in ("anthropic", "openai"):
                logger.warning(f"AIReasoning: unknown provider '{self.provider}', "
                               f"defaulting to anthropic")
                self.provider = "anthropic"

            logger.info(
                f"AIReasoning initialized | provider={self.provider} | "
                f"timeout={self.timeout}s | threshold={self.position_threshold_pct}% | "
                f"actions={self.enabled_actions}"
            )
        else:
            logger.info("AIReasoning disabled — all trades use rule-based signals only")

    # -----------------------------------------------------------------------
    # Gate check: should we even invoke the LLM?
    # -----------------------------------------------------------------------
    def should_invoke(
        self,
        action: str,
        position_value: float,
        portfolio_equity: float,
    ) -> Tuple[bool, str]:
        """
        Check whether this trade meets the criteria for LLM review.

        Returns (should_invoke: bool, reason: str).
        """
        if not self.enabled:
            return False, "AI reasoning disabled"

        if not HAS_REQUESTS:
            return False, "requests library not available"

        if action not in self.enabled_actions:
            return False, f"action {action} not in enabled_actions {self.enabled_actions}"

        if portfolio_equity <= 0:
            return False, "portfolio equity is zero or negative"

        position_pct = (position_value / portfolio_equity) * 100.0
        if position_pct < self.position_threshold_pct:
            return False, (
                f"position {position_pct:.1f}% < threshold "
                f"{self.position_threshold_pct}%"
            )

        # Check we have a key for the configured provider
        if self.provider == "anthropic" and not self._anthropic_key:
            return False, "no Anthropic API key configured"
        if self.provider == "openai" and not self._openai_key:
            return False, "no OpenAI API key configured"

        return True, "OK"

    # -----------------------------------------------------------------------
    # Prompt builder
    # -----------------------------------------------------------------------
    def _build_prompt(
        self,
        ticker: str,
        price: float,
        signal,               # TradeSignal dataclass
        proposed_shares: int,
        position_value: float,
        portfolio_equity: float,
        news_headlines: List[str],
        social_summary: Optional[Dict],
        macro_context: Optional[Dict],
        open_positions: Optional[List[Dict]],
    ) -> str:
        """
        Build the structured prompt from all available data layers.
        Gracefully handles missing/None data in every section.
        """
        # Position percentage
        position_pct = (position_value / portfolio_equity * 100.0
                        if portfolio_equity > 0 else 0.0)

        # Signal breakdown (safe access for both TradeSignal objects and dicts)
        def _get(obj, attr, default=0.0):
            if obj is None:
                return default
            if isinstance(obj, dict):
                return obj.get(attr, default)
            return getattr(obj, attr, default)

        composite_score     = _get(signal, "composite_score", 50.0)
        dominant_direction  = _get(signal, "dominant_direction", "unknown")
        direction_agreement = _get(signal, "direction_agreement", 0)
        action              = _get(signal, "action", "UNKNOWN")
        technical_score     = _get(signal, "technical_score", 50.0)
        momentum_score      = _get(signal, "momentum_score", 50.0)
        news_score          = _get(signal, "news_score", 50.0)
        social_score        = _get(signal, "social_score", 50.0)
        macro_score         = _get(signal, "macro_score", 50.0)

        ew = _get(signal, "effective_weights", {})
        if not isinstance(ew, dict):
            ew = {}

        # News headlines block
        if news_headlines:
            news_lines = []
            for i, h in enumerate(news_headlines[:3], 1):
                news_lines.append(f"  {i}. {str(h)[:120]}")
            news_block = "\n".join(news_lines)
        else:
            news_block = "  (no recent headlines available)"

        # Social sentiment block
        if social_summary and isinstance(social_summary, dict):
            soc_parts = []
            soc_signal = social_summary.get("combined_signal",
                         social_summary.get("signal", "neutral"))
            soc_score_val = social_summary.get("combined_score",
                            social_summary.get("sentiment_avg", 0.0))
            soc_mentions = social_summary.get("social_mentions_2h",
                           social_summary.get("mentions_2h", 0))
            soc_momentum = social_summary.get("momentum_flag", False)
            soc_parts.append(f"Signal: {soc_signal}")
            soc_parts.append(f"Score: {soc_score_val:+.3f}")
            soc_parts.append(f"Mentions (2h): {soc_mentions}")
            if soc_momentum:
                soc_parts.append("MOMENTUM SPIKE detected")
            social_block = "  " + " | ".join(soc_parts)
        else:
            social_block = "  (no social data available)"

        # Macro block
        if macro_context and isinstance(macro_context, dict):
            mac_parts = []
            mac_parts.append(f"Regime: {macro_context.get('regime', 'UNKNOWN')}")
            mac_parts.append(f"Bias: {macro_context.get('market_bias', 'unknown')}")
            fed = macro_context.get("fed_rate")
            if fed is not None:
                mac_parts.append(f"Fed Rate: {fed:.2f}%")
            cpi = macro_context.get("cpi_yoy")
            if cpi is not None:
                mac_parts.append(f"CPI YoY: {cpi}%")
            unemp = macro_context.get("unemployment")
            if unemp is not None:
                mac_parts.append(f"Unemployment: {unemp:.1f}%")
            nxt = macro_context.get("next_major_event")
            if nxt and isinstance(nxt, dict) and nxt.get("name"):
                mac_parts.append(f"Next Event: {nxt['name'][:80]}")
            macro_block = "  " + " | ".join(mac_parts)
        else:
            macro_block = "  (no macro data available)"

        # Open positions block
        positions = open_positions or []
        total_exposure = 0.0
        pos_lines = []
        for p in positions[:15]:  # Cap at 15 to keep prompt short
            sym = p.get("symbol", "?")
            qty = p.get("qty", "?")
            mkt_val = float(p.get("market_value", 0))
            unrealized = float(p.get("unrealized_pl", 0))
            pct_change = float(p.get("unrealized_plpc", 0)) * 100
            total_exposure += abs(mkt_val)
            pos_lines.append(
                f"  {sym:<6} x{qty} | value=${mkt_val:,.0f} | "
                f"P&L=${unrealized:+,.0f} ({pct_change:+.1f}%)"
            )
        if not pos_lines:
            positions_block = "  (no open positions)"
        else:
            positions_block = "\n".join(pos_lines)

        exposure_pct = (total_exposure / portfolio_equity * 100.0
                        if portfolio_equity > 0 else 0.0)

        return TRADE_PROMPT_TEMPLATE.format(
            ticker=ticker,
            action=action,
            price=price,
            proposed_shares=proposed_shares,
            position_value=position_value,
            portfolio_equity=portfolio_equity,
            position_pct=position_pct,
            composite_score=composite_score,
            dominant_direction=dominant_direction,
            direction_agreement=direction_agreement,
            technical_score=technical_score,
            momentum_score=momentum_score,
            news_score=news_score,
            social_score=social_score,
            macro_score=macro_score,
            tech_weight=ew.get("technical", 0.35),
            mom_weight=ew.get("momentum", 0.25),
            news_weight=ew.get("news", 0.20),
            social_weight=ew.get("social", 0.10),
            macro_weight=ew.get("macro", 0.10),
            news_block=news_block,
            social_block=social_block,
            macro_block=macro_block,
            n_positions=len(positions),
            positions_block=positions_block,
            total_exposure=total_exposure,
            exposure_pct=exposure_pct,
        )

    # -----------------------------------------------------------------------
    # LLM API callers
    # -----------------------------------------------------------------------
    def _call_anthropic(self, prompt: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Call Claude via Anthropic Messages API.
        Returns (response_text, error_string). One will be None.
        """
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self._anthropic_key,
            "anthropic-version": "2023-06-01",
        }
        payload = {
            "model": self.model_anthropic,
            "max_tokens": MAX_RESPONSE_TOKENS,
            "system": SYSTEM_PROMPT,
            "messages": [
                {"role": "user", "content": prompt}
            ],
        }

        try:
            resp = requests.post(
                ANTHROPIC_API_URL,
                headers=headers,
                json=payload,
                timeout=self.timeout,
            )
            if resp.status_code != 200:
                body = resp.text[:300]
                return None, f"Anthropic API {resp.status_code}: {body}"

            data = resp.json()
            # Extract text from content blocks
            content = data.get("content", [])
            text_parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    text_parts.append(block.get("text", ""))
            return "\n".join(text_parts).strip(), None

        except requests.exceptions.Timeout:
            return None, "Anthropic API timeout"
        except requests.exceptions.ConnectionError as e:
            return None, f"Anthropic connection error: {e}"
        except Exception as e:
            return None, f"Anthropic unexpected error: {e}"

    def _call_openai(self, prompt: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Call GPT-4o via OpenAI Chat Completions API.
        Returns (response_text, error_string). One will be None.
        """
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._openai_key}",
        }
        payload = {
            "model": self.model_openai,
            "max_tokens": MAX_RESPONSE_TOKENS,
            "temperature": 0.2,  # Low temp for deterministic risk assessment
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        }

        try:
            resp = requests.post(
                OPENAI_API_URL,
                headers=headers,
                json=payload,
                timeout=self.timeout,
            )
            if resp.status_code != 200:
                body = resp.text[:300]
                return None, f"OpenAI API {resp.status_code}: {body}"

            data = resp.json()
            choices = data.get("choices", [])
            if not choices:
                return None, "OpenAI returned empty choices"
            text = choices[0].get("message", {}).get("content", "").strip()
            return text, None

        except requests.exceptions.Timeout:
            return None, "OpenAI API timeout"
        except requests.exceptions.ConnectionError as e:
            return None, f"OpenAI connection error: {e}"
        except Exception as e:
            return None, f"OpenAI unexpected error: {e}"

    # -----------------------------------------------------------------------
    # Response parser
    # -----------------------------------------------------------------------
    @staticmethod
    def _parse_response(raw: str) -> AIVerdict:
        """
        Parse the LLM's JSON response into an AIVerdict.

        Handles:
          - Clean JSON
          - JSON wrapped in markdown code fences
          - Partial / malformed JSON (regex fallback)
        """
        if not raw or not raw.strip():
            return AIVerdict(
                decision="APPROVE",
                reason="Empty LLM response — defaulting to approve",
                error="empty_response",
            )

        # Strip markdown fences if present
        cleaned = raw.strip()
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
        cleaned = cleaned.strip()

        # Attempt JSON parse
        parsed = None
        try:
            parsed = json.loads(cleaned)
        except json.JSONDecodeError:
            # Try to extract JSON object from surrounding text
            match = re.search(r"\{[^{}]*\}", cleaned, re.DOTALL)
            if match:
                try:
                    parsed = json.loads(match.group())
                except json.JSONDecodeError:
                    pass

        if parsed is None:
            # Last resort: regex for decision keyword
            decision = "APPROVE"
            reason = "Could not parse LLM response"
            upper = raw.upper()
            if "REJECT" in upper:
                decision = "REJECT"
                reason = raw[:200]
            elif "REDUCE_SIZE" in upper or "REDUCE" in upper:
                decision = "REDUCE_SIZE"
                reason = raw[:200]

            logger.warning(f"AIReasoning: JSON parse failed, regex fallback -> {decision}")
            return AIVerdict(
                decision=decision,
                size_multiplier=0.5 if decision == "REDUCE_SIZE" else 1.0,
                reason=reason,
                error="json_parse_failed",
                raw_response=raw[:500],
            )

        # Validate decision field
        decision = str(parsed.get("decision", "APPROVE")).upper().strip()
        if decision not in ("APPROVE", "REJECT", "REDUCE_SIZE"):
            logger.warning(f"AIReasoning: unknown decision '{decision}', defaulting to APPROVE")
            decision = "APPROVE"

        # Size multiplier (only relevant for REDUCE_SIZE)
        size_mult = 1.0
        if decision == "REDUCE_SIZE":
            try:
                size_mult = float(parsed.get("size_multiplier", 0.5))
                size_mult = max(0.1, min(1.0, size_mult))
            except (TypeError, ValueError):
                size_mult = 0.5
                logger.warning("AIReasoning: invalid size_multiplier, defaulting to 0.5")

        reason = str(parsed.get("reason", "No reason provided"))[:300]

        return AIVerdict(
            decision=decision,
            size_multiplier=size_mult,
            reason=reason,
            raw_response=raw[:500],
        )

    # -----------------------------------------------------------------------
    # Thread-wrapped LLM call with timeout
    # -----------------------------------------------------------------------
    def _call_llm_with_timeout(self, prompt: str) -> Tuple[Optional[str], Optional[str]]:
        """
        Run the LLM call in a separate thread so we can enforce the timeout
        even if the HTTP library's own timeout doesn't fire (e.g. DNS stall).

        Returns (response_text, error_string).
        """
        result_container: Dict[str, Any] = {"text": None, "error": None}

        def _worker():
            if self.provider == "anthropic":
                text, err = self._call_anthropic(prompt)
            else:
                text, err = self._call_openai(prompt)
            result_container["text"] = text
            result_container["error"] = err

        thread = threading.Thread(target=_worker, daemon=True,
                                  name="AIReasoning-LLM")
        thread.start()
        thread.join(timeout=self.timeout)

        if thread.is_alive():
            # Thread is still running — we've exceeded our timeout
            logger.warning(f"AIReasoning: LLM call exceeded {self.timeout}s timeout")
            return None, "timeout"

        return result_container["text"], result_container["error"]

    # -----------------------------------------------------------------------
    # Main public API
    # -----------------------------------------------------------------------
    def evaluate_trade(
        self,
        ticker: str,
        price: float,
        signal,                                    # TradeSignal or dict
        position_value: float,
        portfolio_equity: float,
        proposed_shares: int = 0,
        news_headlines: Optional[List[str]] = None,
        social_summary: Optional[Dict] = None,
        macro_context: Optional[Dict] = None,
        open_positions: Optional[List[Dict]] = None,
    ) -> Dict[str, Any]:
        """
        Evaluate a proposed trade through the LLM second-opinion layer.

        Returns a dict with keys:
            decision         : "APPROVE" | "REJECT" | "REDUCE_SIZE"
            size_multiplier  : float (1.0 for APPROVE/REJECT, 0.1-0.9 for REDUCE)
            reason           : str
            provider         : str ("anthropic" | "openai" | "fallback" | "skipped")
            latency_ms       : int
            error            : str (empty if no error)
        """
        # Derive action from signal
        if isinstance(signal, dict):
            action = signal.get("action", "UNKNOWN")
        else:
            action = getattr(signal, "action", "UNKNOWN")

        # If proposed_shares not given, derive from position_value / price
        if proposed_shares <= 0 and price > 0:
            proposed_shares = int(position_value / price)

        # Gate check
        should, gate_reason = self.should_invoke(action, position_value,
                                                 portfolio_equity)
        if not should:
            logger.info(f"AIReasoning skipped for {ticker}: {gate_reason}")
            return AIVerdict(
                decision="APPROVE",
                reason=f"AI review skipped: {gate_reason}",
                provider="skipped",
            ).to_dict()

        # Build prompt
        logger.info(f"AIReasoning: evaluating {ticker} {action} "
                    f"(${position_value:,.0f}, "
                    f"{position_value/portfolio_equity*100:.1f}% of portfolio)")

        prompt = self._build_prompt(
            ticker=ticker,
            price=price,
            signal=signal,
            proposed_shares=proposed_shares,
            position_value=position_value,
            portfolio_equity=portfolio_equity,
            news_headlines=news_headlines or [],
            social_summary=social_summary,
            macro_context=macro_context,
            open_positions=open_positions,
        )

        # Call LLM with timeout
        t0 = time.monotonic()
        raw_text, error = self._call_llm_with_timeout(prompt)
        latency_ms = int((time.monotonic() - t0) * 1000)

        with self._lock:
            self._call_count += 1

        # Handle errors / timeouts — fall back to rule-based (APPROVE)
        if error:
            with self._lock:
                if "timeout" in str(error).lower():
                    self._timeout_count += 1
                else:
                    self._error_count += 1

            logger.warning(f"AIReasoning: LLM error for {ticker}: {error} "
                           f"({latency_ms}ms) — falling back to rule-based signal")
            return AIVerdict(
                decision="APPROVE",
                reason=f"LLM unavailable ({error}) — rule-based fallback",
                provider="fallback",
                latency_ms=latency_ms,
                error=str(error),
            ).to_dict()

        # Parse response
        verdict = self._parse_response(raw_text)
        verdict.provider = self.provider
        verdict.latency_ms = latency_ms

        # Update stats
        with self._lock:
            if verdict.decision == "APPROVE":
                self._approve_count += 1
            elif verdict.decision == "REJECT":
                self._reject_count += 1
            elif verdict.decision == "REDUCE_SIZE":
                self._reduce_count += 1

        # Log the verdict
        if verdict.decision == "REJECT":
            logger.info(f"AIReasoning REJECT {ticker}: {verdict.reason} "
                        f"({verdict.provider}, {latency_ms}ms)")
        elif verdict.decision == "REDUCE_SIZE":
            logger.info(f"AIReasoning REDUCE_SIZE {ticker}: "
                        f"{verdict.size_multiplier:.2f}x — {verdict.reason} "
                        f"({verdict.provider}, {latency_ms}ms)")
        else:
            logger.info(f"AIReasoning APPROVE {ticker}: {verdict.reason} "
                        f"({verdict.provider}, {latency_ms}ms)")

        return verdict.to_dict()

    # -----------------------------------------------------------------------
    # Stats / summary
    # -----------------------------------------------------------------------
    def get_stats(self) -> Dict[str, Any]:
        """Return cumulative stats for the menu UI or logging."""
        with self._lock:
            return {
                "enabled":       self.enabled,
                "provider":      self.provider,
                "total_calls":   self._call_count,
                "approvals":     self._approve_count,
                "rejections":    self._reject_count,
                "reductions":    self._reduce_count,
                "timeouts":      self._timeout_count,
                "errors":        self._error_count,
                "timeout_sec":   self.timeout,
                "threshold_pct": self.position_threshold_pct,
            }

    def log_stats(self):
        """Emit a one-line summary to the logger."""
        s = self.get_stats()
        if not s["enabled"]:
            return
        logger.info(
            f"AIReasoning stats | calls={s['total_calls']} | "
            f"approve={s['approvals']} reject={s['rejections']} "
            f"reduce={s['reductions']} | "
            f"timeouts={s['timeouts']} errors={s['errors']} | "
            f"provider={s['provider']}"
        )


# ---------------------------------------------------------------------------
# Standalone self-test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stdout,
    )

    logger.info("=== AIReasoning — standalone test ===")

    # Simulated config (no real API key — will exercise gate + fallback logic)
    class FakeConfig:
        def __init__(self, data):
            self._data = data
        def get(self, key, default=None):
            keys = key.split(".")
            obj = self._data
            for k in keys:
                if isinstance(obj, dict):
                    obj = obj.get(k)
                else:
                    return default
                if obj is None:
                    return default
            return obj

    cfg = FakeConfig({
        "ai_reasoning": {
            "enabled": True,
            "provider": "anthropic",
            "anthropic_api_key": "",   # intentionally empty for test
            "timeout_seconds": 8,
            "position_threshold_pct": 8.0,
            "enabled_actions": ["STRONG_BUY", "STRONG_SELL"],
        }
    })

    ai = AIReasoning(cfg)

    # Test 1: Gate check — should skip (no API key)
    logger.info("\n--- Test 1: Missing API key ---")
    v = ai.evaluate_trade(
        ticker="NVDA", price=135.0,
        signal={"action": "STRONG_BUY", "composite_score": 82.3,
                "dominant_direction": "bullish", "direction_agreement": 4,
                "technical_score": 78, "momentum_score": 85,
                "news_score": 72, "social_score": 69, "macro_score": 70,
                "effective_weights": {"technical": 0.35, "momentum": 0.25,
                                      "news": 0.20, "social": 0.10, "macro": 0.10}},
        position_value=12000, portfolio_equity=100000,
        proposed_shares=88,
        news_headlines=["NVDA beats Q1 estimates", "AI chip demand surges",
                        "Nvidia partnership with major cloud provider"],
        social_summary={"combined_signal": "bullish", "combined_score": 0.35,
                        "social_mentions_2h": 45, "momentum_flag": False},
        macro_context={"regime": "RISK_ON", "market_bias": "bullish",
                       "fed_rate": 4.25, "cpi_yoy": 2.8, "unemployment": 3.9},
        open_positions=[
            {"symbol": "AAPL", "qty": 50, "market_value": 8500,
             "unrealized_pl": 320, "unrealized_plpc": 0.038},
            {"symbol": "MSFT", "qty": 30, "market_value": 12600,
             "unrealized_pl": -180, "unrealized_plpc": -0.014},
        ],
    )
    logger.info(f"Verdict: {json.dumps(v, indent=2)}")

    # Test 2: Gate check — should skip (action not in enabled list)
    logger.info("\n--- Test 2: Action BUY (not STRONG_BUY) ---")
    v2 = ai.evaluate_trade(
        ticker="AAPL", price=170.0,
        signal={"action": "BUY", "composite_score": 68},
        position_value=15000, portfolio_equity=100000,
    )
    logger.info(f"Verdict: {json.dumps(v2, indent=2)}")

    # Test 3: Gate check — should skip (position too small)
    logger.info("\n--- Test 3: Position under threshold ---")
    v3 = ai.evaluate_trade(
        ticker="SPY", price=520.0,
        signal={"action": "STRONG_BUY", "composite_score": 78},
        position_value=5000, portfolio_equity=100000,
    )
    logger.info(f"Verdict: {json.dumps(v3, indent=2)}")

    # Test 4: Response parser tests
    logger.info("\n--- Test 4: Response parser ---")

    # Clean JSON
    r1 = AIReasoning._parse_response(
        '{"decision": "REJECT", "reason": "Earnings in 24h, too risky"}'
    )
    logger.info(f"  Clean JSON:    decision={r1.decision} reason={r1.reason}")

    # Markdown-wrapped
    r2 = AIReasoning._parse_response(
        '```json\n{"decision": "REDUCE_SIZE", "size_multiplier": 0.6, '
        '"reason": "Macro is RISK_OFF"}\n```'
    )
    logger.info(f"  Markdown:      decision={r2.decision} mult={r2.size_multiplier}")

    # Malformed — regex fallback
    r3 = AIReasoning._parse_response(
        "I think you should REJECT this trade because of conflicting signals."
    )
    logger.info(f"  Regex fallback: decision={r3.decision} reason={r3.reason[:60]}")

    # Empty
    r4 = AIReasoning._parse_response("")
    logger.info(f"  Empty:         decision={r4.decision} error={r4.error}")

    ai.log_stats()
    logger.info("=== Test complete ===")
