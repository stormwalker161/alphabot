"""
PatternDetector - High-probability trade setup scanner for AlphaBot
===================================================================
Identifies two pattern families across the entire watchlist and returns
structured PatternSignal objects the trading engine can act on:

  1. BREAKOUT_LONG  — momentum / breakout continuation
  2. MEAN_REVERSION_LONG — oversold bounce / exhaustion reversal

Each detected pattern carries a confidence score (0-100), a suggested
entry price, and an invalidation level (the price at which the thesis
is wrong and the trade should be stopped out).

Pattern criteria
----------------

BREAKOUT_LONG (all must be true):
  • Price closes above 20-day high
  • Volume >= 1.5× the 20-day average volume
  • RSI between 55-75 (strong but not overbought)
  • MACD histogram turning positive (momentum accelerating)
  • Price above session VWAP
  Confidence boosters: volume ratio >2×, RSI 60-70 sweet spot, histogram
  acceleration, breakout margin > 1%.

MEAN_REVERSION_LONG (all must be true):
  • Price <= lower Bollinger Band (20-period, 2 std deviations)
  • RSI <= 30 (oversold)
  • Volume declining on the down move (exhaustion)
  • No negative earnings/news catalyst in last 48 hours
  Confidence boosters: RSI < 25 (deeply oversold), price touching lower BB
  with long lower wick, volume drying up significantly.

Integration with engine.py
--------------------------
    from core.pattern_detector import PatternDetector

    # In TradingEngine.__init__:
    self.pattern_detector = PatternDetector(config)

    # In scan_for_signals(), after data refresh:
    patterns = self.pattern_detector.scan(
        bars_cache=self.bars_cache,
        watchlist=self.watchlist,
        earnings_intel=self.intel.earnings if self.intel else None,
        news_intel=self.intel.sentiment.news if self.intel and self.intel.sentiment else None,
    )
    for p in patterns:
        logger.info(f"PATTERN {p.pattern_type} on {p.ticker} "
                     f"confidence={p.confidence} entry=${p.entry_price:.2f}")
        # Feed into SignalEngine as additional confirmation or standalone

Indicator calculations use pandas + numpy (already in requirements.txt).
Falls back gracefully if pandas-ta is installed (uses it for RSI/MACD/
Bollinger) but works fine without it via pure numpy implementations.

Safe to call every 5 minutes. Processes the full watchlist in a single
batch call. Windows-safe. Thread-safe (no shared mutable state between
scan calls). All output via logger.info().
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger("alphabot.pattern_detector")

# ---------------------------------------------------------------------------
# Dependency checks
# ---------------------------------------------------------------------------
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False
    logger.error("numpy not installed — PatternDetector requires numpy")

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False
    logger.error("pandas not installed — PatternDetector requires pandas")

# pandas-ta is preferred for indicator calculation but fully optional
try:
    import pandas_ta as ta
    HAS_PANDAS_TA = True
except ImportError:
    HAS_PANDAS_TA = False
    logger.info("pandas-ta not installed — using built-in indicator implementations")


# ---------------------------------------------------------------------------
# Output dataclass
# ---------------------------------------------------------------------------
@dataclass
class PatternSignal:
    """
    A detected trade pattern with all metadata the engine needs.

    Fields
    ------
    ticker              : symbol where the pattern was detected
    pattern_type        : "BREAKOUT_LONG" | "MEAN_REVERSION_LONG"
    confidence          : 0-100 composite confidence score
    entry_price_suggested : ideal entry (current close for breakouts,
                            current close for mean reversion)
    invalidation_level  : price where the thesis is wrong (stop level)
    detected_at         : UTC ISO timestamp of detection
    details             : dict of indicator values that triggered the pattern

    Convenience
    -----------
    risk_reward_ratio   : pre-computed R:R based on entry vs invalidation
                          vs a 2× risk target
    """
    ticker:                str
    pattern_type:          str            # BREAKOUT_LONG | MEAN_REVERSION_LONG
    confidence:            int            # 0-100
    entry_price_suggested: float
    invalidation_level:    float          # stop-loss / thesis-wrong level
    detected_at:           str   = ""     # ISO timestamp
    details:               dict  = field(default_factory=dict)

    @property
    def risk_reward_ratio(self) -> float:
        """R:R assuming a 2× risk target above entry."""
        risk = abs(self.entry_price_suggested - self.invalidation_level)
        if risk <= 0:
            return 0.0
        reward = risk * 2.0  # 2:1 target
        return round(reward / risk, 2)

    def to_dict(self) -> dict:
        return {
            "ticker":                self.ticker,
            "pattern_type":          self.pattern_type,
            "confidence":            self.confidence,
            "entry_price_suggested": round(self.entry_price_suggested, 4),
            "invalidation_level":    round(self.invalidation_level, 4),
            "risk_reward_ratio":     self.risk_reward_ratio,
            "detected_at":          self.detected_at,
            "details":               self.details,
        }

    def __repr__(self):
        return (
            f"PatternSignal({self.ticker} {self.pattern_type} "
            f"conf={self.confidence} entry=${self.entry_price_suggested:.2f} "
            f"stop=${self.invalidation_level:.2f})"
        )


# ---------------------------------------------------------------------------
# Pure-numpy indicator implementations (used when pandas-ta is absent)
# ---------------------------------------------------------------------------

def _sma(data: np.ndarray, period: int) -> np.ndarray:
    """Simple Moving Average. Returns array same length as input (NaN-padded)."""
    out = np.full_like(data, np.nan, dtype=float)
    if len(data) < period:
        return out
    cumsum = np.cumsum(data, dtype=float)
    cumsum[period:] = cumsum[period:] - cumsum[:-period]
    out[period - 1:] = cumsum[period - 1:] / period
    return out


def _ema(data: np.ndarray, period: int) -> np.ndarray:
    """Exponential Moving Average."""
    out = np.full_like(data, np.nan, dtype=float)
    if len(data) < period:
        return out
    alpha = 2.0 / (period + 1)
    # Seed with SMA of first `period` values
    out[period - 1] = np.mean(data[:period])
    for i in range(period, len(data)):
        out[i] = alpha * data[i] + (1.0 - alpha) * out[i - 1]
    return out


def _rsi(close: np.ndarray, period: int = 14) -> np.ndarray:
    """Relative Strength Index (Wilder smoothing)."""
    out = np.full_like(close, np.nan, dtype=float)
    if len(close) < period + 1:
        return out
    deltas = np.diff(close)
    gains = np.where(deltas > 0, deltas, 0.0)
    losses = np.where(deltas < 0, -deltas, 0.0)

    avg_gain = np.mean(gains[:period])
    avg_loss = np.mean(losses[:period])

    out[period] = 100.0 - (100.0 / (1.0 + avg_gain / (avg_loss + 1e-12)))

    for i in range(period, len(deltas)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
        rs = avg_gain / (avg_loss + 1e-12)
        out[i + 1] = 100.0 - (100.0 / (1.0 + rs))

    return out


def _macd(close: np.ndarray,
          fast: int = 12, slow: int = 26, signal: int = 9
          ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """MACD line, signal line, histogram."""
    ema_fast = _ema(close, fast)
    ema_slow = _ema(close, slow)
    macd_line = ema_fast - ema_slow
    signal_line = _ema(macd_line[~np.isnan(macd_line)], signal)
    # Pad signal_line back to original length
    pad = len(macd_line) - len(signal_line)
    signal_padded = np.concatenate([np.full(pad, np.nan), signal_line])
    histogram = macd_line - signal_padded
    return macd_line, signal_padded, histogram


def _bollinger_bands(close: np.ndarray, period: int = 20, std_dev: float = 2.0
                     ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Returns (upper, middle, lower) Bollinger Bands."""
    middle = _sma(close, period)
    std = np.full_like(close, np.nan, dtype=float)
    for i in range(period - 1, len(close)):
        std[i] = np.std(close[i - period + 1:i + 1], ddof=0)
    upper = middle + std_dev * std
    lower = middle - std_dev * std
    return upper, middle, lower


def _vwap(high: np.ndarray, low: np.ndarray, close: np.ndarray,
          volume: np.ndarray) -> np.ndarray:
    """
    Cumulative VWAP. In a real intraday context this resets each day;
    for daily bars we compute a rolling 5-day VWAP as a proxy.
    """
    tp = (high + low + close) / 3.0
    # Rolling 5-day VWAP (approximation for daily bars)
    period = min(5, len(close))
    out = np.full_like(close, np.nan, dtype=float)
    for i in range(period - 1, len(close)):
        window_tp = tp[i - period + 1:i + 1]
        window_vol = volume[i - period + 1:i + 1]
        vol_sum = np.sum(window_vol)
        if vol_sum > 0:
            out[i] = np.sum(window_tp * window_vol) / vol_sum
        else:
            out[i] = close[i]
    return out


# ---------------------------------------------------------------------------
# PatternDetector
# ---------------------------------------------------------------------------
class PatternDetector:
    """
    Scans a batch of tickers for BREAKOUT_LONG and MEAN_REVERSION_LONG
    patterns. Designed to run every 5 minutes during market hours.

    Usage:
        detector = PatternDetector(config)
        patterns = detector.scan(
            bars_cache=multi_bars,          # {symbol: [bar_dicts]}
            watchlist=["AAPL", "NVDA", ...],
            earnings_intel=earnings_obj,    # optional EarningsIntelligence
            news_intel=news_obj,            # optional NewsIntelligence
        )
        for p in patterns:
            logger.info(p)
    """

    # Minimum bars required for any pattern (need 26 for MACD slow EMA)
    MIN_BARS = 30

    # ── Breakout thresholds ──
    BREAKOUT_LOOKBACK       = 20       # 20-day high
    BREAKOUT_VOL_RATIO_MIN  = 1.5      # volume >= 1.5× average
    BREAKOUT_RSI_LOW        = 55.0     # RSI floor
    BREAKOUT_RSI_HIGH       = 75.0     # RSI ceiling
    BREAKOUT_RSI_SWEET_LOW  = 60.0     # sweet-spot range for confidence boost
    BREAKOUT_RSI_SWEET_HIGH = 70.0

    # ── Mean reversion thresholds ──
    MR_BB_PERIOD            = 20       # Bollinger Band period
    MR_BB_STD               = 2.0      # standard deviations
    MR_RSI_MAX              = 30.0     # oversold ceiling
    MR_RSI_DEEP             = 25.0     # deeply oversold (confidence boost)
    MR_NEWS_WINDOW_HOURS    = 48       # negative-catalyst lookback

    def __init__(self, config=None):
        self.config = config

        # Allow config overrides for thresholds
        if config is not None:
            try:
                pd_cfg = config.get("pattern_detector") or {}
                if isinstance(pd_cfg, dict):
                    self.BREAKOUT_VOL_RATIO_MIN = float(
                        pd_cfg.get("breakout_vol_ratio", self.BREAKOUT_VOL_RATIO_MIN))
                    self.BREAKOUT_RSI_LOW = float(
                        pd_cfg.get("breakout_rsi_low", self.BREAKOUT_RSI_LOW))
                    self.BREAKOUT_RSI_HIGH = float(
                        pd_cfg.get("breakout_rsi_high", self.BREAKOUT_RSI_HIGH))
                    self.MR_RSI_MAX = float(
                        pd_cfg.get("mr_rsi_max", self.MR_RSI_MAX))
            except Exception:
                pass

        # Stats
        self._scan_count = 0
        self._total_patterns = 0
        self._last_scan_time = None
        self._last_scan_duration_ms = 0

        logger.info(
            f"PatternDetector initialized | "
            f"breakout_vol>={self.BREAKOUT_VOL_RATIO_MIN}x | "
            f"breakout_rsi={self.BREAKOUT_RSI_LOW}-{self.BREAKOUT_RSI_HIGH} | "
            f"mr_rsi<={self.MR_RSI_MAX} | "
            f"pandas_ta={'yes' if HAS_PANDAS_TA else 'builtin'}"
        )

    # -----------------------------------------------------------------------
    # Bar data -> numpy arrays
    # -----------------------------------------------------------------------
    @staticmethod
    def _bars_to_arrays(bars: List[Dict]) -> Optional[Dict[str, np.ndarray]]:
        """
        Convert AlphaBot's bar list (list of dicts with keys o/h/l/c/v or
        open/high/low/close/volume) into numpy arrays.

        Returns None if the data is insufficient or malformed.
        """
        if not bars or len(bars) < PatternDetector.MIN_BARS:
            return None

        try:
            # Alpaca bar format uses short keys: o, h, l, c, v
            # Some formats use long keys: open, high, low, close, volume
            def _get(bar, short, long, default=0.0):
                val = bar.get(short)
                if val is None:
                    val = bar.get(long, default)
                return float(val)

            opens  = np.array([_get(b, "o", "open")   for b in bars], dtype=float)
            highs  = np.array([_get(b, "h", "high")   for b in bars], dtype=float)
            lows   = np.array([_get(b, "l", "low")    for b in bars], dtype=float)
            closes = np.array([_get(b, "c", "close")  for b in bars], dtype=float)
            volumes = np.array([_get(b, "v", "volume") for b in bars], dtype=float)

            # Basic sanity: no zero closes, no all-NaN
            if np.any(closes <= 0) or np.all(np.isnan(closes)):
                return None

            return {
                "open": opens, "high": highs, "low": lows,
                "close": closes, "volume": volumes,
            }
        except Exception as e:
            logger.debug(f"Bar conversion failed: {e}")
            return None

    # -----------------------------------------------------------------------
    # Indicator computation (pandas-ta with numpy fallback)
    # -----------------------------------------------------------------------
    @staticmethod
    def _compute_indicators(arrays: Dict[str, np.ndarray]) -> Optional[Dict[str, Any]]:
        """
        Compute all indicators needed for both pattern types.

        Returns a dict of indicator arrays/values, or None on failure.
        """
        close = arrays["close"]
        high = arrays["high"]
        low = arrays["low"]
        volume = arrays["volume"]
        n = len(close)

        try:
            if HAS_PANDAS_TA and HAS_PANDAS:
                # Use pandas-ta for accuracy
                df = pd.DataFrame({
                    "open": arrays["open"], "high": high,
                    "low": low, "close": close, "volume": volume,
                })
                rsi_s = df.ta.rsi(length=14)
                macd_df = df.ta.macd(fast=12, slow=26, signal=9)
                bb_df = df.ta.bbands(length=20, std=2.0)

                rsi_arr = rsi_s.values if rsi_s is not None else _rsi(close)

                if macd_df is not None and not macd_df.empty:
                    cols = macd_df.columns.tolist()
                    macd_line = macd_df.iloc[:, 0].values
                    macd_hist = macd_df.iloc[:, 1].values
                    macd_signal = macd_df.iloc[:, 2].values
                else:
                    macd_line, macd_signal, macd_hist = _macd(close)

                if bb_df is not None and not bb_df.empty:
                    bb_lower = bb_df.iloc[:, 0].values
                    bb_mid = bb_df.iloc[:, 1].values
                    bb_upper = bb_df.iloc[:, 2].values
                else:
                    bb_upper, bb_mid, bb_lower = _bollinger_bands(close)

            else:
                # Pure numpy fallback
                rsi_arr = _rsi(close)
                macd_line, macd_signal, macd_hist = _macd(close)
                bb_upper, bb_mid, bb_lower = _bollinger_bands(close)

            # VWAP (always use our rolling implementation for daily bars)
            vwap_arr = _vwap(high, low, close, volume)

            # 20-day high
            high_20 = np.full_like(close, np.nan)
            for i in range(19, n):
                high_20[i] = np.max(high[i - 19:i + 1])

            # 20-day average volume
            avg_vol_20 = _sma(volume, 20)

            return {
                "rsi":         rsi_arr,
                "macd_line":   macd_line,
                "macd_signal": macd_signal,
                "macd_hist":   macd_hist,
                "bb_upper":    bb_upper,
                "bb_mid":      bb_mid,
                "bb_lower":    bb_lower,
                "vwap":        vwap_arr,
                "high_20":     high_20,
                "avg_vol_20":  avg_vol_20,
                "close":       close,
                "high":        high,
                "low":         low,
                "open":        arrays["open"],
                "volume":      volume,
            }

        except Exception as e:
            logger.warning(f"Indicator computation failed: {e}")
            return None

    # -----------------------------------------------------------------------
    # News / earnings catalyst check
    # -----------------------------------------------------------------------
    @staticmethod
    def _has_negative_catalyst(
        ticker: str,
        earnings_intel=None,
        news_intel=None,
    ) -> bool:
        """
        Check if the ticker has had a negative earnings event or strongly
        negative news in the last 48 hours.

        Returns True if a negative catalyst exists (mean reversion should
        be avoided), False if clear.
        """
        # Check earnings
        if earnings_intel is not None:
            try:
                status = earnings_intel.get_earnings_status(ticker)
                # Earnings risk window (within 3 days) — skip mean reversion
                if status.get("earnings_risk", False):
                    return True
                # Recent filing flag
                if status.get("filing_flag", False):
                    return True
                # Strong miss in last 5 days
                signal = status.get("signal", "UNKNOWN")
                if signal in ("MISS_STRONG", "MISS_MILD"):
                    last_date = status.get("last_earnings_date")
                    if last_date:
                        try:
                            ld = datetime.strptime(str(last_date)[:10], "%Y-%m-%d")
                            if (datetime.now() - ld).total_seconds() < 48 * 3600:
                                return True
                        except Exception:
                            pass
            except Exception as e:
                logger.debug(f"Earnings check failed for {ticker}: {e}")

        # Check news sentiment
        if news_intel is not None:
            try:
                sent = news_intel.get_ticker_sentiment(ticker)
                score = sent.get("score", 0.0)
                count = sent.get("headline_count", 0)
                # Strongly negative news with enough headlines
                if count >= 3 and score <= -0.30:
                    return True
            except Exception as e:
                logger.debug(f"News check failed for {ticker}: {e}")

        return False

    # -----------------------------------------------------------------------
    # Pattern detection: BREAKOUT_LONG
    # -----------------------------------------------------------------------
    def _detect_breakout(
        self,
        ticker: str,
        ind: Dict[str, Any],
    ) -> Optional[PatternSignal]:
        """
        Check the most recent bar for a momentum breakout pattern.

        Criteria (all must be true):
          1. Close > 20-day high (of the prior 20 bars, not including today)
          2. Volume >= 1.5× 20-day average volume
          3. RSI between 55-75
          4. MACD histogram turning positive (current > 0 and > previous)
          5. Close > VWAP

        Returns PatternSignal or None.
        """
        n = len(ind["close"])
        if n < self.MIN_BARS:
            return None

        # Current bar values (index -1)
        close    = ind["close"][-1]
        volume   = ind["volume"][-1]
        high_20  = ind["high_20"][-2] if n > 20 else None   # Prior bar's 20-day high
        avg_vol  = ind["avg_vol_20"][-1]
        rsi      = ind["rsi"][-1]
        hist_now = ind["macd_hist"][-1]
        hist_prev = ind["macd_hist"][-2] if n > 1 else None
        vwap     = ind["vwap"][-1]

        # Guard NaN values
        if any(v is None or (isinstance(v, float) and np.isnan(v))
               for v in [close, volume, high_20, avg_vol, rsi, hist_now, hist_prev, vwap]):
            return None

        # ── Criterion checks ──

        # 1. Close above 20-day high
        if close <= high_20:
            return None

        # 2. Volume >= 1.5× average
        if avg_vol <= 0:
            return None
        vol_ratio = volume / avg_vol
        if vol_ratio < self.BREAKOUT_VOL_RATIO_MIN:
            return None

        # 3. RSI in sweet zone
        if rsi < self.BREAKOUT_RSI_LOW or rsi > self.BREAKOUT_RSI_HIGH:
            return None

        # 4. MACD histogram turning positive
        if hist_now <= 0:
            return None
        if hist_now <= hist_prev:
            # Histogram not accelerating — still allow if it just crossed zero
            if hist_prev >= 0:
                return None  # Was already positive and decelerating

        # 5. Close above VWAP
        if close <= vwap:
            return None

        # ── All criteria met — compute confidence ──
        confidence = 50  # base

        # Volume ratio boost: 1.5× = base, 2× = +10, 3× = +15
        if vol_ratio >= 3.0:
            confidence += 15
        elif vol_ratio >= 2.0:
            confidence += 10
        elif vol_ratio >= 1.7:
            confidence += 5

        # RSI sweet spot
        if self.BREAKOUT_RSI_SWEET_LOW <= rsi <= self.BREAKOUT_RSI_SWEET_HIGH:
            confidence += 10
        elif rsi < self.BREAKOUT_RSI_SWEET_LOW:
            confidence += 3  # Slightly early but still strong
        # RSI > 70 already filtered out, but close to 75 gets no boost

        # Breakout margin: how far above the 20-day high
        breakout_margin_pct = (close - high_20) / high_20 * 100.0
        if breakout_margin_pct >= 3.0:
            confidence += 10
        elif breakout_margin_pct >= 1.5:
            confidence += 7
        elif breakout_margin_pct >= 0.5:
            confidence += 3

        # MACD histogram acceleration (magnitude)
        hist_accel = hist_now - hist_prev
        if hist_accel > 0.1:
            confidence += 8
        elif hist_accel > 0.02:
            confidence += 4

        # VWAP distance (further above = stronger)
        vwap_pct = (close - vwap) / vwap * 100.0 if vwap > 0 else 0
        if vwap_pct >= 1.5:
            confidence += 5
        elif vwap_pct >= 0.5:
            confidence += 2

        confidence = max(0, min(100, confidence))

        # ── Entry and invalidation ──
        entry_price = close  # enter at current close
        # Invalidation: below the prior 20-day high (the breakout level)
        # with a small buffer (0.5%) to avoid noise whipsaws
        invalidation = high_20 * 0.995

        details = {
            "breakout_margin_pct": round(breakout_margin_pct, 2),
            "volume_ratio":        round(vol_ratio, 2),
            "rsi":                 round(rsi, 2),
            "macd_histogram":      round(hist_now, 4),
            "macd_hist_prev":      round(hist_prev, 4),
            "macd_hist_accel":     round(hist_accel, 4),
            "vwap":                round(vwap, 4),
            "vwap_distance_pct":   round(vwap_pct, 2),
            "high_20":             round(high_20, 4),
            "close":               round(close, 4),
        }

        return PatternSignal(
            ticker=ticker,
            pattern_type="BREAKOUT_LONG",
            confidence=confidence,
            entry_price_suggested=round(entry_price, 4),
            invalidation_level=round(invalidation, 4),
            detected_at=datetime.utcnow().isoformat(timespec="seconds") + "Z",
            details=details,
        )

    # -----------------------------------------------------------------------
    # Pattern detection: MEAN_REVERSION_LONG
    # -----------------------------------------------------------------------
    def _detect_mean_reversion(
        self,
        ticker: str,
        ind: Dict[str, Any],
        earnings_intel=None,
        news_intel=None,
    ) -> Optional[PatternSignal]:
        """
        Check the most recent bar for a mean-reversion bounce setup.

        Criteria (all must be true):
          1. Close <= lower Bollinger Band (20-period, 2σ)
          2. RSI <= 30
          3. Volume declining on the down move (volume < avg_vol_20)
          4. No negative earnings/news catalyst in last 48h

        Returns PatternSignal or None.
        """
        n = len(ind["close"])
        if n < self.MIN_BARS:
            return None

        close     = ind["close"][-1]
        bb_lower  = ind["bb_lower"][-1]
        bb_mid    = ind["bb_mid"][-1]
        rsi       = ind["rsi"][-1]
        volume    = ind["volume"][-1]
        avg_vol   = ind["avg_vol_20"][-1]
        low       = ind["low"][-1]

        # Guard NaN
        if any(v is None or (isinstance(v, float) and np.isnan(v))
               for v in [close, bb_lower, bb_mid, rsi, volume, avg_vol]):
            return None

        # ── Criterion checks ──

        # 1. Close at or below lower Bollinger Band
        if close > bb_lower:
            return None

        # 2. RSI oversold
        if rsi > self.MR_RSI_MAX:
            return None

        # 3. Volume declining (exhaustion) — current volume below 20-day average
        if avg_vol <= 0:
            return None
        vol_ratio = volume / avg_vol
        if vol_ratio >= 1.0:
            # Volume is not declining — this isn't exhaustion, it's capitulation
            # We allow up to 1.0× (at average), reject above
            return None

        # 4. No negative catalyst
        if self._has_negative_catalyst(ticker, earnings_intel, news_intel):
            logger.info(f"  [{ticker}] Mean reversion blocked: negative catalyst detected")
            return None

        # ── All criteria met — compute confidence ──
        confidence = 50  # base

        # Deeply oversold RSI boost
        if rsi <= 20:
            confidence += 15
        elif rsi <= self.MR_RSI_DEEP:
            confidence += 10
        elif rsi <= 28:
            confidence += 5

        # Distance below BB (further below = more stretched = higher reversion odds)
        bb_distance_pct = (bb_lower - close) / bb_lower * 100.0 if bb_lower > 0 else 0
        if bb_distance_pct >= 3.0:
            confidence += 12
        elif bb_distance_pct >= 1.5:
            confidence += 8
        elif bb_distance_pct >= 0.5:
            confidence += 4

        # Volume exhaustion (lower volume = more confidence the selling is drying up)
        if vol_ratio <= 0.4:
            confidence += 10
        elif vol_ratio <= 0.6:
            confidence += 7
        elif vol_ratio <= 0.8:
            confidence += 3

        # Lower wick signal: if the low is significantly below close,
        # buyers are stepping in (bullish hammer-like candle)
        if low < close:
            wick_pct = (close - low) / close * 100.0
            if wick_pct >= 2.0:
                confidence += 8
            elif wick_pct >= 1.0:
                confidence += 4

        # Check if we're also near a round-number support level
        # (psychological support at $10, $20, $50, $100, etc.)
        round_levels = [10, 20, 25, 50, 75, 100, 150, 200, 250, 300, 500]
        for lvl in round_levels:
            if abs(close - lvl) / lvl <= 0.02:  # within 2% of round number
                confidence += 3
                break

        confidence = max(0, min(100, confidence))

        # ── Entry and invalidation ──
        entry_price = close  # enter at current close (the stretched price)

        # Invalidation: below the recent low with a 1% buffer
        # If the price continues lower despite being oversold, the thesis is wrong
        recent_low = np.min(ind["low"][-5:])  # 5-bar low
        invalidation = recent_low * 0.99      # 1% below

        details = {
            "rsi":                  round(rsi, 2),
            "bb_lower":             round(bb_lower, 4),
            "bb_mid":               round(bb_mid, 4),
            "bb_distance_pct":      round(bb_distance_pct, 2),
            "volume_ratio_to_avg":  round(vol_ratio, 2),
            "close":                round(close, 4),
            "recent_5bar_low":      round(recent_low, 4),
            "target_bb_mid":        round(bb_mid, 4),
        }

        return PatternSignal(
            ticker=ticker,
            pattern_type="MEAN_REVERSION_LONG",
            confidence=confidence,
            entry_price_suggested=round(entry_price, 4),
            invalidation_level=round(invalidation, 4),
            detected_at=datetime.utcnow().isoformat(timespec="seconds") + "Z",
            details=details,
        )

    # -----------------------------------------------------------------------
    # Batch scanner (main public API)
    # -----------------------------------------------------------------------
    def scan(
        self,
        bars_cache: Dict[str, List[Dict]],
        watchlist: Optional[List[str]] = None,
        earnings_intel=None,
        news_intel=None,
    ) -> List[PatternSignal]:
        """
        Scan a batch of tickers for breakout and mean-reversion patterns.

        Parameters
        ----------
        bars_cache       : {symbol: [bar_dicts]} from TradingEngine._refresh_data()
        watchlist        : list of symbols to scan (defaults to all keys in bars_cache)
        earnings_intel   : optional EarningsIntelligence for catalyst checking
        news_intel       : optional NewsIntelligence for catalyst checking

        Returns
        -------
        List of PatternSignal objects, sorted by confidence (highest first).
        """
        if not HAS_NUMPY:
            logger.error("PatternDetector.scan: numpy not available")
            return []

        t0 = time.monotonic()
        symbols = watchlist if watchlist else list(bars_cache.keys())
        patterns: List[PatternSignal] = []
        scanned = 0
        skipped = 0

        for ticker in symbols:
            bars = bars_cache.get(ticker)
            if not bars:
                skipped += 1
                continue

            # Convert to arrays
            arrays = self._bars_to_arrays(bars)
            if arrays is None:
                skipped += 1
                continue

            # Compute indicators once per ticker
            ind = self._compute_indicators(arrays)
            if ind is None:
                skipped += 1
                continue

            scanned += 1

            # Check breakout
            try:
                bp = self._detect_breakout(ticker, ind)
                if bp:
                    patterns.append(bp)
            except Exception as e:
                logger.debug(f"Breakout detection error for {ticker}: {e}")

            # Check mean reversion
            try:
                mr = self._detect_mean_reversion(
                    ticker, ind,
                    earnings_intel=earnings_intel,
                    news_intel=news_intel,
                )
                if mr:
                    patterns.append(mr)
            except Exception as e:
                logger.debug(f"Mean reversion detection error for {ticker}: {e}")

        # Sort by confidence descending
        patterns.sort(key=lambda p: p.confidence, reverse=True)

        elapsed_ms = int((time.monotonic() - t0) * 1000)
        self._scan_count += 1
        self._total_patterns += len(patterns)
        self._last_scan_time = datetime.utcnow()
        self._last_scan_duration_ms = elapsed_ms

        # Log results
        breakouts = [p for p in patterns if p.pattern_type == "BREAKOUT_LONG"]
        reversions = [p for p in patterns if p.pattern_type == "MEAN_REVERSION_LONG"]

        logger.info(
            f"PatternDetector scan #{self._scan_count} | "
            f"{scanned} scanned, {skipped} skipped | "
            f"{len(patterns)} patterns found "
            f"({len(breakouts)} breakout, {len(reversions)} reversion) | "
            f"{elapsed_ms}ms"
        )
        for p in patterns:
            logger.info(
                f"  PATTERN {p.pattern_type:<22} {p.ticker:<6} | "
                f"conf={p.confidence:>3} | "
                f"entry=${p.entry_price_suggested:<9.2f} | "
                f"stop=${p.invalidation_level:<9.2f} | "
                f"R:R={p.risk_reward_ratio}"
            )

        return patterns

    # -----------------------------------------------------------------------
    # Summary / stats
    # -----------------------------------------------------------------------
    def get_stats(self) -> dict:
        return {
            "total_scans":         self._scan_count,
            "total_patterns":      self._total_patterns,
            "last_scan_time":      (self._last_scan_time.isoformat()
                                    if self._last_scan_time else None),
            "last_scan_ms":        self._last_scan_duration_ms,
            "using_pandas_ta":     HAS_PANDAS_TA,
        }

    def summary_table(self, patterns: List[PatternSignal]) -> str:
        """Format a compact table of detected patterns for logging."""
        if not patterns:
            return "PatternDetector: no patterns detected."
        header = (
            f"{'TICKER':<8} {'PATTERN':<24} {'CONF':>5} "
            f"{'ENTRY':>10} {'STOP':>10} {'R:R':>5}"
        )
        sep = "─" * len(header)
        rows = [header, sep]
        for p in patterns:
            rows.append(
                f"{p.ticker:<8} {p.pattern_type:<24} {p.confidence:>5} "
                f"${p.entry_price_suggested:>9.2f} "
                f"${p.invalidation_level:>9.2f} "
                f"{p.risk_reward_ratio:>5.1f}"
            )
        return "\n".join(rows)


# ---------------------------------------------------------------------------
# Standalone self-test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stdout,
    )

    logger.info("=== PatternDetector — standalone test ===")
    logger.info(f"numpy:     {HAS_NUMPY}")
    logger.info(f"pandas:    {HAS_PANDAS}")
    logger.info(f"pandas-ta: {HAS_PANDAS_TA}")

    # Generate synthetic bar data
    np.random.seed(42)

    def _make_bars(n=60, trend="up", volatility=0.02, base_price=100.0, base_vol=1_000_000):
        """Generate synthetic OHLCV bars."""
        bars = []
        price = base_price
        for i in range(n):
            if trend == "up":
                drift = 0.003
            elif trend == "down":
                drift = -0.004
            else:
                drift = 0.0
            ret = drift + volatility * np.random.randn()
            price *= (1 + ret)
            o = price * (1 + 0.002 * np.random.randn())
            h = max(price, o) * (1 + abs(0.005 * np.random.randn()))
            l = min(price, o) * (1 - abs(0.005 * np.random.randn()))
            c = price
            # Volume: add surge near end for breakout test
            vol = base_vol * (1 + 0.3 * np.random.randn())
            if trend == "up" and i >= n - 3:
                vol *= 2.5  # volume surge
            if trend == "down" and i >= n - 5:
                vol *= 0.5  # volume exhaustion
            bars.append({"o": o, "h": h, "l": l, "c": c, "v": max(vol, 1000)})
        return bars

    # Test case 1: Uptrending stock (potential breakout)
    logger.info("\n--- Generating test data ---")
    bars_cache = {
        "NVDA": _make_bars(60, trend="up", base_price=130, volatility=0.025),
        "AAPL": _make_bars(60, trend="flat", base_price=175, volatility=0.012),
        "COIN": _make_bars(60, trend="down", base_price=220, volatility=0.035),
        "TSLA": _make_bars(60, trend="down", base_price=180, volatility=0.04),
        "SPY":  _make_bars(60, trend="flat", base_price=520, volatility=0.008),
    }

    detector = PatternDetector()
    patterns = detector.scan(
        bars_cache=bars_cache,
        watchlist=["NVDA", "AAPL", "COIN", "TSLA", "SPY"],
    )

    logger.info(f"\n{detector.summary_table(patterns)}")

    # Test indicator computation directly
    logger.info("\n--- Indicator spot check (NVDA) ---")
    arrays = detector._bars_to_arrays(bars_cache["NVDA"])
    if arrays:
        ind = detector._compute_indicators(arrays)
        if ind:
            logger.info(f"  RSI[-1]:      {ind['rsi'][-1]:.2f}")
            logger.info(f"  MACD hist[-1]: {ind['macd_hist'][-1]:.4f}")
            logger.info(f"  BB lower[-1]: {ind['bb_lower'][-1]:.2f}")
            logger.info(f"  BB mid[-1]:   {ind['bb_mid'][-1]:.2f}")
            logger.info(f"  BB upper[-1]: {ind['bb_upper'][-1]:.2f}")
            logger.info(f"  VWAP[-1]:     {ind['vwap'][-1]:.2f}")
            logger.info(f"  20d high[-1]: {ind['high_20'][-1]:.2f}")
            logger.info(f"  Vol ratio:    {ind['volume'][-1] / ind['avg_vol_20'][-1]:.2f}x")

    logger.info(f"\nStats: {detector.get_stats()}")
    logger.info("=== Test complete ===")
