@echo off
TITLE AlphaBot Reinstaller
color 0E

echo.
echo  ============================================
echo   AlphaBot v1.3.0 - Clean Reinstall
echo  ============================================
echo.

REM ── Work out where this script lives ─────────────────────────────────────────
set "BAT_DIR=%~dp0"
if "%BAT_DIR:~-1%"=="\" set "BAT_DIR=%BAT_DIR:~0,-1%"

REM ── Source = alphabot folder sitting next to this bat ─────────────────────────
set "SOURCE=%BAT_DIR%\alphabot"

REM ── Safety check: make sure the source files actually exist ───────────────────
if not exist "%SOURCE%\bot.py" (
    echo.
    echo  [ERROR] Cannot find alphabot\bot.py next to this script.
    echo  Make sure REINSTALL.bat and the alphabot folder are in the same place.
    echo  Current location: %BAT_DIR%
    echo.
    pause
    exit /b 1
)

REM ── Destination = Desktop\alphabot ───────────────────────────────────────────
set "DEST=%USERPROFILE%\Desktop\alphabot"
echo  Source:      %SOURCE%
echo  Destination: %DEST%
echo.
echo  This will install AlphaBot to your Desktop.
echo  Your config.json, trades, models and logs will be kept.
echo.

set /p CONFIRM= Type YES to continue (anything else cancels): 
if /i not "%CONFIRM%"=="YES" (
    echo  Cancelled.
    pause
    exit /b 0
)

REM ── Make sure destination exists ──────────────────────────────────────────────
if not exist "%DEST%" mkdir "%DEST%"

REM ── Save config.json to temp ──────────────────────────────────────────────────
set "CFG_TMP=%TEMP%\ab_config_%RANDOM%.json"
if exist "%DEST%\config.json" (
    copy /y "%DEST%\config.json" "%CFG_TMP%" >nul
    echo  [OK] config.json saved
)

REM ── Save trades, models, logs to temp ────────────────────────────────────────
set "SAVE_TMP=%TEMP%\ab_save_%RANDOM%"
mkdir "%SAVE_TMP%"
for %%D in (trades models logs) do (
    if exist "%DEST%\%%D\" (
        xcopy /e /i /q "%DEST%\%%D" "%SAVE_TMP%\%%D" >nul
        echo  [OK] Saved %%D\
    )
)

REM ── Copy fresh files FROM source TO destination ───────────────────────────────
echo.
echo  Copying fresh files...
robocopy "%SOURCE%" "%DEST%" /e /purge ^
    /xd "%DEST%\venv" "%DEST%\backups" "%DEST%\trades" "%DEST%\models" "%DEST%\logs" ^
    /xf "%DEST%\config.json" ^
    /njh /njs /nc /ns /np
echo  [OK] Fresh files installed

REM ── Restore config.json ───────────────────────────────────────────────────────
if exist "%CFG_TMP%" (
    copy /y "%CFG_TMP%" "%DEST%\config.json" >nul
    del "%CFG_TMP%" >nul 2>&1
    echo  [OK] config.json restored
)

REM ── Restore trades, models, logs ─────────────────────────────────────────────
for %%D in (trades models logs) do (
    if exist "%SAVE_TMP%\%%D\" (
        if not exist "%DEST%\%%D\" mkdir "%DEST%\%%D"
        xcopy /e /i /q /y "%SAVE_TMP%\%%D" "%DEST%\%%D" >nul
        echo  [OK] Restored %%D\
    )
)
rmdir /s /q "%SAVE_TMP%" >nul 2>&1

REM ── Install Python dependencies ───────────────────────────────────────────────
cd /d "%DEST%"
if not exist "venv\" (
    echo.
    echo  Installing Python dependencies (1-2 min)...
    python --version >nul 2>&1
    if errorlevel 1 (
        echo  [ERROR] Python not found. Install from https://python.org
        pause
        exit /b 1
    )
    python -m venv venv
    call venv\Scripts\activate.bat
    pip install --upgrade pip -q
    pip install -r requirements.txt -q
    echo  [OK] Dependencies installed
) else (
    call venv\Scripts\activate.bat
    echo  [OK] Using existing venv
)

REM ── Launch ────────────────────────────────────────────────────────────────────
echo.
echo  ============================================
echo   Done! Launching AlphaBot...
echo  ============================================
echo.
timeout /t 2 /nobreak >nul
python menu.py

exit /b 0
