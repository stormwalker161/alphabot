"""
Live terminal dashboard for AlphaBot
Shows real-time account status, positions, and signals
"""

import threading
import time
import os
import json
from datetime import datetime


class Dashboard:
    def __init__(self, engine):
        self.engine = engine
        self.running = False
        self._thread = None

    def start(self):
        self.running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self.running = False

    def _loop(self):
        while self.running:
            try:
                self._render()
            except Exception:
                pass
            time.sleep(30)

    def _render(self):
        os.system("cls" if os.name == "nt" else "clear")
        broker = self.engine.broker
        account = broker.get_account()
        positions = broker.get_positions()
        trade_history = self.engine.trade_history

        equity = float(account.get("equity", 0))
        bp = float(account.get("buying_power", 0))
        closed = [t for t in trade_history if t.get("status") == "closed"]
        wins = [t for t in closed if t.get("return_pct", 0) > 0]
        win_rate = len(wins) / len(closed) if closed else 0
        total_pnl = sum(t.get("pnl", 0) for t in closed)

        mode = "PAPER" if self.engine.paper else "LIVE"
        print(f"""
+==================================================+
|  AlphaBot Dashboard  |  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  |  {mode}  |
+==================================================+

ACCOUNT
  Equity:       ${equity:>12,.2f}
  Buying Power: ${bp:>12,.2f}
  PnL (closed): ${total_pnl:>+12,.2f}

PERFORMANCE ({len(closed)} closed trades)
  Win Rate:     {win_rate:>11.1%}
  Total Trades: {len(closed):>11}
  Open Pos:     {len(positions):>11}

OPEN POSITIONS""")

        if positions:
            for p in positions:
                sym = p.get("symbol", "")
                qty = p.get("qty", 0)
                pl_pct = float(p.get("unrealized_plpc", 0)) * 100
                pl_usd = float(p.get("unrealized_pl", 0))
                price = float(p.get("current_price", 0))
                sign = "+" if pl_pct >= 0 else ""
                print(f"  {sym:<8} {qty:>6} shares @ ${price:>8.2f}  {sign}{pl_pct:.2f}%  ${pl_usd:+.2f}")
        else:
            print("  No open positions")

        print(f"\n  [ML Model: {'Trained' if self.engine.ml_engine.is_trained else 'Untrained'}]")
        print(f"  Press Ctrl+C to stop\n")
