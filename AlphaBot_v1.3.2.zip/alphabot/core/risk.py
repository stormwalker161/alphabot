"""
Risk Management System
Controls position sizing, drawdown limits, and portfolio exposure.
This is the most important module — it protects your capital.
"""

import logging
import json
import os
from datetime import datetime, date

logger = logging.getLogger("alphabot.risk")


class RiskManager:
    def __init__(self, config, broker):
        self.config = config
        self.broker = broker
        self.risk_cfg = config.get("risk") or {}
        self.daily_stats_path = "trades/daily_stats.json"
        self._load_daily_stats()

    def _load_daily_stats(self):
        today = str(date.today())
        if os.path.exists(self.daily_stats_path):
            with open(self.daily_stats_path) as f:
                data = json.load(f)
            if data.get("date") == today:
                self.daily_stats = data
                return
        self.daily_stats = {
            "date": today,
            "trades_taken": 0,
            "daily_pnl": 0.0,
            "max_drawdown_today": 0.0,
            "starting_equity": None
        }

    def _save_daily_stats(self):
        os.makedirs("trades", exist_ok=True)
        with open(self.daily_stats_path, "w") as f:
            json.dump(self.daily_stats, f, indent=2)

    def get_position_size(self, symbol, price, stop_price, account_equity):
        """
        Calculate position size using fixed fractional risk.
        Never risk more than risk_per_trade_pct of portfolio on a single trade.
        """
        risk_pct = self.risk_cfg.get("risk_per_trade_pct", 0.02)
        max_pos_pct = self.risk_cfg.get("max_position_pct", 0.05)

        dollar_risk = account_equity * risk_pct
        risk_per_share = abs(price - stop_price)

        if risk_per_share <= 0:
            return 0

        # Risk-based sizing
        risk_based_shares = int(dollar_risk / risk_per_share)

        # Cap at max position size
        max_shares = int((account_equity * max_pos_pct) / price)
        shares = min(risk_based_shares, max_shares)

        logger.info(f"{symbol}: risk_based={risk_based_shares}, max_allowed={max_shares}, "
                    f"final={shares} @ ${price:.2f} (stop: ${stop_price:.2f})")

        return max(1, shares)

    def get_stop_loss(self, price, atr_ratio=None):
        """Calculate stop loss price."""
        stop_pct = self.risk_cfg.get("stop_loss_pct", 0.05)
        if atr_ratio and atr_ratio > 0:
            # ATR-based stop: 2x ATR
            atr_stop = price * (1 - atr_ratio * 2)
            pct_stop = price * (1 - stop_pct)
            return max(atr_stop, pct_stop)  # Use the wider stop
        return price * (1 - stop_pct)

    def get_take_profit(self, price):
        """Calculate take profit price."""
        tp_pct = self.risk_cfg.get("take_profit_pct", 0.10)
        return price * (1 + tp_pct)

    def can_open_position(self, symbol):
        """Check if we're allowed to open a new position."""
        positions = self.broker.get_positions()
        open_count = len(positions)
        max_positions = self.risk_cfg.get("max_open_positions", 8)

        if open_count >= max_positions:
            logger.info(f"Max positions reached ({open_count}/{max_positions})")
            return False, f"Max positions {open_count}/{max_positions}"

        # Already in this symbol?
        for p in positions:
            if p.get("symbol") == symbol:
                return False, f"Already have position in {symbol}"

        # Check daily drawdown limit (3% daily max loss)
        account = self.broker.get_account()
        equity = float(account.get("equity", 0))
        if self.daily_stats.get("starting_equity") is None:
            self.daily_stats["starting_equity"] = equity
            self._save_daily_stats()

        start_equity = self.daily_stats.get("starting_equity", equity)
        daily_loss_pct = (equity - start_equity) / (start_equity + 1e-9)
        if daily_loss_pct < -0.03:
            logger.warning(f"Daily drawdown limit hit: {daily_loss_pct:.2%}")
            return False, f"Daily loss limit reached ({daily_loss_pct:.2%})"

        # Check total portfolio risk
        total_risk = self._calc_total_portfolio_risk(equity, positions)
        max_portfolio_risk = self.risk_cfg.get("max_portfolio_risk_pct", 0.20)
        if total_risk >= max_portfolio_risk:
            return False, f"Portfolio risk at max ({total_risk:.2%})"

        return True, "OK"

    def _calc_total_portfolio_risk(self, equity, positions):
        total_value = sum(abs(float(p.get("market_value", 0))) for p in positions)
        return total_value / (equity + 1e-9)

    def check_portfolio_health(self):
        """
        Periodic health check. Returns warnings and actions needed.
        """
        warnings = []
        actions = []

        account = self.broker.get_account()
        equity = float(account.get("equity", 0))
        buying_power = float(account.get("buying_power", 0))
        positions = self.broker.get_positions()

        # Check each position
        for pos in positions:
            symbol = pos.get("symbol")
            unrealized_pnl_pct = float(pos.get("unrealized_plpc", 0))

            # Emergency stop: position down more than 8%
            if unrealized_pnl_pct < -0.08:
                warnings.append(f"{symbol} emergency stop: {unrealized_pnl_pct:.2%}")
                actions.append({"action": "close", "symbol": symbol, "reason": "emergency_stop"})

            # Trailing profit protection: lock in gains if up >5%
            elif unrealized_pnl_pct > 0.05:
                avg_price = float(pos.get("avg_entry_price", 0))
                current = float(pos.get("current_price", 0))
                trailing_stop = current * (1 - self.risk_cfg.get("trailing_stop_pct", 0.03))
                if current < avg_price * 1.03:  # Gave back most of the gain
                    warnings.append(f"{symbol} trailing stop: {unrealized_pnl_pct:.2%}")
                    actions.append({"action": "close", "symbol": symbol, "reason": "trailing_stop"})

        # Buying power check
        if buying_power < equity * 0.1:
            warnings.append(f"Low buying power: ${buying_power:,.0f}")

        return warnings, actions

    def record_trade(self, symbol, side, qty, price, pnl=None):
        """Record a completed trade for stats."""
        self.daily_stats["trades_taken"] = self.daily_stats.get("trades_taken", 0) + 1
        if pnl:
            self.daily_stats["daily_pnl"] = self.daily_stats.get("daily_pnl", 0) + pnl
        self._save_daily_stats()

    def get_paper_to_live_readiness(self, trade_history):
        """
        Assess whether the bot is ready to switch from paper to live trading.
        Returns (ready: bool, report: dict)
        """
        cfg = self.config.get("trading") or {}
        min_days = cfg.get("paper_to_live_min_days", 30)
        min_sharpe = cfg.get("paper_to_live_min_sharpe", 1.0)
        min_winrate = cfg.get("paper_to_live_min_winrate", 0.52)

        if not trade_history:
            return False, {"reason": "No trade history"}

        # Calculate stats
        returns = [t.get("return_pct", 0) for t in trade_history if t.get("return_pct") is not None]
        wins = [r for r in returns if r > 0]
        win_rate = len(wins) / len(returns) if returns else 0

        import numpy as np
        arr = np.array(returns) if returns else np.array([0])
        sharpe = (arr.mean() / (arr.std() + 1e-9)) * (252 ** 0.5) if len(arr) > 1 else 0

        if trade_history:
            first_trade = trade_history[0].get("timestamp", "")
            try:
                first_date = datetime.fromisoformat(first_trade)
                days_trading = (datetime.now() - first_date).days
            except Exception:
                days_trading = 0
        else:
            days_trading = 0

        report = {
            "days_trading": days_trading,
            "total_trades": len(trade_history),
            "win_rate": win_rate,
            "sharpe_ratio": sharpe,
            "requirements": {
                "min_days": min_days,
                "min_sharpe": min_sharpe,
                "min_winrate": min_winrate
            },
            "checks": {
                "days_ok": days_trading >= min_days,
                "sharpe_ok": sharpe >= min_sharpe,
                "winrate_ok": win_rate >= min_winrate,
                "min_trades_ok": len(trade_history) >= 50
            }
        }

        ready = all(report["checks"].values())
        report["ready"] = ready
        report["reason"] = "All criteria met" if ready else ", ".join(
            k for k, v in report["checks"].items() if not v
        )

        return ready, report
