@echo off
TITLE AlphaBot AI Trading Bot
color 0A

echo.
echo  Starting AlphaBot...
echo.

REM Check for Python
python --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo  [ERROR] Python not found.
    echo  Please install Python 3.9+ from https://python.org
    echo  Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

REM Create virtual environment if it doesn't exist
IF NOT EXIST "venv\" (
    echo  First time setup - installing dependencies...
    echo  This will take about 1-2 minutes, please wait.
    echo.
    python -m venv venv
    call venv\Scripts\activate.bat
    pip install --upgrade pip -q
    pip install -r requirements.txt -q
    echo.
    echo  [OK] Setup complete!
    echo.
) ELSE (
    call venv\Scripts\activate.bat
)

REM Create config if missing
IF NOT EXIST "config.json" (
    python -c "from core.config import Config; Config()"
    echo  [OK] Default config.json created.
    echo  Opening config to add your API keys...
    timeout /t 2 /nobreak >nul
    notepad config.json
)

REM Launch the GUI menu
echo  Launching AlphaBot menu...
python menu.py

exit /b 0
