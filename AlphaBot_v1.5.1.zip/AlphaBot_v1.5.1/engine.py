"""
Trading Engine - Orchestrates the entire trading loop
Connects ML signals -> risk management -> order execution -> learning
"""

import time
import logging
import json
import os
from datetime import datetime, timedelta

from core.risk import RiskManager
from ml.ml_engine import MLEngine
from data.scanner import AutoScanner

# Intelligence layer (macro + earnings + sentiment). Optional - if the
# package isn't present the engine still runs with ML signals only.
try:
    from core.intelligence import IntelligenceHub
    HAS_INTEL = True
except Exception as _e:
    HAS_INTEL = False
    logging.getLogger("alphabot.engine").warning(
        f"IntelligenceHub unavailable, continuing without macro/earnings/sentiment: {_e}"
    )

# AIReasoning layer (LLM second-opinion for high-stakes trades). Optional.
try:
    from core.ai_reasoning import AIReasoning
    HAS_AI_REASONING = True
except Exception as _e:
    HAS_AI_REASONING = False
    logging.getLogger("alphabot.engine").warning(
        f"AIReasoning unavailable, continuing without LLM second-opinion: {_e}"
    )

logger = logging.getLogger("alphabot.engine")


class TradingEngine:
    def __init__(self, config, broker, paper=True):
        self.config = config
        self.broker = broker
        self.paper = paper
        self.running = False
        self._apply_mode(config)
        self.ml_engine = MLEngine(config)
        self.risk_manager = RiskManager(config, broker)
        self.watchlist = config.get("watchlist", [])
        self.check_interval = config.get("trading.check_interval_seconds", 30)
        self.open_buffer = config.get("trading.market_open_buffer_minutes", 15)
        self.close_buffer = config.get("trading.market_close_buffer_minutes", 30)
        self.trade_history = self._load_trade_history()
        self.scanner = AutoScanner(config)
        self.last_scan = None
        self.scan_interval_minutes = 30
        self.bars_cache = {}
        self.last_data_refresh = None
        os.makedirs("trades", exist_ok=True)
        os.makedirs("logs", exist_ok=True)

        # Intelligence hub: macro regime, earnings risk, sentiment.
        # Each layer is independently optional and degrades gracefully.
        if HAS_INTEL:
            try:
                self.intel = IntelligenceHub(config, watchlist=self.watchlist)
                self.intel.start()
            except Exception as e:
                logger.error(f"Could not start IntelligenceHub: {e}")
                self.intel = None
        else:
            self.intel = None

        # AIReasoning: LLM second-opinion for high-stakes trades. Gated to
        # only fire on STRONG_BUY/STRONG_SELL with positions >8% of equity.
        if HAS_AI_REASONING:
            try:
                self.ai_reasoning = AIReasoning(config)
            except Exception as e:
                logger.error(f"Could not initialize AIReasoning: {e}")
                self.ai_reasoning = None
        else:
            self.ai_reasoning = None

    def _load_trade_history(self):
        path = "trades/history.json"
        if os.path.exists(path):
            try:
                with open(path) as f:
                    return json.load(f)
            except Exception:
                pass
        return []

    def _save_trade_history(self):
        path = "trades/history.json"
        with open(path, "w") as f:
            json.dump(self.trade_history, f, indent=2, default=str)

    def _refresh_data(self):
        """Fetch latest bar data for watchlist."""
        logger.info(f"Refreshing market data for {len(self.watchlist)} symbols...")
        multi_bars = self.broker.get_multi_bars(
            self.watchlist, timeframe="1Day",
            limit=self.config.get("ml.lookback_days", 120)
        )
        self.bars_cache = multi_bars
        self.last_data_refresh = datetime.now()
        logger.info(f"Got data for {len(multi_bars)} symbols")
        return multi_bars

    def _maybe_retrain(self):
        """Retrain ML model if needed."""
        if self.ml_engine.needs_retrain():
            logger.info("ML model needs retrain, fetching training data...")
            multi_bars = self._refresh_data()
            success = self.ml_engine.train(multi_bars)
            if success:
                logger.info("ML model retrained successfully")
            else:
                logger.warning("ML retrain failed - using existing model or rule-based fallback")

    def _is_safe_to_trade(self):
        """Check market hours and safety conditions."""
        clock = self.broker.get_clock()
        if not clock:
            return False, "Cannot reach Alpaca API"
        if not clock.get("is_open", False):
            return False, "Market closed"

        try:
            from datetime import timezone
            next_close = datetime.fromisoformat(
                clock["next_close"].replace("Z", "+00:00")
            )  # keep timezone info
            now_utc = datetime.now(timezone.utc)
            mins_to_close = (next_close - now_utc).total_seconds() / 60
            if mins_to_close < self.close_buffer:
                return False, f"Too close to market close ({mins_to_close:.0f} min remaining)"
        except Exception:
            pass

        return True, "OK"

    def scan_for_signals(self):
        """Scan all watchlist symbols for trade signals."""
        signals = []

        # Refresh data if stale (>10 min)
        if (self.last_data_refresh is None or
                (datetime.now() - self.last_data_refresh).seconds > 600):
            self._refresh_data()

        for symbol in self.watchlist:
            bars = self.bars_cache.get(symbol, [])
            if len(bars) < 50:
                continue

            signal, confidence = self.ml_engine.predict(bars)

            # Macro regime can tighten or loosen the threshold (RISK_OFF -> +0.05)
            effective_threshold = self.ml_engine.confidence_threshold
            if self.intel is not None:
                try:
                    effective_threshold += self.intel.confidence_adjustment()
                except Exception:
                    pass

            if signal == "buy" and confidence >= effective_threshold:
                price = float(bars[-1].get("c", 0))
                atr_ratio = None
                try:
                    features = self.ml_engine.compute_features(bars)
                    atr_ratio = features.get("atr_ratio") if features else None
                except Exception:
                    pass

                signals.append({
                    "symbol": symbol,
                    "signal": signal,
                    "confidence": confidence,
                    "price": price,
                    "atr_ratio": atr_ratio
                })

        # Sort by confidence
        signals.sort(key=lambda x: x["confidence"], reverse=True)
        return signals

    def execute_signals(self, signals, account_equity):
        """Execute trade signals that pass risk checks."""
        executed = []

        for sig in signals[:3]:  # Max 3 new positions per cycle
            symbol = sig["symbol"]
            price = sig["price"]
            confidence = sig["confidence"]

            # Risk check
            can_trade, reason = self.risk_manager.can_open_position(symbol)
            if not can_trade:
                logger.info(f"Skipping {symbol}: {reason}")
                continue

            # Calculate levels
            stop_price = self.risk_manager.get_stop_loss(price, sig.get("atr_ratio"))
            take_profit = self.risk_manager.get_take_profit(price)
            shares = self.risk_manager.get_position_size(
                symbol, price, stop_price, account_equity
            )

            # Cascade through macro -> earnings -> sentiment. Any layer
            # returning 0 short-circuits and we skip the trade entirely.
            if self.intel is not None:
                try:
                    shares = self.intel.adjust_position_size(shares, symbol)
                except Exception as e:
                    logger.warning(f"Intel sizing failed for {symbol}: {e}")

            if shares < 1:
                logger.info(f"Skipping {symbol}: position size too small or intel veto")
                continue

            # AIReasoning second-opinion: only fires for high-stakes trades
            # (configurable: STRONG_BUY/STRONG_SELL + position >8% of equity).
            # The current ML signal is "buy" with no STRONG_ classification, so
            # we treat any high-confidence buy that exceeds the threshold as
            # eligible by tagging it STRONG_BUY for the gate check.
            if self.ai_reasoning is not None:
                try:
                    position_value = shares * price
                    # Map ML confidence to action label for AI gate
                    ai_action = "STRONG_BUY" if confidence >= 0.75 else "BUY"

                    # Build a minimal signal dict (we don't have full SignalEngine
                    # output yet — pass what we have)
                    ai_signal = {
                        "action": ai_action,
                        "composite_score": confidence * 100,
                        "dominant_direction": "bullish",
                        "direction_agreement": 3,
                        "technical_score": confidence * 100,
                        "momentum_score": 50,
                        "news_score": 50,
                        "social_score": 50,
                        "macro_score": 50,
                        "effective_weights": {
                            "technical": 0.35, "momentum": 0.25,
                            "news": 0.20, "social": 0.10, "macro": 0.10,
                        },
                    }

                    # Gather context from intelligence layers if available
                    news_headlines = []
                    social_summary = None
                    macro_context = None
                    if self.intel is not None:
                        try:
                            if self.intel.sentiment is not None:
                                soc = self.intel.sentiment.get_combined_score(symbol)
                                social_summary = soc
                                top = soc.get("top_news_headline", "")
                                if top:
                                    news_headlines.append(top)
                            if self.intel.macro is not None:
                                macro_context = self.intel.macro.get_macro_context()
                        except Exception:
                            pass

                    positions = self.broker.get_positions() or []

                    verdict = self.ai_reasoning.evaluate_trade(
                        ticker=symbol,
                        price=price,
                        signal=ai_signal,
                        position_value=position_value,
                        portfolio_equity=account_equity,
                        proposed_shares=shares,
                        news_headlines=news_headlines,
                        social_summary=social_summary,
                        macro_context=macro_context,
                        open_positions=positions,
                    )

                    if verdict["decision"] == "REJECT":
                        logger.info(f"AI REJECT {symbol}: {verdict['reason']}")
                        continue
                    if verdict["decision"] == "REDUCE_SIZE":
                        new_shares = int(shares * verdict["size_multiplier"])
                        logger.info(f"AI REDUCE {symbol}: {verdict['size_multiplier']}x "
                                    f"-> {new_shares} shares ({verdict['reason']})")
                        shares = new_shares
                        if shares < 1:
                            logger.info(f"Skipping {symbol}: AI reduced size below 1 share")
                            continue
                except Exception as e:
                    logger.warning(f"AIReasoning failed for {symbol}: {e}")

            logger.info(f"SIGNAL: {symbol} BUY {shares} @ ${price:.2f} | "
                        f"SL: ${stop_price:.2f} | TP: ${take_profit:.2f} | "
                        f"Confidence: {confidence:.2%}")

            # Submit bracket order
            order = self.broker.submit_order(
                symbol=symbol,
                qty=shares,
                side="buy",
                order_type="market",
                take_profit=take_profit,
                stop_loss=stop_price
            )

            if order:
                trade_record = {
                    "id": order.get("id"),
                    "symbol": symbol,
                    "side": "buy",
                    "qty": shares,
                    "entry_price": price,
                    "stop_loss": stop_price,
                    "take_profit": take_profit,
                    "confidence": confidence,
                    "timestamp": datetime.now().isoformat(),
                    "paper": self.paper,
                    "status": "open"
                }
                self.trade_history.append(trade_record)
                self._save_trade_history()
                executed.append(trade_record)
                logger.info(f"Opened position: {symbol} x{shares}")
                self.risk_manager.record_trade(symbol, "buy", shares, price)
            else:
                logger.warning(f"Order failed for {symbol}")

        return executed

    def check_and_manage_positions(self):
        """Check existing positions and manage exits."""
        warnings, actions = self.risk_manager.check_portfolio_health()

        for w in warnings:
            logger.warning(f"Risk alert: {w}")

        closed = []
        for action in actions:
            if action["action"] == "close":
                symbol = action["symbol"]
                logger.info(f"Closing {symbol}: {action['reason']}")
                result = self.broker.close_position(symbol)
                if result:
                    # Record exit and learn from it
                    self._record_exit(symbol, action["reason"])
                    closed.append(symbol)

        return closed

    def _record_exit(self, symbol, reason):
        """Record position exit and feed outcome to ML."""
        price = self.broker.get_latest_price(symbol)
        if not price:
            return

        # Find entry in history
        for trade in reversed(self.trade_history):
            if trade.get("symbol") == symbol and trade.get("status") == "open":
                trade["exit_price"] = price
                trade["exit_reason"] = reason
                trade["exit_timestamp"] = datetime.now().isoformat()
                entry = trade.get("entry_price", price)
                trade["return_pct"] = (price - entry) / entry
                trade["status"] = "closed"
                pnl = (price - entry) * trade.get("qty", 1)
                trade["pnl"] = pnl
                logger.info(f"Closed {symbol}: {trade['return_pct']:.2%} | PnL: ${pnl:.2f}")

                # Feed outcome to ML for future learning
                bars = self.bars_cache.get(symbol, [])
                if bars:
                    features = self.ml_engine.compute_features(bars)
                    if features:
                        self.ml_engine.learn_from_trade(
                            symbol, entry, price,
                            features, trade.get("signal", "buy")
                        )
                break

        self._save_trade_history()

    def _apply_mode(self, config):
        """Apply conservative or aggressive settings based on config."""
        aggressive = config.get("aggressive_mode.enabled", False)
        if aggressive:
            # Override ML and risk settings with aggressive values
            config.set("ml.confidence_threshold", config.get("aggressive_mode.confidence_threshold", 0.55))
            config.set("risk.take_profit_pct",    config.get("aggressive_mode.take_profit_pct", 0.05))
            config.set("risk.stop_loss_pct",      config.get("aggressive_mode.stop_loss_pct", 0.04))
            config.set("risk.trailing_stop_pct",  config.get("aggressive_mode.trailing_stop_pct", 0.02))
            config.set("risk.max_open_positions", config.get("aggressive_mode.max_open_positions", 12))
            config.set("risk.risk_per_trade_pct", config.get("aggressive_mode.risk_per_trade_pct", 0.03))
            logger.info("Mode: AGGRESSIVE - lower confidence threshold, faster exits, more positions")
        else:
            logger.info("Mode: CONSERVATIVE - high confidence threshold, 10% take profit, 5% stop loss")

    def get_mode_label(self):
        return "AGGRESSIVE" if self.config.get("aggressive_mode.enabled", False) else "CONSERVATIVE"

    def run(self):
        """Main trading loop."""
        self.running = True
        logger.info("Trading engine started")
        cycle = 0

        # Initial retrain check
        self._maybe_retrain()

        while self.running:
            cycle += 1
            try:
                # 1. Check if safe to trade
                safe, reason = self._is_safe_to_trade()
                if not safe:
                    logger.info(f"Not trading: {reason}. Next check in 30s...")
                    self._sleep(30)
                    continue

                # 2. Periodic retrain check (every 50 cycles)
                if cycle % 50 == 0:
                    self._maybe_retrain()

                # 3. Auto-scan for new stock opportunities (every 24h)
                if (self.last_scan is None or
                        (datetime.now() - self.last_scan).total_seconds() / 60 >= self.scan_interval_minutes):
                    logger.info("Running auto-scanner to discover new stocks...")
                    changes = self.scanner.update_watchlist()
                    if changes:
                        for c in changes:
                            logger.info(f"Scanner: {c}")
                        # Update watchlist reference and trigger retrain
                        self.watchlist = self.config.get("watchlist", self.watchlist)
                        self.ml_engine.force_retrain()
                        # Tell intelligence layers about the new watchlist
                        if self.intel is not None:
                            try:
                                self.intel.update_watchlist(self.watchlist)
                            except Exception as e:
                                logger.debug(f"intel.update_watchlist failed: {e}")
                    self.last_scan = datetime.now()

                # 4. Manage existing positions
                closed = self.check_and_manage_positions()
                if closed:
                    logger.info(f"Closed positions: {', '.join(closed)}")

                # 5. Scan for new signals
                account = self.broker.get_account()
                equity = float(account.get("equity", 0))
                signals = self.scan_for_signals()

                if signals:
                    logger.info(f"Found {len(signals)} signals: "
                                f"{[s['symbol'] for s in signals]}")
                    executed = self.execute_signals(signals, equity)
                    if executed:
                        logger.info(f"Executed {len(executed)} trades")
                else:
                    logger.info(f"Scanning... no signals above threshold this cycle (checked {len(self.watchlist)} symbols)")

                # 6. Status print
                positions = self.broker.get_positions()
                self._print_status(equity, positions)

                # 7. Check paper->live readiness
                if self.paper and len(self.trade_history) > 0 and cycle % 100 == 0:
                    ready, report = self.risk_manager.get_paper_to_live_readiness(
                        [t for t in self.trade_history if t.get("status") == "closed"]
                    )
                    if ready:
                        logger.info("*** PAPER TRADING CRITERIA MET - Bot may be ready for live trading ***")
                        logger.info(f"Stats: WR={report['win_rate']:.1%}, Sharpe={report['sharpe_ratio']:.2f}, Days={report['days_trading']}")

            except Exception as e:
                logger.error(f"Engine error (cycle {cycle}): {e}", exc_info=True)

            self._sleep(self.check_interval)

    def _print_status(self, equity, positions):
        closed_trades = [t for t in self.trade_history if t.get("status") == "closed"]
        wins = [t for t in closed_trades if t.get("return_pct", 0) > 0]
        win_rate = len(wins) / len(closed_trades) if closed_trades else 0
        total_pnl = sum(t.get("pnl", 0) for t in closed_trades)
        pos_str = f"{len(positions)} open" if positions else "none"
        logger.info(
            f"STATUS | Equity: ${equity:,.2f} | Positions: {pos_str} | "
            f"Trades: {len(closed_trades)} | WR: {win_rate:.1%} | "
            f"PnL: ${total_pnl:+,.2f} | {'PAPER' if self.paper else 'LIVE'} | {self.get_mode_label()}"
        )
        for p in positions:
            sym = p.get("symbol", "?")
            qty = p.get("qty", "?")
            entry = float(p.get("avg_entry_price", 0))
            current = float(p.get("current_price", 0))
            unrealized = float(p.get("unrealized_pl", 0))
            pct = float(p.get("unrealized_plpc", 0)) * 100
            logger.info(f"  POSITION {sym} x{qty} | entry ${entry:.2f} | now ${current:.2f} | {pct:+.2f}% | PnL: ${unrealized:+.2f}")

    def _sleep(self, seconds):
        """Interruptible sleep."""
        for _ in range(seconds):
            if not self.running:
                break
            time.sleep(1)

    def shutdown(self):
        """Graceful shutdown."""
        self.running = False
        if self.intel is not None:
            try:
                self.intel.stop()
            except Exception:
                pass
        self._save_trade_history()
        logger.info("Trading engine stopped")

    def run_backtest(self, days=90):
        """Simple backtest over historical data."""
        logger.info(f"Starting backtest ({days} days)")
        from datetime import timedelta
        import numpy as np

        multi_bars = self.broker.get_multi_bars(
            self.watchlist, timeframe="1Day", limit=days + 60
        )

        trades = []
        equity = 10000.0
        peak_equity = equity

        for symbol, bars in multi_bars.items():
            if len(bars) < 60:
                continue

            for i in range(60, len(bars) - 10):
                window = bars[:i]
                signal, confidence = self.ml_engine.predict(window)

                if signal == "buy" and confidence >= self.ml_engine.confidence_threshold:
                    entry = float(bars[i].get("c", 0))
                    stop = entry * (1 - self.config.get("risk.stop_loss_pct", 0.05))
                    tp = entry * (1 + self.config.get("risk.take_profit_pct", 0.10))

                    # Simulate trade over next N bars
                    for j in range(i + 1, min(i + 10, len(bars))):
                        h = float(bars[j].get("h", 0))
                        l = float(bars[j].get("l", 0))
                        if l <= stop:
                            ret = (stop - entry) / entry
                            break
                        elif h >= tp:
                            ret = (tp - entry) / entry
                            break
                    else:
                        ret = (float(bars[min(i + 9, len(bars) - 1)].get("c", entry)) - entry) / entry

                    pos_size = equity * self.config.get("risk.risk_per_trade_pct", 0.02) / abs(entry - stop) * entry
                    pos_size = min(pos_size, equity * 0.05)
                    pnl = pos_size * ret
                    equity += pnl
                    trades.append({"symbol": symbol, "return_pct": ret, "pnl": pnl})

                    if equity > peak_equity:
                        peak_equity = equity

        if not trades:
            return {"total_return_pct": 0, "sharpe_ratio": 0, "max_drawdown_pct": 0,
                    "win_rate": 0, "total_trades": 0, "profit_factor": 0}

        rets = np.array([t["return_pct"] for t in trades])
        wins = [t["pnl"] for t in trades if t["pnl"] > 0]
        losses = [abs(t["pnl"]) for t in trades if t["pnl"] < 0]

        return {
            "total_return_pct": (equity - 10000) / 10000 * 100,
            "sharpe_ratio": float((rets.mean() / (rets.std() + 1e-9)) * (252 ** 0.5)) if len(rets) > 1 else 0,
            "max_drawdown_pct": float((equity - peak_equity) / (peak_equity + 1e-9) * 100),
            "win_rate": float(len([t for t in trades if t["pnl"] > 0]) / len(trades) * 100),
            "total_trades": len(trades),
            "profit_factor": float(sum(wins) / (sum(losses) + 1e-9))
        }
