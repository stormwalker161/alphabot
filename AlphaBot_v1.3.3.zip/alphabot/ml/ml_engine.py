"""
ML Engine - The learning brain of AlphaBot
Uses RandomForest + Gradient Boosting ensemble with online learning.
Retrains automatically every N hours on new market data.
Learns from its own trade outcomes to improve over time.
"""

import os
import json
import logging
import numpy as np
from datetime import datetime, timedelta
import pickle

logger = logging.getLogger("alphabot.ml")

try:
    from data.yf_fetcher import fetch_multi_bars_yf
    HAS_YF_FETCHER = True
except ImportError:
    HAS_YF_FETCHER = False

# Graceful imports
try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False
    logger.warning("pandas not installed - ML features limited")

try:
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import cross_val_score
    from sklearn.metrics import classification_report
    HAS_SKLEARN = True
except ImportError:
    HAS_SKLEARN = False
    logger.warning("scikit-learn not installed - using rule-based fallback")


class MLEngine:
    def __init__(self, config):
        self.config = config
        self.model = None
        self.scaler = None
        self.is_trained = False
        self.last_trained = None
        self.model_path = "models/alphabot_model.pkl"
        self.scaler_path = "models/alphabot_scaler.pkl"
        self.performance_path = "models/model_performance.json"
        self.last_trained_path = "models/last_trained.json"
        self.retrain_hours = config.get("ml.retrain_interval_hours", 24)
        self.confidence_threshold = config.get("ml.confidence_threshold", 0.62)
        self.min_samples = config.get("ml.min_training_samples", 500)

        os.makedirs("models", exist_ok=True)
        self._load_model()
        self._load_last_trained()

    def _load_model(self):
        if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
            try:
                with open(self.model_path, "rb") as f:
                    self.model = pickle.load(f)
                with open(self.scaler_path, "rb") as f:
                    self.scaler = pickle.load(f)
                self.is_trained = True
                logger.info("Loaded existing ML model from disk")
                if os.path.exists(self.performance_path):
                    with open(self.performance_path) as f:
                        perf = json.load(f)
                    logger.info(f"Model performance: accuracy={perf.get('accuracy', 0):.3f}, "
                                f"trained on {perf.get('training_samples', 0)} samples")
            except Exception as e:
                logger.warning(f"Could not load model: {e}")
                self.is_trained = False

    def _load_last_trained(self):
        """Load last trained timestamp from disk so restarts dont trigger retrain."""
        if os.path.exists(self.last_trained_path):
            try:
                with open(self.last_trained_path) as f:
                    data = json.load(f)
                ts = data.get("last_trained")
                if ts:
                    self.last_trained = datetime.fromisoformat(ts)
                    logger.info(f"Last trained: {self.last_trained.strftime('%Y-%m-%d %H:%M')}")
            except Exception:
                pass

    def _save_last_trained(self):
        """Persist last trained time to disk."""
        try:
            with open(self.last_trained_path, "w") as f:
                json.dump({"last_trained": self.last_trained.isoformat()}, f)
        except Exception:
            pass

    def _save_model(self):
        try:
            with open(self.model_path, "wb") as f:
                pickle.dump(self.model, f)
            with open(self.scaler_path, "wb") as f:
                pickle.dump(self.scaler, f)
        except Exception as e:
            logger.error(f"Failed to save model: {e}")

    def needs_retrain(self):
        if not self.is_trained:
            return True
        if self.last_trained is None:
            return True
        hours_since = (datetime.now() - self.last_trained).total_seconds() / 3600
        return hours_since >= self.retrain_hours

    def force_retrain(self):
        self.last_trained = None
        self.is_trained = False

    def compute_features(self, bars):
        """
        Compute technical indicator features from OHLCV bars.
        Returns feature array for ML prediction.
        bars: list of dicts with keys: o, h, l, c, v
        """
        if not HAS_PANDAS or len(bars) < 50:
            return None

        df = pd.DataFrame(bars)
        df.columns = [c.lower() for c in df.columns]

        # Ensure we have OHLCV
        for col in ['o', 'h', 'l', 'c', 'v']:
            if col not in df.columns:
                return None

        df['open'] = df['o'].astype(float)
        df['high'] = df['h'].astype(float)
        df['low'] = df['l'].astype(float)
        df['close'] = df['c'].astype(float)
        df['volume'] = df['v'].astype(float)

        features = {}

        # === RSI ===
        delta = df['close'].diff()
        gain = delta.clip(lower=0).rolling(14).mean()
        loss = (-delta.clip(upper=0)).rolling(14).mean()
        rs = gain / (loss + 1e-9)
        df['rsi'] = 100 - (100 / (1 + rs))
        features['rsi'] = df['rsi'].iloc[-1]
        features['rsi_prev'] = df['rsi'].iloc[-2]

        # === MACD ===
        ema12 = df['close'].ewm(span=12).mean()
        ema26 = df['close'].ewm(span=26).mean()
        df['macd'] = ema12 - ema26
        df['macd_signal'] = df['macd'].ewm(span=9).mean()
        df['macd_hist'] = df['macd'] - df['macd_signal']
        features['macd_hist'] = df['macd_hist'].iloc[-1]
        features['macd_cross'] = 1 if df['macd_hist'].iloc[-1] > 0 and df['macd_hist'].iloc[-2] <= 0 else (
                                 -1 if df['macd_hist'].iloc[-1] < 0 and df['macd_hist'].iloc[-2] >= 0 else 0)

        # === Bollinger Bands ===
        sma20 = df['close'].rolling(20).mean()
        std20 = df['close'].rolling(20).std()
        upper = sma20 + 2 * std20
        lower = sma20 - 2 * std20
        features['bb_position'] = (df['close'].iloc[-1] - lower.iloc[-1]) / (upper.iloc[-1] - lower.iloc[-1] + 1e-9)
        features['bb_width'] = (upper.iloc[-1] - lower.iloc[-1]) / (sma20.iloc[-1] + 1e-9)

        # === Moving averages ===
        sma50 = df['close'].rolling(50).mean()
        sma200 = df['close'].rolling(200).mean() if len(df) >= 200 else sma50
        ema20 = df['close'].ewm(span=20).mean()
        price = df['close'].iloc[-1]
        features['above_sma50'] = 1 if price > sma50.iloc[-1] else 0
        features['above_sma200'] = 1 if price > sma200.iloc[-1] else 0
        features['price_vs_ema20'] = (price - ema20.iloc[-1]) / (ema20.iloc[-1] + 1e-9)
        features['sma50_slope'] = (sma50.iloc[-1] - sma50.iloc[-5]) / (sma50.iloc[-5] + 1e-9)

        # === Volume ===
        avg_vol = df['volume'].rolling(20).mean()
        features['volume_ratio'] = df['volume'].iloc[-1] / (avg_vol.iloc[-1] + 1e-9)
        features['volume_trend'] = (df['volume'].rolling(5).mean().iloc[-1] /
                                    (df['volume'].rolling(20).mean().iloc[-1] + 1e-9))

        # === Momentum ===
        features['momentum_5'] = (price / (df['close'].iloc[-5] + 1e-9)) - 1
        features['momentum_10'] = (price / (df['close'].iloc[-10] + 1e-9)) - 1
        features['momentum_20'] = (price / (df['close'].iloc[-20] + 1e-9)) - 1

        # === ATR (volatility) ===
        high_low = df['high'] - df['low']
        high_close = abs(df['high'] - df['close'].shift())
        low_close = abs(df['low'] - df['close'].shift())
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        atr = tr.rolling(14).mean()
        features['atr_ratio'] = atr.iloc[-1] / (price + 1e-9)
        features['atr_trend'] = (atr.rolling(5).mean().iloc[-1] / (atr.rolling(20).mean().iloc[-1] + 1e-9))

        # === Price patterns ===
        features['higher_highs'] = 1 if df['high'].iloc[-1] > df['high'].iloc[-3] else 0
        features['higher_lows'] = 1 if df['low'].iloc[-1] > df['low'].iloc[-3] else 0
        features['candle_body'] = (df['close'].iloc[-1] - df['open'].iloc[-1]) / (df['high'].iloc[-1] - df['low'].iloc[-1] + 1e-9)

        # === Stochastic ===
        low14 = df['low'].rolling(14).min()
        high14 = df['high'].rolling(14).max()
        k = 100 * (df['close'] - low14) / (high14 - low14 + 1e-9)
        features['stoch_k'] = k.iloc[-1]
        features['stoch_d'] = k.rolling(3).mean().iloc[-1]

        # Sanitize
        for k, v in features.items():
            if isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
                features[k] = 0.0

        return features

    def build_training_dataset(self, multi_bars, lookahead=5, threshold=0.02):
        """
        Build supervised training dataset from historical bar data.
        Label: 1 = price rose >threshold in next N bars, 0 = otherwise
        """
        if not HAS_PANDAS:
            return None, None

        all_X, all_y = [], []

        for symbol, bars in multi_bars.items():
            if len(bars) < self.min_samples // max(1, len(multi_bars)):
                continue

            df = pd.DataFrame(bars)
            df.columns = [c.lower() for c in df.columns]
            if 'c' not in df.columns:
                continue

            closes = df['c'].astype(float).values

            for i in range(60, len(df) - lookahead):
                window_bars = bars[max(0, i-200):i]
                features = self.compute_features(window_bars)
                if features is None:
                    continue

                future_return = (closes[i + lookahead] - closes[i]) / (closes[i] + 1e-9)
                label = 1 if future_return > threshold else 0

                all_X.append(list(features.values()))
                all_y.append(label)

        if len(all_X) < 100:
            return None, None

        return np.array(all_X), np.array(all_y)

    def train(self, multi_bars):
        """Train/retrain the ML ensemble model."""
        if not HAS_SKLEARN or not HAS_PANDAS:
            logger.warning("ML libraries not available, skipping training")
            return False

        # If Alpaca data is thin, fetch from Yahoo Finance (free, no key needed)
        total_bars = sum(len(v) for v in multi_bars.values())
        if total_bars < self.min_samples and HAS_YF_FETCHER:
            logger.info(f"Alpaca data thin ({total_bars} bars) — fetching from Yahoo Finance...")
            symbols = list(multi_bars.keys()) or self.config.get("watchlist", [
                "AAPL","MSFT","NVDA","GOOGL","AMZN","TSLA","SPY","QQQ","META","AMD"
            ])
            yf_data = fetch_multi_bars_yf(symbols, period="1y", interval="1d")
            if yf_data:
                for sym, bars in yf_data.items():
                    if sym not in multi_bars or len(multi_bars.get(sym, [])) < len(bars):
                        multi_bars[sym] = bars
                logger.info(f"Yahoo Finance loaded: {sum(len(v) for v in multi_bars.values())} total bars")

        logger.info("Building training dataset...")
        X, y = self.build_training_dataset(multi_bars)
        if X is None or len(X) < 100:
            logger.warning(f"Insufficient training data ({0 if X is None else len(X)} samples)")
            return False

        logger.info(f"Training on {len(X)} samples | Class balance: {y.mean():.2f}")

        # Scale features
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)

        # Ensemble: RandomForest + GradientBoosting
        rf = RandomForestClassifier(n_estimators=150, max_depth=8,
                                    min_samples_leaf=20, random_state=42, n_jobs=-1)
        gb = GradientBoostingClassifier(n_estimators=100, max_depth=4,
                                         learning_rate=0.05, random_state=42)
        self.model = VotingClassifier(
            estimators=[("rf", rf), ("gb", gb)],
            voting="soft"
        )

        # Cross-validate
        cv_scores = cross_val_score(self.model, X_scaled, y, cv=5, scoring="accuracy")
        logger.info(f"CV Accuracy: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")

        # Final fit
        self.model.fit(X_scaled, y)
        self.is_trained = True
        self.last_trained = datetime.now()

        # Save performance metrics
        perf = {
            "accuracy": float(cv_scores.mean()),
            "accuracy_std": float(cv_scores.std()),
            "training_samples": len(X),
            "class_balance": float(y.mean()),
            "trained_at": datetime.now().isoformat()
        }
        with open(self.performance_path, "w") as f:
            json.dump(perf, f, indent=2)

        self._save_model()
        self._save_last_trained()
        logger.info(f"Model trained and saved. Accuracy: {cv_scores.mean():.3f}")
        return True

    def predict(self, bars):
        """
        Predict buy signal for a symbol given its bars.
        Returns: (signal, confidence) where signal is 'buy', 'sell', or 'hold'
        """
        features = self.compute_features(bars)
        if features is None:
            return "hold", 0.0

        if self.is_trained and HAS_SKLEARN:
            try:
                X = np.array(list(features.values())).reshape(1, -1)
                X_scaled = self.scaler.transform(X)
                proba = self.model.predict_proba(X_scaled)[0]
                buy_prob = proba[1]
                sell_prob = proba[0]

                if buy_prob >= self.confidence_threshold:
                    return "buy", float(buy_prob)
                elif sell_prob >= self.confidence_threshold + 0.05:
                    return "sell", float(sell_prob)
                else:
                    return "hold", float(max(buy_prob, sell_prob))
            except Exception as e:
                logger.warning(f"Prediction error: {e}, using rule-based fallback")

        # Rule-based fallback when ML model not available
        return self._rule_based_signal(features)

    def _rule_based_signal(self, features):
        """Simple rule-based fallback signal."""
        score = 0
        if features.get('rsi', 50) < 35: score += 2
        if features.get('rsi', 50) > 65: score -= 2
        if features.get('macd_hist', 0) > 0: score += 1
        if features.get('macd_cross', 0) == 1: score += 2
        if features.get('above_sma50', 0): score += 1
        if features.get('momentum_20', 0) > 0.02: score += 1
        if features.get('volume_ratio', 1) > 1.5: score += 1
        if features.get('bb_position', 0.5) < 0.2: score += 1

        if score >= 4:
            return "buy", min(0.5 + score * 0.05, 0.85)
        elif score <= -2:
            return "sell", min(0.5 + abs(score) * 0.05, 0.85)
        return "hold", 0.5

    def learn_from_trade(self, symbol, entry_price, exit_price, features_at_entry, signal):
        """
        Online learning: record outcome of a completed trade.
        This data is incorporated in the next full retrain.
        """
        outcome = {
            "symbol": symbol,
            "signal": signal,
            "entry": entry_price,
            "exit": exit_price,
            "return_pct": (exit_price - entry_price) / entry_price,
            "features": features_at_entry,
            "timestamp": datetime.now().isoformat()
        }
        path = "models/trade_outcomes.jsonl"
        with open(path, "a") as f:
            f.write(json.dumps(outcome) + "\n")

        # Check if we have enough new outcomes to trigger retrain
        try:
            with open(path) as f:
                count = sum(1 for _ in f)
            if count > 0 and count % 50 == 0:
                logger.info(f"Collected {count} trade outcomes — queuing model retrain")
                self.force_retrain()
        except Exception:
            pass
