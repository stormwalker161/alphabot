"""
Auto Scanner — finds high-potential stocks and adds them to the watchlist.
Runs periodically and discovers new opportunities the bot should watch.
Screens for: momentum, volume spikes, trend strength, and sector rotation.
"""

import json
import logging
import os

logger = logging.getLogger("alphabot.scanner")

try:
    import yfinance as yf
    HAS_YF = True
except ImportError:
    HAS_YF = False

try:
    import pandas as pd
    import numpy as np
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False


# Large universe of liquid, tradable stocks to screen from
SCAN_UNIVERSE = [
    # Mega cap tech
    "AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "META", "TSLA", "AVGO", "ORCL", "CRM",
    # Semiconductors
    "AMD", "INTC", "QCOM", "MU", "AMAT", "LRCX", "KLAC", "MRVL", "TSM", "ARM",
    # Finance
    "JPM", "BAC", "GS", "MS", "V", "MA", "PYPL", "COIN", "BRK-B", "WFC",
    # Healthcare
    "UNH", "JNJ", "LLY", "ABBV", "MRK", "PFE", "TMO", "ABT", "ISRG", "REGN",
    # Consumer
    "AMZN", "HD", "MCD", "NKE", "SBUX", "TGT", "WMT", "COST", "LOW", "TJX",
    # Energy
    "XOM", "CVX", "COP", "SLB", "OXY", "PSX", "VLO", "MPC", "EOG", "PXD",
    # ETFs
    "SPY", "QQQ", "IWM", "DIA", "XLK", "XLF", "XLE", "XLV", "XLI", "ARKK",
    # High growth / momentum names
    "PLTR", "NET", "SNOW", "DDOG", "CRWD", "ZS", "PANW", "UBER", "LYFT", "ABNB",
    "SHOP", "SQ", "ROKU", "RBLX", "U", "HOOD", "SOFI", "AFRM", "UPST", "IONQ",
    # Industrial / defense
    "CAT", "DE", "BA", "LMT", "RTX", "NOC", "GE", "HON", "MMM", "EMR",
    # Other large cap
    "NFLX", "DIS", "CMCSA", "T", "VZ", "TMUS", "AMT", "PLD", "SPG", "CCI",
]


class AutoScanner:
    def __init__(self, config):
        self.config = config
        self.max_watchlist_size = 25
        self.min_score = 3
        self.scan_results_path = "trades/scan_results.json"

    def score_stock(self, symbol):
        """
        Score a stock 0-10 based on momentum, volume, trend, and volatility.
        Higher = more interesting to watch.
        """
        if not HAS_YF or not HAS_PANDAS:
            return 0, {}

        try:
            ticker = yf.Ticker(symbol)
            df = ticker.history(period="6mo", interval="1d", auto_adjust=True)

            if df is None or len(df) < 60:
                return 0, {}

            close = df["Close"].astype(float)
            volume = df["Volume"].astype(float)
            high = df["High"].astype(float)
            low = df["Low"].astype(float)

            score = 0
            reasons = []

            # 1. Momentum: price above key MAs
            sma50 = close.rolling(50).mean().iloc[-1]
            sma200 = close.rolling(200).mean().iloc[-1] if len(df) >= 200 else sma50
            price = close.iloc[-1]

            if price > sma50:
                score += 1
                reasons.append("above SMA50")
            if price > sma200:
                score += 1
                reasons.append("above SMA200")

            # 2. Recent momentum (last 20 days)
            mom20 = (price / close.iloc[-20]) - 1
            if mom20 > 0.05:
                score += 2
                reasons.append(f"momentum +{mom20:.1%}")
            elif mom20 > 0.02:
                score += 1
                reasons.append(f"momentum +{mom20:.1%}")

            # 3. Volume surge (recent vs average)
            avg_vol = volume.rolling(20).mean().iloc[-1]
            recent_vol = volume.iloc[-5:].mean()
            vol_ratio = recent_vol / (avg_vol + 1e-9)
            if vol_ratio > 1.5:
                score += 2
                reasons.append(f"volume surge {vol_ratio:.1f}x")
            elif vol_ratio > 1.2:
                score += 1
                reasons.append(f"volume up {vol_ratio:.1f}x")

            # 4. Trend consistency (higher highs and higher lows)
            highs = high.iloc[-10:]
            lows = low.iloc[-10:]
            higher_highs = sum(1 for i in range(1, len(highs)) if highs.iloc[i] > highs.iloc[i-1])
            higher_lows = sum(1 for i in range(1, len(lows)) if lows.iloc[i] > lows.iloc[i-1])
            if higher_highs >= 6 and higher_lows >= 6:
                score += 2
                reasons.append("strong uptrend")
            elif higher_highs >= 4:
                score += 1
                reasons.append("mild uptrend")

            # 5. RSI in sweet spot (not overbought, has room to run)
            delta = close.diff()
            gain = delta.clip(lower=0).rolling(14).mean()
            loss = (-delta.clip(upper=0)).rolling(14).mean()
            rs = gain / (loss + 1e-9)
            rsi = (100 - (100 / (1 + rs))).iloc[-1]
            if 45 <= rsi <= 65:
                score += 1
                reasons.append(f"RSI {rsi:.0f} (ideal)")
            elif rsi > 75:
                score -= 1
                reasons.append(f"RSI {rsi:.0f} (overbought)")

            # 6. Not too volatile (ATR < 5% of price = manageable risk)
            hl = high - low
            atr = hl.rolling(14).mean().iloc[-1]
            atr_pct = atr / price
            if atr_pct > 0.06:
                score -= 1
                reasons.append(f"high volatility ({atr_pct:.1%})")

            info = {
                "price": round(price, 2),
                "momentum_20d": round(mom20 * 100, 1),
                "volume_ratio": round(vol_ratio, 2),
                "rsi": round(rsi, 1),
                "score": score,
                "reasons": reasons
            }

            return max(0, score), info

        except Exception as e:
            logger.debug(f"Score failed for {symbol}: {e}")
            return 0, {}

    def scan(self):
        """
        Scan universe, score every stock, return top candidates.
        """
        if not HAS_YF or not HAS_PANDAS:
            logger.warning("yfinance/pandas not available for scanning")
            return []

        current_watchlist = self.config.get("watchlist", [])
        logger.info(f"Scanning {len(SCAN_UNIVERSE)} stocks for opportunities...")

        results = []
        for i, symbol in enumerate(SCAN_UNIVERSE):
            if i % 20 == 0:
                logger.info(f"  Scanning... {i}/{len(SCAN_UNIVERSE)}")
            score, info = self.score_stock(symbol)
            if score >= self.min_score:
                results.append({"symbol": symbol, "score": score, **info})

        # Sort by score descending
        results.sort(key=lambda x: x["score"], reverse=True)

        logger.info(f"Found {len(results)} stocks scoring {self.min_score}+")

        # Save scan results
        os.makedirs("trades", exist_ok=True)
        with open(self.scan_results_path, "w") as f:
            json.dump(results[:50], f, indent=2)

        return results

    def update_watchlist(self):
        """
        Scan and automatically update watchlist with best opportunities.
        Keeps existing strong performers, adds new ones, removes weak ones.
        Returns list of changes made.
        """
        results = self.scan()
        if not results:
            return []

        current = self.config.get("watchlist", [])
        top_symbols = [r["symbol"] for r in results[:self.max_watchlist_size]]

        # Always keep ETFs and core holdings
        always_keep = {"SPY", "QQQ", "IWM"}
        current_set = set(current)
        top_set = set(top_symbols)

        # New additions: in top but not in current
        additions = [s for s in top_symbols if s not in current_set][:5]

        # Removals: in current but scored poorly (not in top 35)
        top35 = set(r["symbol"] for r in results[:35])
        removals = [s for s in current if s not in top35 and s not in always_keep][:3]

        changes = []

        new_watchlist = list(current)

        for symbol in removals:
            new_watchlist.remove(symbol)
            changes.append(f"REMOVED {symbol} (low score)")
            logger.info(f"Auto-scanner removed {symbol} from watchlist (weak momentum)")

        for symbol in additions:
            if len(new_watchlist) < self.max_watchlist_size:
                new_watchlist.append(symbol)
                info = next((r for r in results if r["symbol"] == symbol), {})
                reason = ", ".join(info.get("reasons", []))
                changes.append(f"ADDED {symbol} (score {info.get('score', 0)}: {reason})")
                logger.info(f"Auto-scanner added {symbol} to watchlist: {reason}")

        if changes:
            self.config.set("watchlist", new_watchlist)
            logger.info(f"Watchlist updated: {len(changes)} changes")
        else:
            logger.info("Watchlist unchanged — current stocks still strong")

        return changes

    def print_top_opportunities(self, n=10):
        """Print top N current opportunities."""
        results = self.scan()
        print(f"\n{'='*55}")
        print(f"  TOP {n} OPPORTUNITIES (Auto-Scanner)")
        print(f"{'='*55}")
        print(f"  {'Symbol':<8} {'Score':<7} {'Price':<9} {'Mom20d':<9} {'VolRatio':<10} {'RSI'}")
        print(f"  {'-'*50}")
        for r in results[:n]:
            print(f"  {r['symbol']:<8} {r['score']:<7} ${r.get('price', 0):<8.2f} "
                  f"{r.get('momentum_20d', 0):+.1f}%   {r.get('volume_ratio', 0):<10.2f} "
                  f"{r.get('rsi', 0):.0f}")
        print(f"{'='*55}\n")
        return results
