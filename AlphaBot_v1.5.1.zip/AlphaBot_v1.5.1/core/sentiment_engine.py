# -*- coding: utf-8 -*-
"""
AlphaBot - Unified Sentiment Engine
=====================================
Combines financial news intelligence and StockTwits social sentiment into a
single, background-threaded signal layer that the trading engine can query
without ever blocking the main loop.

Contains three cooperating modules:

  1. NewsIntelligence    — scrapes 4 free financial news sources, scores
                           headlines with VADER, maintains a rolling 4-hour
                           per-ticker cache.

  2. SocialSentiment     — pulls $TICKER chatter from the StockTwits public
                           API (no auth required), uses the site's built-in
                           Bullish/Bearish user tags when present and falls
                           back to VADER on the message body. Tracks 2-hour
                           mention frequency and 30-minute momentum spikes.

  3. CombinedIntelligence — orchestrates both, merges signals, and exposes
                             a single clean interface to TradingEngine.

# ============================================================
# REQUIREMENTS — replace requirements.txt with the updated
# version delivered alongside this file, or run:
#
#   pip install feedparser vaderSentiment beautifulsoup4 lxml
#
# Full pinned versions:
#   feedparser>=6.0.10
#   vaderSentiment>=3.3.2
#   beautifulsoup4>=4.12.0
#   lxml>=4.9.0
# ============================================================

# ============================================================
# NO API KEYS REQUIRED
#
# StockTwits exposes a free public endpoint:
#   https://api.stocktwits.com/api/2/streams/symbol/<TICKER>.json
#
# It returns the latest ~30 messages per ticker along with any
# self-tagged Bullish/Bearish label. No account, no OAuth, no key.
# Rate limited to ~200 requests/hour per IP which is plenty for
# a 238-stock watchlist on a 5-minute refresh.
#
# Optional config.json block (all fields have sensible defaults):
#
#   "stocktwits": {
#       "enabled": true,
#       "refresh_minutes": 5,
#       "window_hours": 2.0,
#       "spike_multiplier": 3.0
#   }
# ============================================================
"""

import threading
import time
import logging
import json
import os
import re
import urllib.parse
import calendar
from datetime import datetime, timedelta
from collections import defaultdict, deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import requests

logger = logging.getLogger("alphabot.sentiment")

# ─── optional dependency guards (all gracefully degraded) ─────────────────────

try:
    import feedparser
    HAS_FEEDPARSER = True
except ImportError:
    HAS_FEEDPARSER = False
    logger.warning("feedparser not installed — RSS news sources disabled  |  pip install feedparser")

try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    _VADER_INSTANCE = SentimentIntensityAnalyzer()
    HAS_VADER = True
except ImportError:
    _VADER_INSTANCE = None
    HAS_VADER = False
    logger.warning("vaderSentiment not installed — sentiment scoring disabled  |  pip install vaderSentiment")

try:
    from bs4 import BeautifulSoup
    HAS_BS4 = True
except ImportError:
    HAS_BS4 = False
    logger.warning("beautifulsoup4 not installed — Finviz scraping disabled  |  pip install beautifulsoup4")


# ─── shared VADER scorer (one instance, lock-protected) ───────────────────────

_VADER_LOCK = threading.Lock()


def _vader_score(text: str) -> float:
    """Thread-safe VADER compound score. Returns 0.0 if VADER unavailable."""
    if not HAS_VADER or _VADER_INSTANCE is None:
        return 0.0
    try:
        with _VADER_LOCK:
            return float(_VADER_INSTANCE.polarity_scores(text)["compound"])
    except Exception:
        return 0.0


# ─── shared ticker regex ──────────────────────────────────────────────────────

# Matches $AAPL / $TSLA style (Reddit) and bare UPPERCASE words (news)
_TICKER_DOLLAR   = re.compile(r"\$([A-Z]{1,5})\b")
_TICKER_BARE     = re.compile(r"\b([A-Z]{2,5})\b")

# Words that look like tickers but aren't — used to filter bare-word matches
_COMMON_WORDS = frozenset({
    "A", "I", "AM", "AN", "AS", "AT", "BE", "BY", "DO", "GO", "IF", "IN",
    "IS", "IT", "ME", "MY", "NO", "OF", "ON", "OR", "SO", "TO", "UP", "US",
    "WE", "OK", "ARE", "BUT", "CAN", "FOR", "GET", "GOT", "HAS", "HAD",
    "HIM", "HIS", "HOW", "ITS", "LET", "MAY", "NOT", "NOW", "OLD", "OUR",
    "OUT", "OWN", "PER", "PUT", "SAY", "SHE", "THE", "TOO", "TWO", "USE",
    "WAS", "WAY", "WHO", "WHY", "YET", "YOU", "YOUR", "ALL", "AND", "ANY",
    "CEO", "CFO", "COO", "IPO", "SEC", "ETF", "ATH", "ATM", "USD", "EUR",
    "GDP", "CPI", "Fed", "FED", "BTC", "ETH", "NFT", "API", "EPS", "ATR",
    "RSI", "SMA", "EMA", "HIGH", "HIGHS", "LOW", "LOWS", "OPEN", "JUST",
    "WILL", "FROM", "BEEN", "WITH", "HAVE", "THAN", "THAT", "THEY", "THIS",
    "WHAT", "WHEN", "WERE", "ALSO", "BACK", "DOWN", "EACH", "EVEN", "EVER",
    "GOOD", "HERE", "INTO", "MAKE", "MANY", "MUCH", "NEED", "NEXT", "OVER",
    "SAME", "SOME", "SUCH", "TAKE", "TIME", "VERY", "WEEK", "WELL", "YEAR",
    "LONG", "BULL", "BEAR", "CALL", "PUTS", "HOLD", "SELL", "YOLO", "MOON",
    "LOSS", "GAIN", "CASH", "BANK", "RATE", "RATE", "NEWS", "SOLD", "BOND",
    "FUND", "DIPS", "DIPS", "BEEN", "PUMP", "DUMP",
})


def _extract_tickers(text: str, watchlist: Optional[frozenset] = None) -> List[str]:
    """
    Extract stock ticker symbols from a text string.

    Priority:
      1. $TICKER mentions (always included, most reliable)
      2. Bare ALL-CAPS words (only included if they appear in watchlist)

    Returns a deduplicated list of uppercase ticker strings.
    """
    found = set()

    # $TICKER — high confidence
    for m in _TICKER_DOLLAR.finditer(text):
        found.add(m.group(1).upper())

    # Bare CAPS — only trust if in watchlist (avoids "I SOLD SOME" → "I", "SOLD", "SOME")
    if watchlist:
        for m in _TICKER_BARE.finditer(text):
            sym = m.group(1).upper()
            if sym in watchlist and sym not in _COMMON_WORDS:
                found.add(sym)

    return list(found)


# ══════════════════════════════════════════════════════════════════════════════
#  PART 1 — NewsIntelligence
#  Financial news from Yahoo Finance RSS, Finviz, Google News, Seeking Alpha
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class NewsItem:
    """A single scored financial news headline."""
    headline:  str
    ticker:    str
    source:    str
    timestamp: datetime
    score:     float            # VADER compound -1.0 … +1.0
    url:       str = ""

    def is_within(self, hours: float) -> bool:
        return (datetime.utcnow() - self.timestamp).total_seconds() < hours * 3600

    def __repr__(self):
        sign = "+" if self.score >= 0 else ""
        return f"[{self.source}] {sign}{self.score:.2f} | {self.headline[:80]}"


@dataclass
class TickerSentiment:
    """Aggregated news sentiment for one ticker."""
    ticker:         str
    score:          float
    headline_count: int
    top_headline:   str
    top_score:      float
    last_updated:   datetime
    sources_hit:    List[str] = field(default_factory=list)
    bullish_count:  int = 0
    bearish_count:  int = 0
    neutral_count:  int = 0

    def signal(self) -> str:
        if self.score >= 0.15:  return "bullish"
        if self.score <= -0.15: return "bearish"
        return "neutral"

    def to_dict(self) -> dict:
        return {
            "ticker":         self.ticker,
            "score":          round(self.score, 4),
            "headline_count": self.headline_count,
            "top_headline":   self.top_headline,
            "top_score":      round(self.top_score, 4),
            "last_updated":   self.last_updated.isoformat(),
            "signal":         self.signal(),
            "sources_hit":    self.sources_hit,
            "bullish_count":  self.bullish_count,
            "bearish_count":  self.bearish_count,
            "neutral_count":  self.neutral_count,
        }


class NewsIntelligence:
    """
    Background financial-news fetcher and VADER sentiment scorer.

    Sources (all free, no API key required):
      • Yahoo Finance RSS    — per-ticker official feed
      • Finviz               — scraped news table (20 headlines)
      • Google News RSS      — broad search results per ticker
      • Seeking Alpha RSS    — analyst notes and earnings previews

    Threading model: one daemon thread; never blocks the trading loop.
    Rolling window: 4 hours (configurable).
    """

    _HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
        "Accept-Language": "en-US,en;q=0.9",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    _TIMEOUT           = 10
    _MIN_FETCH_INTERVAL = 60      # seconds between fetches of same ticker

    def __init__(
        self,
        config=None,
        refresh_interval_minutes: int = 15,
        window_hours: float = 4.0,
        cache_path: str = "trades/news_cache.json",
    ):
        self.config           = config
        self.refresh_interval = refresh_interval_minutes * 60
        self.window_hours     = window_hours
        self.cache_path       = cache_path

        self._lock            = threading.RLock()
        self._headlines:      Dict[str, List[NewsItem]]    = defaultdict(list)
        self._watchlist:      List[str]                    = []
        self._last_fetch:     Dict[str, datetime]          = {}
        self._sentiment_cache: Dict[str, TickerSentiment] = {}

        self._thread:         Optional[threading.Thread]   = None
        self._stop_event      = threading.Event()
        self._running         = False

        os.makedirs("trades", exist_ok=True)
        logger.info(
            f"NewsIntelligence ready | "
            f"refresh={refresh_interval_minutes}min | window={window_hours}h"
        )

    # ── public ────────────────────────────────────────────────────────────────

    def start(self):
        if self._running:
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._background_loop, name="news-intel", daemon=True
        )
        self._thread.start()
        self._running = True
        logger.info("NewsIntelligence thread started")

    def stop(self):
        if not self._running:
            return
        self._stop_event.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=15)
        self._running = False
        logger.info("NewsIntelligence thread stopped")

    def watch_ticker(self, ticker: str):
        ticker = ticker.upper().strip()
        with self._lock:
            if ticker not in self._watchlist:
                self._watchlist.append(ticker)

    def watch_tickers(self, tickers: List[str]):
        for t in tickers:
            self.watch_ticker(t)

    def get_ticker_sentiment(self, ticker: str) -> dict:
        ticker = ticker.upper().strip()
        if ticker not in self._watchlist:
            self.watch_ticker(ticker)
        if ticker not in self._sentiment_cache:
            self._fetch_ticker(ticker)
        with self._lock:
            cached = self._sentiment_cache.get(ticker)
        return cached.to_dict() if cached else self._empty_result(ticker)

    def get_market_sentiment(self) -> dict:
        results = []
        with self._lock:
            for t in self._watchlist:
                if t in self._sentiment_cache:
                    results.append(self._sentiment_cache[t])
        if not results:
            return {"score": 0.0, "ticker_count": 0, "signal": "neutral"}
        avg = sum(r.score for r in results) / len(results)
        return {
            "score":        round(avg, 4),
            "ticker_count": len(results),
            "signal":       "bullish" if avg >= 0.10 else ("bearish" if avg <= -0.10 else "neutral"),
            "top_tickers":  [
                {"ticker": r.ticker, "score": round(r.score, 3)}
                for r in sorted(results, key=lambda x: abs(x.score), reverse=True)[:5]
            ],
        }

    # ── background ────────────────────────────────────────────────────────────

    def _background_loop(self):
        logger.info("NewsIntelligence background loop started")
        while not self._stop_event.is_set():
            try:
                with self._lock:
                    tickers = list(self._watchlist)
                logger.info(f"[News] Refresh cycle — {len(tickers)} tickers")
                for ticker in tickers:
                    if self._stop_event.is_set():
                        break
                    self._fetch_ticker(ticker)
                    self._stop_event.wait(timeout=1.5)
                self._prune_old_headlines()
                self._save_cache()
            except Exception as exc:
                logger.warning(f"[News] Loop error: {exc}")
            self._stop_event.wait(timeout=self.refresh_interval)
        logger.info("NewsIntelligence background loop exited")

    # ── fetching ──────────────────────────────────────────────────────────────

    def _fetch_ticker(self, ticker: str):
        last = self._last_fetch.get(ticker)
        if last and (datetime.utcnow() - last).total_seconds() < self._MIN_FETCH_INTERVAL:
            return
        items: List[NewsItem] = []
        items += self._fetch_yahoo_rss(ticker)
        items += self._fetch_finviz(ticker)
        items += self._fetch_google_news_rss(ticker)
        items += self._fetch_seeking_alpha_rss(ticker)
        if items:
            logger.info(
                f"[{ticker}] News: {len(items)} headlines from "
                f"{len({i.source for i in items})} source(s)"
            )
        with self._lock:
            existing = {h.headline: h for h in self._headlines[ticker]}
            for item in items:
                if item.headline not in existing:
                    existing[item.headline] = item
            self._headlines[ticker] = list(existing.values())
            self._last_fetch[ticker] = datetime.utcnow()
        self._aggregate(ticker)

    def _fetch_yahoo_rss(self, ticker: str) -> List[NewsItem]:
        if not HAS_FEEDPARSER:
            return []
        url = (
            f"https://feeds.finance.yahoo.com/rss/2.0/headline"
            f"?s={ticker}&region=US&lang=en-US"
        )
        try:
            feed  = feedparser.parse(url, agent=self._HEADERS["User-Agent"])
            items = []
            for entry in feed.entries[:20]:
                headline = _clean_text(entry.get("title", ""))
                if not headline:
                    continue
                ts    = _parse_feed_time(entry)
                score = _vader_score(headline)
                items.append(NewsItem(
                    headline=headline, ticker=ticker, source="yahoo_rss",
                    timestamp=ts, score=score, url=entry.get("link", ""),
                ))
            logger.info(f"[{ticker}] Yahoo RSS: {len(items)} headlines")
            return items
        except Exception as exc:
            logger.warning(f"[{ticker}] Yahoo RSS error: {exc}")
            return []

    def _fetch_finviz(self, ticker: str) -> List[NewsItem]:
        if not HAS_BS4:
            return []
        url = f"https://finviz.com/quote.ashx?t={ticker}&p=d"
        try:
            resp  = requests.get(url, headers=self._HEADERS, timeout=self._TIMEOUT)
            resp.raise_for_status()
            soup  = BeautifulSoup(resp.text, "lxml")
            table = soup.find("table", id="news-table")
            if not table:
                return []
            items     = []
            last_date = datetime.utcnow().date()
            for row in table.find_all("tr"):
                cells = row.find_all("td")
                if len(cells) < 2:
                    continue
                dt_text = cells[0].text.strip()
                if len(dt_text) > 8:
                    try:
                        last_date = datetime.strptime(dt_text[:9], "%b-%d-%y").date()
                    except ValueError:
                        pass
                time_part = dt_text[-7:] if len(dt_text) >= 7 else dt_text
                try:
                    t  = datetime.strptime(time_part, "%I:%M%p").time()
                    ts = datetime.combine(last_date, t)
                except ValueError:
                    ts = datetime.utcnow()
                link = cells[1].find("a")
                if not link:
                    continue
                headline = _clean_text(link.text)
                if not headline:
                    continue
                items.append(NewsItem(
                    headline=headline, ticker=ticker, source="finviz",
                    timestamp=ts, score=_vader_score(headline),
                    url=link.get("href", ""),
                ))
            logger.info(f"[{ticker}] Finviz: {len(items)} headlines")
            return items
        except requests.exceptions.HTTPError as exc:
            if exc.response is not None and exc.response.status_code == 429:
                logger.warning(f"[{ticker}] Finviz rate-limited — backing off")
            else:
                logger.warning(f"[{ticker}] Finviz HTTP error: {exc}")
            return []
        except Exception as exc:
            logger.warning(f"[{ticker}] Finviz error: {exc}")
            return []

    def _fetch_google_news_rss(self, ticker: str) -> List[NewsItem]:
        if not HAS_FEEDPARSER:
            return []
        query = urllib.parse.quote(f"{ticker} stock earnings")
        url   = (
            f"https://news.google.com/rss/search"
            f"?q={query}&hl=en-US&gl=US&ceid=US:en"
        )
        try:
            feed  = feedparser.parse(url, agent=self._HEADERS["User-Agent"])
            items = []
            for entry in feed.entries[:15]:
                headline = re.sub(r"\s+-\s+\S.*$", "",
                                  _clean_text(entry.get("title", ""))).strip()
                if not headline:
                    continue
                ts    = _parse_feed_time(entry)
                score = _vader_score(headline)
                items.append(NewsItem(
                    headline=headline, ticker=ticker, source="google_news",
                    timestamp=ts, score=score, url=entry.get("link", ""),
                ))
            logger.info(f"[{ticker}] Google News: {len(items)} headlines")
            return items
        except Exception as exc:
            logger.warning(f"[{ticker}] Google News error: {exc}")
            return []

    def _fetch_seeking_alpha_rss(self, ticker: str) -> List[NewsItem]:
        if not HAS_FEEDPARSER:
            return []
        url = f"https://seekingalpha.com/api/sa/combined/{ticker}.xml"
        try:
            feed  = feedparser.parse(
                url, agent=self._HEADERS["User-Agent"],
                request_headers={"Referer": "https://seekingalpha.com/"},
            )
            if feed.get("status", 200) == 404:
                return []
            items = []
            for entry in feed.entries[:15]:
                headline = _clean_text(entry.get("title", ""))
                if not headline:
                    continue
                ts    = _parse_feed_time(entry)
                score = _vader_score(headline)
                items.append(NewsItem(
                    headline=headline, ticker=ticker, source="seeking_alpha",
                    timestamp=ts, score=score, url=entry.get("link", ""),
                ))
            if items:
                logger.info(f"[{ticker}] Seeking Alpha: {len(items)} headlines")
            return items
        except Exception as exc:
            logger.info(f"[{ticker}] Seeking Alpha skipped: {exc}")
            return []

    # ── aggregation ───────────────────────────────────────────────────────────

    def _aggregate(self, ticker: str):
        with self._lock:
            all_items = list(self._headlines.get(ticker, []))
        cutoff = datetime.utcnow() - timedelta(hours=self.window_hours)
        window = [i for i in all_items if i.timestamp >= cutoff]
        if not window:
            return
        total_w = 0.0
        wsum    = 0.0
        bull = bear = neutral = 0
        for item in window:
            w       = 2.0 if abs(item.score) > 0.5 else 1.0
            wsum   += item.score * w
            total_w += w
            if   item.score >= 0.05:  bull    += 1
            elif item.score <= -0.05: bear    += 1
            else:                     neutral += 1
        avg_score = wsum / total_w if total_w else 0.0
        top       = max(window, key=lambda x: abs(x.score))
        result    = TickerSentiment(
            ticker=ticker, score=round(avg_score, 4),
            headline_count=len(window),
            top_headline=top.headline, top_score=round(top.score, 4),
            last_updated=datetime.utcnow(),
            sources_hit=list({i.source for i in window}),
            bullish_count=bull, bearish_count=bear, neutral_count=neutral,
        )
        with self._lock:
            self._sentiment_cache[ticker] = result
        logger.info(
            f"[{ticker}] News sentiment | score={avg_score:+.3f} | "
            f"n={len(window)} | {result.signal()}"
        )

    def _prune_old_headlines(self):
        cutoff = datetime.utcnow() - timedelta(hours=self.window_hours * 2)
        with self._lock:
            for ticker in list(self._headlines):
                before = len(self._headlines[ticker])
                self._headlines[ticker] = [
                    h for h in self._headlines[ticker] if h.timestamp >= cutoff
                ]
                pruned = before - len(self._headlines[ticker])
                if pruned:
                    logger.info(f"[{ticker}] Pruned {pruned} old news headlines")

    def _save_cache(self):
        try:
            data = {}
            with self._lock:
                for ticker, result in self._sentiment_cache.items():
                    data[ticker] = result.to_dict()
            with open(self.cache_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, default=str)
        except Exception as exc:
            logger.warning(f"[News] Cache save failed: {exc}")

    # ── trading engine helpers ────────────────────────────────────────────────

    def sentiment_boost(self, ticker: str) -> float:
        """Confidence multiplier based on news score. See CombinedIntelligence."""
        s = self.get_ticker_sentiment(ticker).get("score", 0.0)
        if s >= 0.20: return 1.10
        if s >= 0.05: return 1.04
        if s <= -0.20: return 0.80
        if s <= -0.05: return 0.93
        return 1.00

    def is_news_safe(self, ticker: str, min_score: float = -0.25) -> Tuple[bool, str]:
        r = self.get_ticker_sentiment(ticker)
        score = r.get("score", 0.0)
        count = r.get("headline_count", 0)
        if count >= 3 and score <= min_score:
            return False, (
                f"Negative news sentiment ({score:+.2f}, n={count}) — "
                f"'{r.get('top_headline','')[:60]}'"
            )
        return True, "OK"

    @staticmethod
    def _empty_result(ticker: str) -> dict:
        return {
            "ticker": ticker, "score": 0.0, "headline_count": 0,
            "top_headline": "No headlines available", "top_score": 0.0,
            "last_updated": datetime.utcnow().isoformat(), "signal": "neutral",
            "sources_hit": [], "bullish_count": 0, "bearish_count": 0, "neutral_count": 0,
        }


# ══════════════════════════════════════════════════════════════════════════════
#  PART 2 — SocialSentiment (StockTwits backend)
#  Pulls per-ticker $CASHTAG messages from the StockTwits free public API,
#  uses the site's built-in Bullish/Bearish self-tags when present and falls
#  back to VADER on the message body. 2-hour rolling window, 30-min spike
#  detection. Drop-in replacement for the previous Reddit/PRAW backend —
#  exposes the exact same SocialSentiment / SocialScore public API so
#  CombinedIntelligence works unchanged.
# ══════════════════════════════════════════════════════════════════════════════

# StockTwits public endpoint — no auth, ~200 req/hour per IP
_STOCKTWITS_URL = "https://api.stocktwits.com/api/2/streams/symbol/{ticker}.json"

# Fetch pacing: with a 238-ticker watchlist and 200 req/hour budget we pace
# ourselves to roughly one request per 20 seconds, which comfortably finishes
# one full pass in ~80 minutes. Since we keep a 2-hour rolling window, this
# is fine. If the watchlist is smaller we naturally go faster.
_ST_MIN_INTERVAL    = 1.0     # seconds between consecutive HTTP calls
_ST_RETRY_SLEEP     = 30.0    # seconds to sleep on rate-limit hit
_ST_DEFAULT_REFRESH = 5       # minutes between full watchlist refreshes


@dataclass
class SocialMention:
    """One StockTwits message that mentions a ticker."""
    ticker:    str
    text:      str          # body (first 280 chars)
    score:     float        # -1..+1, from tag or VADER
    timestamp: datetime
    post_id:   str
    source:    str = "stocktwits"
    tag:       str = ""     # "Bullish" / "Bearish" / "" (untagged)


@dataclass
class SocialScore:
    """Aggregated social signal for one ticker. API-compatible with the
    previous Reddit-backed version so CombinedIntelligence doesn't change."""
    ticker:         str
    mentions_2h:    int
    mentions_30m:   int
    sentiment_avg:  float        # weighted average score
    momentum_flag:  bool         # True when 30-min rate > spike_multiplier × baseline
    momentum_ratio: float        # actual ratio (mentions_30m / baseline_per_30m)
    top_post_title: str
    top_post_score: float
    last_updated:   datetime
    subreddits_seen: List[str]  = field(default_factory=list)  # repurposed: sources
    bullish_count:   int         = 0
    bearish_count:   int         = 0
    neutral_count:   int         = 0

    def signal(self) -> str:
        if self.momentum_flag:
            return "momentum_spike"
        if self.sentiment_avg >= 0.15:  return "bullish"
        if self.sentiment_avg <= -0.15: return "bearish"
        return "neutral"

    def to_dict(self) -> dict:
        return {
            "ticker":          self.ticker,
            "mentions_2h":     self.mentions_2h,
            "mentions_30m":    self.mentions_30m,
            "sentiment_avg":   round(self.sentiment_avg, 4),
            "momentum_flag":   self.momentum_flag,
            "momentum_ratio":  round(self.momentum_ratio, 2),
            "top_post_title":  self.top_post_title,
            "top_post_score":  round(self.top_post_score, 4),
            "last_updated":    self.last_updated.isoformat(),
            "signal":          self.signal(),
            "subreddits_seen": self.subreddits_seen,
            "bullish_count":   self.bullish_count,
            "bearish_count":   self.bearish_count,
            "neutral_count":   self.neutral_count,
        }


class SocialSentiment:
    """
    StockTwits-backed social sentiment tracker for AlphaBot.

    Pulls the public per-symbol message stream from StockTwits (no key,
    no account) for every ticker in the watchlist, scores each message,
    and maintains:
      - 2-hour rolling mention counts
      - 30-minute momentum detection (spike > spike_multiplier × baseline rate)

    Threading model: one daemon thread refreshes every `refresh_interval_minutes`.
    Rate limiting: paced with _ST_MIN_INTERVAL between HTTP calls; on a 429
                   we sleep _ST_RETRY_SLEEP and continue.

    Public API (drop-in compatible with the previous Reddit backend):
      .start() / .stop()
      .set_watchlist(list)
      .get_social_score(ticker) -> dict
      .has_social_risk(ticker) -> (risky: bool, reason: str)
      ._lock, ._watchlist_set   (CombinedIntelligence pokes these directly)
    """

    _HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/124.0.0.0 Safari/537.36 AlphaBot/1.0"
        ),
        "Accept": "application/json",
    }
    _TIMEOUT = 10

    def __init__(
        self,
        config=None,
        refresh_interval_minutes: int = _ST_DEFAULT_REFRESH,
        window_hours: float = 2.0,
        spike_multiplier: float = 3.0,
        cache_path: str = "trades/social_cache.json",
    ):
        self.config = config

        # Allow config override via optional "stocktwits" block
        st_cfg = {}
        if config is not None:
            try:
                st_cfg = config.get("stocktwits") or {}
            except Exception:
                st_cfg = {}

        self.enabled          = bool(st_cfg.get("enabled", True))
        self.refresh_interval = int(st_cfg.get("refresh_minutes", refresh_interval_minutes)) * 60
        self.window_hours     = float(st_cfg.get("window_hours", window_hours))
        self.spike_multiplier = float(st_cfg.get("spike_multiplier", spike_multiplier))
        self.cache_path       = cache_path

        self._lock             = threading.RLock()
        self._mentions:        Dict[str, deque] = defaultdict(deque)   # ticker -> deque[SocialMention]
        self._scores_cache:    Dict[str, SocialScore] = {}
        self._watchlist_set:   frozenset = frozenset()
        self._last_post_ids:   Dict[str, set] = defaultdict(set)       # dedup per-ticker

        self._thread:          Optional[threading.Thread] = None
        self._stop_event       = threading.Event()
        self._running          = False

        # Baseline mention rate per ticker (mentions per minute, rolling)
        self._baseline_rate:   Dict[str, float] = defaultdict(float)
        self._baseline_alpha   = 0.15   # EMA smoothing factor

        os.makedirs("trades", exist_ok=True)
        logger.info(
            f"SocialSentiment ready (StockTwits) | enabled={self.enabled} | "
            f"refresh={self.refresh_interval // 60}min | window={self.window_hours}h | "
            f"spike={self.spike_multiplier}x"
        )

    # ── public ────────────────────────────────────────────────────────────────

    def set_watchlist(self, tickers: List[str]):
        """Replace the watchlist. Called from CombinedIntelligence.watch_tickers."""
        clean = frozenset(t.upper().strip() for t in tickers if t and t.strip())
        with self._lock:
            self._watchlist_set = clean
        logger.info(f"SocialSentiment watchlist set: {len(clean)} tickers")

    def start(self):
        if not self.enabled:
            logger.info("SocialSentiment disabled via config — not starting background thread")
            return
        if self._running:
            return
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._background_loop, daemon=True, name="SocialSentiment"
        )
        self._running = True
        self._thread.start()
        logger.info("SocialSentiment background thread started")

    def stop(self):
        self._stop_event.set()
        self._running = False
        logger.info("SocialSentiment stopping")

    def get_social_score(self, ticker: str) -> dict:
        """Return the aggregated social score dict for a ticker."""
        ticker = ticker.upper().strip()
        with self._lock:
            cached = self._scores_cache.get(ticker)
        if cached:
            return cached.to_dict()
        # No data yet — trigger a one-shot fetch so the first caller isn't empty
        if self.enabled:
            try:
                self._fetch_ticker(ticker)
                with self._lock:
                    cached = self._scores_cache.get(ticker)
                if cached:
                    return cached.to_dict()
            except Exception as e:
                logger.debug(f"On-demand StockTwits fetch failed for {ticker}: {e}")
        return self._empty_result(ticker)

    def has_social_risk(self, ticker: str) -> Tuple[bool, str]:
        """
        Hard risk check used by CombinedIntelligence.is_trade_safe.
        Flags pump-and-dump pattern: momentum spike + negative sentiment.
        """
        s = self.get_social_score(ticker)
        if s.get("momentum_flag") and s.get("sentiment_avg", 0.0) <= -0.15:
            return True, (
                f"Social pump-dump pattern: {s['mentions_30m']} mentions/30m "
                f"({s['momentum_ratio']:.1f}x baseline), sentiment {s['sentiment_avg']:+.2f}"
            )
        return False, "OK"

    # ── background loop ───────────────────────────────────────────────────────

    def _background_loop(self):
        logger.info("SocialSentiment background loop started (StockTwits)")
        while not self._stop_event.is_set():
            try:
                with self._lock:
                    tickers = list(self._watchlist_set)
                if not tickers:
                    # Nothing to do yet; wait a bit and re-check
                    if self._stop_event.wait(10):
                        return
                    continue

                logger.info(f"[Social] Refresh cycle — {len(tickers)} tickers")
                fetched = 0
                for ticker in tickers:
                    if self._stop_event.is_set():
                        return
                    try:
                        if self._fetch_ticker(ticker):
                            fetched += 1
                    except Exception as e:
                        logger.debug(f"[Social] {ticker} fetch error: {e}")
                    # Pace HTTP calls
                    if self._stop_event.wait(_ST_MIN_INTERVAL):
                        return

                # Recompute aggregated scores for all watched tickers
                self._recompute_all_scores()
                logger.info(f"[Social] Refresh complete — {fetched}/{len(tickers)} updated")

                self._save_cache()
            except Exception as e:
                logger.error(f"[Social] Background loop error: {e}")

            # Sleep until next refresh (interruptible)
            if self._stop_event.wait(self.refresh_interval):
                return

    # ── fetching ──────────────────────────────────────────────────────────────

    def _fetch_ticker(self, ticker: str) -> bool:
        """Fetch the StockTwits message stream for one ticker. Returns True on success."""
        url = _STOCKTWITS_URL.format(ticker=urllib.parse.quote(ticker))
        try:
            resp = requests.get(url, headers=self._HEADERS, timeout=self._TIMEOUT)
        except requests.RequestException as e:
            logger.debug(f"[Social] HTTP error for {ticker}: {e}")
            return False

        if resp.status_code == 429:
            logger.warning(f"[Social] Rate limited on {ticker}, sleeping {_ST_RETRY_SLEEP}s")
            self._stop_event.wait(_ST_RETRY_SLEEP)
            return False
        if resp.status_code == 404:
            # StockTwits returns 404 for unknown symbols — silently skip
            return False
        if resp.status_code != 200:
            logger.debug(f"[Social] HTTP {resp.status_code} for {ticker}")
            return False

        try:
            data = resp.json()
        except ValueError:
            return False

        messages = data.get("messages") or []
        if not messages:
            return False

        new_mentions = []
        cutoff = datetime.utcnow() - timedelta(hours=self.window_hours)

        with self._lock:
            seen_ids = self._last_post_ids[ticker]

            for msg in messages:
                mid = str(msg.get("id", ""))
                if not mid or mid in seen_ids:
                    continue
                seen_ids.add(mid)

                # Parse timestamp (ISO format with Z)
                ts_str = msg.get("created_at", "")
                try:
                    # StockTwits uses e.g. "2026-04-09T17:23:45Z"
                    ts = datetime.strptime(ts_str, "%Y-%m-%dT%H:%M:%SZ")
                except Exception:
                    ts = datetime.utcnow()

                if ts < cutoff:
                    continue

                body = _clean_text(msg.get("body", ""))[:280]

                # StockTwits users can self-tag Bullish/Bearish via entities.sentiment
                tag = ""
                tag_score = None
                try:
                    sent = (msg.get("entities") or {}).get("sentiment") or {}
                    basic = sent.get("basic") if isinstance(sent, dict) else None
                    if basic == "Bullish":
                        tag, tag_score = "Bullish", 0.6
                    elif basic == "Bearish":
                        tag, tag_score = "Bearish", -0.6
                except Exception:
                    pass

                # Fall back to VADER on the body if no self-tag
                score = tag_score if tag_score is not None else _vader_score(body)

                m = SocialMention(
                    ticker=ticker,
                    text=body,
                    score=score,
                    timestamp=ts,
                    post_id=mid,
                    tag=tag,
                )
                new_mentions.append(m)

            # Prune seen_ids to keep memory bounded
            if len(seen_ids) > 500:
                # Drop oldest half (sets aren't ordered; just truncate arbitrarily)
                self._last_post_ids[ticker] = set(list(seen_ids)[-250:])

            # Append new mentions to the ticker's deque and evict stale ones
            dq = self._mentions[ticker]
            for m in new_mentions:
                dq.append(m)
            # Evict anything older than the window (×2 for baseline smoothing)
            hard_cutoff = datetime.utcnow() - timedelta(hours=self.window_hours * 2)
            while dq and dq[0].timestamp < hard_cutoff:
                dq.popleft()

        return True

    # ── aggregation ───────────────────────────────────────────────────────────

    def _recompute_all_scores(self):
        """Rebuild per-ticker SocialScore objects from the mention deques."""
        now = datetime.utcnow()
        window_cut = now - timedelta(hours=self.window_hours)
        spike_cut  = now - timedelta(minutes=30)

        with self._lock:
            for ticker in list(self._mentions.keys()):
                dq = self._mentions[ticker]
                if not dq:
                    continue

                # Count in the two windows
                in_window = [m for m in dq if m.timestamp >= window_cut]
                in_spike  = [m for m in in_window if m.timestamp >= spike_cut]

                mentions_2h  = len(in_window)
                mentions_30m = len(in_spike)

                # Weighted average sentiment — weight by 1 + |score|
                if in_window:
                    weights = [1.0 + abs(m.score) for m in in_window]
                    sentiment_avg = sum(m.score * w for m, w in zip(in_window, weights)) / sum(weights)
                else:
                    sentiment_avg = 0.0

                # Baseline rate EMA (mentions per minute over 2h window)
                current_rate = mentions_2h / (self.window_hours * 60.0) if self.window_hours > 0 else 0.0
                prev_baseline = self._baseline_rate.get(ticker, current_rate)
                baseline = (self._baseline_alpha * current_rate +
                            (1.0 - self._baseline_alpha) * prev_baseline)
                self._baseline_rate[ticker] = baseline

                # Spike ratio: mentions_30m vs expected (baseline * 30 min)
                expected_30m = max(baseline * 30.0, 0.5)  # avoid div-by-zero
                ratio = mentions_30m / expected_30m if expected_30m > 0 else 0.0
                momentum_flag = (mentions_30m >= 5 and ratio >= self.spike_multiplier)

                # Top mention: highest |score| × upvote-ish proxy
                top = max(in_window, key=lambda m: abs(m.score), default=None)
                top_title = top.text if top else ""
                top_score = top.score if top else 0.0

                # Bullish/bearish/neutral buckets
                bull = sum(1 for m in in_window if m.score >= 0.15)
                bear = sum(1 for m in in_window if m.score <= -0.15)
                neu  = mentions_2h - bull - bear

                score_obj = SocialScore(
                    ticker=ticker,
                    mentions_2h=mentions_2h,
                    mentions_30m=mentions_30m,
                    sentiment_avg=round(sentiment_avg, 4),
                    momentum_flag=momentum_flag,
                    momentum_ratio=round(ratio, 2),
                    top_post_title=top_title,
                    top_post_score=round(top_score, 4),
                    last_updated=now,
                    subreddits_seen=["stocktwits"],
                    bullish_count=bull,
                    bearish_count=bear,
                    neutral_count=neu,
                )
                self._scores_cache[ticker] = score_obj

                if momentum_flag:
                    logger.info(
                        f"[Social] ★ SPIKE ★ {ticker}: {mentions_30m} mentions/30m "
                        f"({ratio:.1f}x baseline), sentiment {sentiment_avg:+.2f}"
                    )

    # ── cache persistence ─────────────────────────────────────────────────────

    def _save_cache(self):
        try:
            with self._lock:
                payload = {
                    t: s.to_dict() for t, s in self._scores_cache.items()
                }
            with open(self.cache_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, default=str)
        except Exception as e:
            logger.debug(f"[Social] cache save failed: {e}")

    # ── utility ───────────────────────────────────────────────────────────────

    def _empty_result(self, ticker: str) -> dict:
        return {
            "ticker":          ticker,
            "mentions_2h":     0,
            "mentions_30m":    0,
            "sentiment_avg":   0.0,
            "momentum_flag":   False,
            "momentum_ratio":  0.0,
            "top_post_title":  "No StockTwits mentions yet",
            "top_post_score":  0.0,
            "last_updated":    datetime.utcnow().isoformat(),
            "signal":          "neutral",
            "subreddits_seen": [],
            "bullish_count":   0,
            "bearish_count":   0,
            "neutral_count":   0,
        }


# ══════════════════════════════════════════════════════════════════════════════
#  PART 3 — CombinedIntelligence
#  Merges news + social into one signal; single interface for TradingEngine
# ══════════════════════════════════════════════════════════════════════════════

class CombinedIntelligence:
    """
    Unified sentiment layer for AlphaBot's TradingEngine.

    Runs NewsIntelligence (news/RSS) and SocialSentiment (Reddit) as two
    independent background threads and merges their outputs into a single
    combined score and set of guard methods.

    Typical engine integration
    --------------------------
    In TradingEngine.__init__:
        self.intel = CombinedIntelligence(config)
        self.intel.watch_tickers(self.watchlist)
        self.intel.start()

    In TradingEngine.execute_signals(), per signal:
        safe, reason = self.intel.is_trade_safe(symbol)
        if not safe:
            logger.info(f"Skipping {symbol}: {reason}")
            continue
        confidence *= self.intel.confidence_multiplier(symbol)

    In TradingEngine.shutdown():
        self.intel.stop()

    Combined score weighting
    ------------------------
        news  : 60 % (higher quality, lower noise)
        social: 40 % (faster signal, higher noise)
    Weights are halved for each source when headline/mention count is < 3
    (low-data penalty), so a source with no data doesn't drag the result.
    """

    NEWS_WEIGHT   = 0.60
    SOCIAL_WEIGHT = 0.40
    LOW_DATA_MIN  = 3       # minimum items before full weight is applied

    def __init__(self, config=None):
        self.config = config
        self.news   = NewsIntelligence(config=config)
        self.social = SocialSentiment(config=config)

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self):
        """Start both background threads."""
        self.news.start()
        self.social.start()
        logger.info("CombinedIntelligence started (news + social threads)")

    def stop(self):
        """Stop both background threads cleanly."""
        self.news.stop()
        self.social.stop()
        logger.info("CombinedIntelligence stopped")

    def watch_tickers(self, tickers: List[str]):
        """Register tickers with both sub-modules."""
        self.news.watch_tickers(tickers)
        self.social.set_watchlist(tickers)

    def watch_ticker(self, ticker: str):
        self.news.watch_ticker(ticker)
        with self.social._lock:
            self.social._watchlist_set = (
                self.social._watchlist_set | frozenset([ticker.upper()])
            )

    # ── combined signal ───────────────────────────────────────────────────────

    def get_combined_score(self, ticker: str) -> dict:
        """
        Merge news and social signals into a single result dict.

        Returns
        -------
        dict with keys:
            combined_score      float   -1 … +1  (blended)
            combined_signal     str     bullish / bearish / neutral / momentum_spike
            news_score          float
            news_signal         str
            news_headlines      int
            social_score        float
            social_signal       str
            social_mentions_2h  int
            social_mentions_30m int
            momentum_flag       bool
            momentum_ratio      float
            top_news_headline   str
            top_reddit_post     str
            last_updated        str
        """
        ticker  = ticker.upper().strip()
        news_r  = self.news.get_ticker_sentiment(ticker)
        soc_r   = self.social.get_social_score(ticker)

        n_score = news_r.get("score", 0.0)
        s_score = soc_r.get("sentiment_avg", 0.0)
        n_count = news_r.get("headline_count", 0)
        s_count = soc_r.get("mentions_2h", 0)

        # Dynamic weights: penalise low-data sources
        nw = self.NEWS_WEIGHT   * (1.0 if n_count >= self.LOW_DATA_MIN else 0.5)
        sw = self.SOCIAL_WEIGHT * (1.0 if s_count >= self.LOW_DATA_MIN else 0.5)
        total_w   = nw + sw
        combined  = (n_score * nw + s_score * sw) / total_w if total_w > 0 else 0.0

        # Momentum spike overrides combined signal label
        momentum = soc_r.get("momentum_flag", False)
        if momentum:
            sig = "momentum_spike"
        elif combined >= 0.15:
            sig = "bullish"
        elif combined <= -0.15:
            sig = "bearish"
        else:
            sig = "neutral"

        return {
            "ticker":              ticker,
            "combined_score":      round(combined, 4),
            "combined_signal":     sig,
            "news_score":          n_score,
            "news_signal":         news_r.get("signal", "neutral"),
            "news_headlines":      n_count,
            "social_score":        s_score,
            "social_signal":       soc_r.get("signal", "neutral"),
            "social_mentions_2h":  s_count,
            "social_mentions_30m": soc_r.get("mentions_30m", 0),
            "momentum_flag":       momentum,
            "momentum_ratio":      soc_r.get("momentum_ratio", 0.0),
            "top_news_headline":   news_r.get("top_headline", ""),
            "top_reddit_post":     soc_r.get("top_post_title", ""),
            "last_updated":        datetime.utcnow().isoformat(),
        }

    # ── trading engine interface ───────────────────────────────────────────────

    def confidence_multiplier(self, ticker: str) -> float:
        """
        Returns a single float to multiply against the ML confidence score
        before the threshold check in TradingEngine.execute_signals().

        Range: 0.78 … 1.18 (conservative — never overwhelms the ML signal)

        Breakdown by combined_score:
            >= +0.25  → 1.18  (strong bullish across both sources)
            >= +0.12  → 1.08
            >= +0.04  → 1.02
            <= -0.25  → 0.78
            <= -0.12  → 0.88
            <= -0.04  → 0.96
            otherwise → 1.00

        Momentum spike adds an additional +0.05 (capped at 1.18).
        """
        r     = self.get_combined_score(ticker)
        score = r.get("combined_score", 0.0)

        if score >= 0.25:   base = 1.18
        elif score >= 0.12: base = 1.08
        elif score >= 0.04: base = 1.02
        elif score <= -0.25: base = 0.78
        elif score <= -0.12: base = 0.88
        elif score <= -0.04: base = 0.96
        else:                base = 1.00

        if r.get("momentum_flag"):
            base = min(base + 0.05, 1.18)

        logger.info(
            f"[{ticker}] Confidence multiplier: {base:.2f} | "
            f"combined={score:+.3f} | signal={r.get('combined_signal')}"
        )
        return base

    def is_trade_safe(self, ticker: str) -> Tuple[bool, str]:
        """
        Hard safety check — returns (safe: bool, reason: str).

        Blocks a trade if ANY of:
          • News sentiment is strongly negative  (< -0.25, n >= 3)
          • Social shows pump-dump pattern       (spike + negative sentiment)

        Designed to be called BEFORE execute_signals() proceeds.
        """
        safe_n, reason_n = self.news.is_news_safe(ticker)
        if not safe_n:
            return False, f"[News] {reason_n}"

        risky_s, reason_s = self.social.has_social_risk(ticker)
        if risky_s:
            return False, f"[Social] {reason_s}"

        return True, "OK"

    def log_summary(self, tickers: Optional[List[str]] = None):
        """
        Emit a formatted summary log of all (or specified) tickers.
        Handy to call once per engine cycle for a readable status snapshot.
        """
        with self.news._lock:
            if tickers is None:
                tickers = list(self.news._watchlist)

        logger.info("─" * 70)
        logger.info(" SENTIMENT SUMMARY")
        logger.info("─" * 70)
        for t in tickers:
            r = self.get_combined_score(t)
            flag = " ★SPIKE★" if r["momentum_flag"] else ""
            logger.info(
                f"  {t:<6} | combined={r['combined_score']:+.3f} "
                f"({r['combined_signal']:<16}) | "
                f"news={r['news_score']:+.3f} (n={r['news_headlines']:>2}) | "
                f"social={r['social_score']:+.3f} (n={r['social_mentions_2h']:>3})"
                f"{flag}"
            )
        logger.info("─" * 70)


# ══════════════════════════════════════════════════════════════════════════════
#  Shared utility functions
# ══════════════════════════════════════════════════════════════════════════════

def _clean_text(text: str) -> str:
    """Strip HTML tags, entities, and collapse whitespace."""
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"&[a-z]+;", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _parse_feed_time(entry) -> datetime:
    """Parse a feedparser entry published_parsed, fall back to utcnow."""
    try:
        if hasattr(entry, "published_parsed") and entry.published_parsed:
            return datetime.utcfromtimestamp(calendar.timegm(entry.published_parsed))
    except Exception:
        pass
    return datetime.utcnow()


# ══════════════════════════════════════════════════════════════════════════════
#  Factory
# ══════════════════════════════════════════════════════════════════════════════

def create_intelligence(
    config=None,
    watchlist: Optional[List[str]] = None,
) -> CombinedIntelligence:
    """
    Factory — builds, populates, and starts a CombinedIntelligence instance.

    Parameters
    ----------
    config      AlphaBot Config object
    watchlist   explicit list of tickers; falls back to config watchlist

    Returns
    -------
    Running CombinedIntelligence instance
    """
    intel = CombinedIntelligence(config=config)

    tickers = watchlist
    if tickers is None and config is not None:
        tickers = config.get("watchlist", [])
    if tickers:
        intel.watch_tickers(tickers)

    intel.start()
    logger.info(
        f"CombinedIntelligence factory started | "
        f"{len(tickers or [])} tickers registered"
    )
    return intel


# ══════════════════════════════════════════════════════════════════════════════
#  Standalone test
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stdout,
    )

    TEST_TICKERS = ["AAPL", "NVDA", "TSLA", "AMD"]
    logger.info("=== AlphaBot Sentiment Engine — standalone test ===")
    logger.info(f"VADER available:      {HAS_VADER}")
    logger.info(f"feedparser available: {HAS_FEEDPARSER}")
    logger.info(f"BeautifulSoup avail:  {HAS_BS4}")
    logger.info(f"Social backend:       StockTwits (no auth)")
    logger.info("")

    # Test news only
    ni = NewsIntelligence(refresh_interval_minutes=99)
    ni.watch_tickers(TEST_TICKERS)

    logger.info("--- Fetching news for test tickers ---")
    for ticker in TEST_TICKERS:
        ni._fetch_ticker(ticker)
        r = ni.get_ticker_sentiment(ticker)
        logger.info(
            f"  {ticker:<6} news | score={r['score']:+.4f} | "
            f"n={r['headline_count']} | signal={r['signal']} | "
            f"top='{r['top_headline'][:60]}'"
        )

    logger.info("")
    market = ni.get_market_sentiment()
    logger.info(
        f"Market (news): score={market['score']:+.4f} | "
        f"signal={market['signal']} | tickers={market['ticker_count']}"
    )

    logger.info("")
    logger.info("--- SocialSentiment (StockTwits, no auth required) ---")
    ss = SocialSentiment(refresh_interval_minutes=99)
    ss.set_watchlist(TEST_TICKERS)
    for ticker in TEST_TICKERS:
        ss._fetch_ticker(ticker)
    ss._recompute_all_scores()
    for ticker in TEST_TICKERS:
        r = ss.get_social_score(ticker)
        logger.info(
            f"  {ticker:<6} social | mentions_2h={r['mentions_2h']} | "
            f"mentions_30m={r['mentions_30m']} | "
            f"sentiment={r['sentiment_avg']:+.3f} | "
            f"momentum={'★ SPIKE' if r['momentum_flag'] else 'no'} | "
            f"signal={r['signal']}"
        )

    ni.stop()
    logger.info("=== Test complete ===")
