# AlphaBot — AI Trading Bot

An AI-powered trading bot that learns from market interactions.  
Uses an ensemble ML model (Random Forest + Gradient Boosting) that retrains  
automatically on new data and incorporates the outcome of every trade it makes.

---

## Quick Start (Windows)

1. **Install Python 3.9+** from https://python.org  
   ✓ Check "Add Python to PATH" during install

2. **Get free Alpaca API keys** at https://alpaca.markets  
   - Sign up → Go to Paper Trading → API Keys → Generate

3. **Double-click `START.bat`**  
   - It will install dependencies automatically  
   - It will open `config.json` for you to add your keys

4. **Edit `config.json`** — add your Alpaca keys:
   ```json
   "alpaca_api_key": "PKXXXXXXXXXXXXXXXXXXXX",
   "alpaca_secret_key": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
   ```

5. **Choose option 1** (Paper trading) and let it run for at least 30 days.

6. **Check readiness** with option 3 before switching to live trading.

---

## How It Works

### 1. Data Collection
The bot fetches daily OHLCV bar data for every symbol in your watchlist  
via the Alpaca market data API. This is updated every 10 minutes while running.

### 2. Feature Engineering
For each symbol, 25+ technical indicators are computed:
- RSI (relative strength index)
- MACD histogram + crossover signals
- Bollinger Bands position and width
- Moving averages (SMA50, SMA200, EMA20) and slopes
- Volume ratio and trend
- Price momentum (5/10/20-day)
- ATR (average true range — volatility measure)
- Stochastic oscillator
- Candlestick body characteristics

### 3. ML Signal Generation
An ensemble model (Random Forest + Gradient Boosting, trained via VotingClassifier)  
takes these 25 features and predicts the probability of price rising >2%  
in the next 5 trading days.

A signal is only acted on if confidence ≥ 62% (configurable).

If the model isn't trained yet, a rule-based fallback generates signals.

### 4. Risk Management
Before any trade is executed:
- Max open positions check (default: 8)
- Already in symbol check
- Daily drawdown limit (3% max daily loss)
- Portfolio exposure check (max 20% in any single position)
- Position sized using fixed fractional risk (2% of equity per trade)
- ATR-based stop loss calculation
- Bracket orders: every entry comes with automatic stop loss + take profit

### 5. Self-Learning
After every closed trade, the bot records:
- Symbol, entry/exit price, return %
- Feature values at entry
- Signal that triggered the trade

Every 50 trade outcomes, the model automatically retrains incorporating  
the real outcomes of its own decisions — improving over time.

The model also retrains every 24 hours on fresh market data.

---

## Configuration (`config.json`)

```json
{
  "alpaca_api_key": "YOUR_KEY",
  "alpaca_secret_key": "YOUR_SECRET",
  
  "watchlist": ["AAPL", "MSFT", "NVDA", "GOOGL", "AMZN", "TSLA", "SPY", "QQQ"],
  
  "risk": {
    "max_position_pct": 0.05,        // Max 5% of portfolio in one trade
    "risk_per_trade_pct": 0.02,      // Risk 2% of equity per trade
    "max_open_positions": 8,          // Hold at most 8 positions
    "stop_loss_pct": 0.05,           // 5% stop loss
    "take_profit_pct": 0.10,         // 10% take profit target
    "trailing_stop_pct": 0.03        // Trailing stop of 3%
  },
  
  "ml": {
    "retrain_interval_hours": 24,    // Retrain every 24 hours
    "confidence_threshold": 0.62,    // Minimum ML confidence to trade
    "lookback_days": 120             // Training data window
  }
}
```

---

## Command Line Usage

```bash
# Paper trading (safe, recommended first)
python bot.py --mode paper

# Paper trading with live dashboard
python bot.py --mode paper --dashboard

# Force retrain ML model on startup
python bot.py --mode paper --retrain

# Run 90-day backtest
python bot.py --backtest --backtest-days 90

# Live trading (real money — read warnings carefully)
python bot.py --mode live
```

---

## Paper → Live Trading Criteria

The bot will tell you when it's ready for live trading. Criteria:

| Requirement | Default | Your Result |
|---|---|---|
| Days of paper trading | ≥ 30 | — |
| Total trades taken | ≥ 50 | — |
| Win rate | ≥ 52% | — |
| Sharpe ratio | ≥ 1.0 | — |

Run option 3 in `START.bat` to check your current status.

---

## Files & Folders

```
alphabot/
├── bot.py                  ← Main entry point
├── config.json             ← Your configuration (add API keys here)
├── requirements.txt        ← Python dependencies
├── START.bat               ← Windows launcher (double-click this)
├── core/
│   ├── broker.py           ← Alpaca API wrapper
│   ├── engine.py           ← Main trading loop
│   ├── risk.py             ← Risk management
│   ├── config.py           ← Config loader
│   ├── logger.py           ← Logging
│   └── dashboard.py        ← Terminal dashboard
├── ml/
│   └── ml_engine.py        ← ML model + feature engineering
├── models/                 ← Trained model files (auto-created)
├── trades/                 ← Trade history + daily stats
└── logs/                   ← Log files
```

---

## Important Warnings

**THIS IS NOT FINANCIAL ADVICE.**

- Algorithmic trading involves substantial risk of loss
- Past performance does not guarantee future results
- Never risk money you cannot afford to lose
- Always run paper trading first and validate performance
- The bot cannot guarantee profits — markets are unpredictable
- Monitor the bot regularly, especially in live mode
- Consider consulting a licensed financial advisor

By using this software you acknowledge you understand and accept these risks.

---

## Getting API Keys (Free)

1. Go to https://alpaca.markets
2. Create a free account
3. Click "Paper Trading" in the sidebar
4. Go to API Keys → click "Generate"
5. Copy the Key ID and Secret Key into config.json

For live trading, you'll need to complete identity verification on Alpaca.

---

## Troubleshooting

**"Cannot connect to broker"**  
→ Check your API keys in config.json  
→ Make sure you're using PAPER keys for paper mode  

**"ML model needs retrain" on every start**  
→ Normal on first run, wait for training to complete (~2 min)  

**"Insufficient training data"**  
→ Some symbols in your watchlist may not have enough history  
→ Try adding more liquid stocks (SPY, QQQ, AAPL, etc.)  

**Orders not executing**  
→ Check market hours (US: 9:30am–4pm ET, weekdays)  
→ Check buying power in your Alpaca account  
