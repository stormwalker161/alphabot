# -*- coding: utf-8 -*-
import sys
if hasattr(sys.stdout, 'reconfigure'): sys.stdout.reconfigure(encoding='utf-8')
"""
AlphaBot - AI Trading Bot
Main entry point. Run: python bot.py
"""

import sys
import os
import time
import argparse
import logging
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.config import Config
from core.broker import AlpacaBroker
from core.engine import TradingEngine
from core.logger import setup_logger
from core.dashboard import Dashboard


def parse_args():
    parser = argparse.ArgumentParser(description="AlphaBot AI Trading Bot")
    parser.add_argument("--mode", choices=["paper", "live"], default="paper",
                        help="Trading mode: paper (safe) or live (real money)")
    parser.add_argument("--config", default="config.json",
                        help="Path to config file")
    parser.add_argument("--retrain", action="store_true",
                        help="Force retrain ML models on startup")
    parser.add_argument("--dashboard", action="store_true",
                        help="Show live dashboard")
    parser.add_argument("--backtest", action="store_true",
                        help="Run backtest instead of live trading")
    parser.add_argument("--backtest-days", type=int, default=90,
                        help="Days of history for backtest")
    parser.add_argument("--scan", action="store_true",
                        help="Run stock scanner and show top opportunities")
    return parser.parse_args()


def main():
    args = parse_args()
    logger = setup_logger("alphabot", "logs/alphabot.log")

    print("""
+===============================================+
|           AlphaBot AI Trading System          |
|         github.com/your-username/alphabot     |
+===============================================+
""")

    # Load config
    config = Config(args.config)

    # Safety check for live mode
    if args.mode == "live":
        print("\n⚠️  WARNING: LIVE TRADING MODE - REAL MONEY AT RISK")
        print("   The bot will execute real trades using your brokerage account.")
        print("   Ensure you have tested thoroughly in paper mode first.\n")
        confirm = input("Type 'I UNDERSTAND THE RISKS' to continue: ")
        if confirm != "I UNDERSTAND THE RISKS":
            print("Live mode cancelled. Starting in paper mode instead.")
            args.mode = "paper"

    logger.info(f"Starting AlphaBot in {args.mode.upper()} mode")
    print(f"Mode: {args.mode.upper()}")
    print(f"Strategy: {config.get('strategy', 'combined')}")
    print(f"Markets: {', '.join(config.get('markets', ['stocks']))}")
    print(f"Watchlist: {', '.join(config.get('watchlist', []))}")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    # Initialize broker
    broker = AlpacaBroker(config, paper=(args.mode == "paper"))

    # Test connection
    print("Connecting to broker...")
    if not broker.test_connection():
        print("\n❌ Cannot connect to broker.")
        print("   Please check your API keys in config.json")
        print("   Get free paper trading keys at: https://alpaca.markets\n")
        sys.exit(1)

    account = broker.get_account()
    print(f"✓ Connected | Account: ${float(account.get('equity', 0)):,.2f} | "
          f"Buying Power: ${float(account.get('buying_power', 0)):,.2f}\n")

    # Initialize trading engine
    engine = TradingEngine(config, broker, paper=(args.mode == "paper"))

    if args.retrain:
        print("Retraining ML models...")
        engine.ml_engine.force_retrain()

    if args.scan:
        from data.scanner import AutoScanner
        scanner = AutoScanner(config)
        scanner.print_top_opportunities(20)
        answer = input("Add top stocks to watchlist automatically? (y/n): ")
        if answer.lower() == "y":
            changes = scanner.update_watchlist()
            for c in changes:
                print(f"  {c}")
            print(f"\nWatchlist updated. Run --retrain to train on new stocks.")
        return

    if args.backtest:
        print(f"Running backtest ({args.backtest_days} days)...")
        results = engine.run_backtest(days=args.backtest_days)
        print_backtest_results(results)
        return

    # Start dashboard in background if requested
    if args.dashboard:
        dashboard = Dashboard(engine)
        dashboard.start()

    # Main trading loop
    print("Bot is running. Press Ctrl+C to stop.\n")
    try:
        engine.run()
    except KeyboardInterrupt:
        print("\n\nShutting down AlphaBot...")
        engine.shutdown()
        print("✓ Bot stopped cleanly. Trades saved to trades/history.json")


def print_backtest_results(results):
    print("\n" + "="*50)
    print("BACKTEST RESULTS")
    print("="*50)
    print(f"Total Return:     {results.get('total_return_pct', 0):+.2f}%")
    print(f"Sharpe Ratio:     {results.get('sharpe_ratio', 0):.2f}")
    print(f"Max Drawdown:     {results.get('max_drawdown_pct', 0):.2f}%")
    print(f"Win Rate:         {results.get('win_rate', 0):.1f}%")
    print(f"Total Trades:     {results.get('total_trades', 0)}")
    print(f"Profit Factor:    {results.get('profit_factor', 0):.2f}")
    print("="*50 + "\n")


if __name__ == "__main__":
    main()
