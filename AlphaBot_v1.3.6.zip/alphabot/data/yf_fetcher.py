"""
Yahoo Finance data fetcher - used for ML training data.
Free, no API key needed, rich historical data.
Alpaca is still used for live order execution.
"""

import logging

logger = logging.getLogger("alphabot.data")

try:
    import yfinance as yf
    HAS_YF = True
except ImportError:
    HAS_YF = False
    logger.warning("yfinance not installed")

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False


def fetch_bars_yf(symbol, period="6mo", interval="1d"):
    """
    Fetch OHLCV bars from Yahoo Finance.
    Returns list of dicts with keys: o, h, l, c, v (same format as Alpaca)
    """
    if not HAS_YF or not HAS_PANDAS:
        return []

    try:
        ticker = yf.Ticker(symbol)
        df = ticker.history(period=period, interval=interval, auto_adjust=True)

        if df is None or df.empty:
            logger.warning(f"No data from Yahoo Finance for {symbol}")
            return []

        bars = []
        for ts, row in df.iterrows():
            bars.append({
                "t": str(ts),
                "o": float(row["Open"]),
                "h": float(row["High"]),
                "l": float(row["Low"]),
                "c": float(row["Close"]),
                "v": float(row["Volume"])
            })

        logger.info(f"Fetched {len(bars)} bars for {symbol} from Yahoo Finance")
        return bars

    except Exception as e:
        logger.error(f"Yahoo Finance fetch failed for {symbol}: {e}")
        return []


def fetch_multi_bars_yf(symbols, period="6mo", interval="1d"):
    """
    Fetch bars for multiple symbols from Yahoo Finance.
    Returns dict: {symbol: [bars]}
    """
    result = {}
    for symbol in symbols:
        bars = fetch_bars_yf(symbol, period=period, interval=interval)
        if bars:
            result[symbol] = bars
        else:
            logger.warning(f"Skipping {symbol} - no data")
    logger.info(f"Got training data for {len(result)}/{len(symbols)} symbols")
    return result
