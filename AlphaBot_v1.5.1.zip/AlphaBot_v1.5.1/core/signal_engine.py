"""
SignalEngine - Multi-source signal fusion for AlphaBot
======================================================
Fuses five independent signal layers into a single composite TradeSignal
score (0-100) and generates BUY / SELL / NEUTRAL / STRONG_BUY / STRONG_SELL
action recommendations with full per-source breakdowns.

Signal sources
--------------
  TechnicalSignal  — RSI, MACD, VWAP deviation, EMA crossover     (default 35%)
  MomentumSignal   — price breakout level, volume surge ratio      (default 25%)
  NewsSignal       — VADER sentiment score (-1 … +1)               (default 20%)
  SocialSignal     — StockTwits sentiment + momentum spike flag     (default 10%)
  MacroSignal      — FRED-based regime (RISK_ON/RISK_OFF/NEUTRAL)  (default 10%)

Composite score bands
---------------------
  75-100  STRONG_BUY
  65-74   WEAK_BUY        <- BUY action requires score >= 65 AND 3-of-5 agree
  56-64   LEAN_BUY        (no action, just leaning)
  45-55   NEUTRAL
  36-44   LEAN_SELL       (no action)
  31-35   WEAK_SELL       <- SELL action requires score <= 35 AND 3-of-5 agree
  0-30    STRONG_SELL

Integration with engine.py
--------------------------
    from core.signal_engine import SignalEngine, TechnicalSignal, MomentumSignal

    # build once in TradingEngine.__init__
    self.signal_engine = SignalEngine()

    # in execute_signals(), per symbol
    tech  = TechnicalSignal(rsi=42.1, macd=0.35, macd_signal=0.18,
                             vwap_dev=-0.003, ema_cross="bullish")
    mom   = MomentumSignal(breakout_pct=2.3, volume_ratio=1.8)
    news  = NewsSignal(score=0.42)              # from CombinedIntelligence
    soc   = SocialSignal(sentiment=-0.1, momentum_spike=False)
    macro = MacroSignal(regime="RISK_ON")

    result = self.signal_engine.evaluate(symbol, tech, mom, news, soc, macro)
    if result.action in ("BUY", "STRONG_BUY"):
        ...
    logger.info(self.signal_engine.explain_signal(symbol))

All numeric internals use pure Python / stdlib — no pandas, numpy, or new
dependencies required. Windows-safe, thread-safe on reads (no shared mutable
state per evaluation call).
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger("alphabot.signal_engine")


# ══════════════════════════════════════════════════════════════════════════════
#  Input dataclasses — one per signal source
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TechnicalSignal:
    """
    Classic technical analysis inputs.

    rsi          : 0-100.  >70 overbought, <30 oversold.
    macd         : MACD line value (raw, any scale).
    macd_signal  : Signal line value. macd > macd_signal => bullish crossover.
    vwap_dev     : (price - VWAP) / VWAP, e.g. +0.005 = 0.5% above VWAP.
    ema_cross    : "bullish" (fast > slow), "bearish" (fast < slow), or "none".
    rsi_weight   : Internal sub-weight applied during normalization (0-1).
    macd_weight  : Internal sub-weight.
    vwap_weight  : Internal sub-weight.
    ema_weight   : Internal sub-weight.
    """
    rsi:         float          # 0-100
    macd:        float = 0.0   # raw MACD value
    macd_signal: float = 0.0   # raw MACD signal line
    vwap_dev:    float = 0.0   # fractional deviation from VWAP
    ema_cross:   str   = "none" # "bullish" | "bearish" | "none"

    # Sub-weights within the Technical layer (auto-normalized to 1.0)
    rsi_weight:  float = 0.35
    macd_weight: float = 0.30
    vwap_weight: float = 0.20
    ema_weight:  float = 0.15


@dataclass
class MomentumSignal:
    """
    Price and volume momentum inputs.

    breakout_pct  : % price move above a recent resistance level (0 = no breakout).
                    Negative values indicate breakdown below support.
    volume_ratio  : current_volume / average_volume. 1.0 = normal, 2.0 = double.
    """
    breakout_pct: float = 0.0   # percent, e.g. 2.3 = 2.3% above resistance
    volume_ratio: float = 1.0   # >= 1.5 considered a volume surge


@dataclass
class NewsSignal:
    """
    VADER / NLP sentiment score from NewsIntelligence.

    score         : -1.0 (very negative) … +1.0 (very positive).
    headline_count: number of headlines in the window. Low count = lower confidence.
    """
    score:          float = 0.0
    headline_count: int   = 0


@dataclass
class SocialSignal:
    """
    StockTwits / social media signal from SocialSentiment.

    sentiment      : weighted VADER average, -1 … +1.
    momentum_spike : True if mention rate is > spike_multiplier × baseline.
    mentions_2h    : raw mention count for confidence weighting.
    """
    sentiment:      float = 0.0
    momentum_spike: bool  = False
    mentions_2h:    int   = 0


@dataclass
class MacroSignal:
    """
    Macro regime from MacroIntelligence.

    regime : "RISK_ON" | "RISK_OFF" | "NEUTRAL"
    """
    regime: str = "NEUTRAL"   # "RISK_ON" | "RISK_OFF" | "NEUTRAL"


# ══════════════════════════════════════════════════════════════════════════════
#  Output dataclass
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class TradeSignal:
    """
    The fully-fused trade recommendation produced by SignalEngine.evaluate().

    Fields
    ------
    ticker              : symbol evaluated
    composite_score     : 0-100 blended score
    action              : STRONG_BUY | BUY | LEAN_BUY | NEUTRAL |
                          LEAN_SELL | SELL | STRONG_SELL
    direction_agreement : number of sources agreeing with the dominant direction
    dominant_direction  : "bullish" | "bearish" | "neutral"

    Per-source scores (each 0-100 scale before weighting):
      technical_score   : normalized technical sub-score
      momentum_score    : normalized momentum sub-score
      news_score        : normalized news sub-score
      social_score      : normalized social sub-score
      macro_score       : normalized macro sub-score

    Per-source contributions (score × effective_weight):
      technical_contribution  : points added to composite
      momentum_contribution   : ...
      news_contribution       : ...
      social_contribution     : ...
      macro_contribution      : ...

    effective_weights   : dict of actual weights used (after any dynamic scaling)
    raw_inputs          : snapshot of the five input objects
    timestamp           : UTC ISO string of evaluation time
    """
    ticker:              str
    composite_score:     float
    action:              str

    direction_agreement: int   = 0
    dominant_direction:  str   = "neutral"

    # Normalized per-source scores (0-100)
    technical_score:     float = 50.0
    momentum_score:      float = 50.0
    news_score:          float = 50.0
    social_score:        float = 50.0
    macro_score:         float = 50.0

    # Weighted contributions to composite
    technical_contribution: float = 0.0
    momentum_contribution:  float = 0.0
    news_contribution:      float = 0.0
    social_contribution:    float = 0.0
    macro_contribution:     float = 0.0

    effective_weights:   Dict[str, float] = field(default_factory=dict)
    raw_inputs:          Dict[str, object] = field(default_factory=dict)
    timestamp:           str = ""

    # Cached explanation string (populated on demand)
    _explanation:        str = field(default="", repr=False)


# ══════════════════════════════════════════════════════════════════════════════
#  SignalEngine
# ══════════════════════════════════════════════════════════════════════════════

class SignalEngine:
    """
    Fuses TechnicalSignal, MomentumSignal, NewsSignal, SocialSignal, and
    MacroSignal into a composite TradeSignal score (0-100) with action label.

    Usage
    -----
    engine = SignalEngine()                          # default weights
    engine = SignalEngine(weights={                  # custom weights (auto-norm)
        "technical": 0.40, "momentum": 0.30,
        "news": 0.15, "social": 0.05, "macro": 0.10
    })

    result = engine.evaluate("AAPL", tech, mom, news, soc, macro)
    print(result.action, result.composite_score)
    print(engine.explain_signal("AAPL"))

    Thread-safety
    -------------
    evaluate() writes to self._last_result (per-ticker). The internal lock
    protects that dict, so concurrent calls for different tickers are safe.
    Concurrent calls for the SAME ticker from two threads should be avoided
    at the call site (the trading engine naturally does one symbol at a time).
    """

    # Score band boundaries
    STRONG_BUY_MIN  = 75
    BUY_MIN         = 65
    LEAN_BUY_MIN    = 56
    LEAN_SELL_MAX   = 44
    SELL_MAX        = 35
    STRONG_SELL_MAX = 30

    # Consensus requirement: how many of 5 sources must agree for a BUY/SELL action
    CONSENSUS_REQUIRED = 3

    # Default weights (must sum to 1.0; enforced via normalization)
    DEFAULT_WEIGHTS: Dict[str, float] = {
        "technical": 0.35,
        "momentum":  0.25,
        "news":      0.20,
        "social":    0.10,
        "macro":     0.10,
    }

    def __init__(self, weights: Optional[Dict[str, float]] = None):
        raw = weights if weights else dict(self.DEFAULT_WEIGHTS)
        self._base_weights = self._normalize_weights(raw)
        self._lock = threading.Lock()
        self._last_result: Dict[str, TradeSignal] = {}
        logger.info(
            "SignalEngine initialized | weights: "
            + " | ".join(f"{k}={v:.0%}" for k, v in self._base_weights.items())
        )

    # ── weight management ─────────────────────────────────────────────────────

    @staticmethod
    def _normalize_weights(w: Dict[str, float]) -> Dict[str, float]:
        """Ensure weights for the five keys are non-negative and sum to 1.0."""
        keys = ("technical", "momentum", "news", "social", "macro")
        clean = {k: max(0.0, float(w.get(k, 0.0))) for k in keys}
        total = sum(clean.values())
        if total <= 0:
            # Fallback to equal weights
            return {k: 1.0 / len(keys) for k in keys}
        return {k: v / total for k, v in clean.items()}

    def set_weights(self, weights: Dict[str, float]):
        """Dynamically update weights (e.g. from a UI or config reload)."""
        with self._lock:
            self._base_weights = self._normalize_weights(weights)
        logger.info(
            "SignalEngine weights updated | "
            + " | ".join(f"{k}={v:.0%}" for k, v in self._base_weights.items())
        )

    def get_weights(self) -> Dict[str, float]:
        """Return a copy of the current base weights."""
        with self._lock:
            return dict(self._base_weights)

    # ── per-source normalizers (raw inputs -> 0-100 score) ────────────────────

    @staticmethod
    def _norm_technical(sig: TechnicalSignal) -> Tuple[float, str]:
        """
        Combine RSI, MACD crossover, VWAP deviation, and EMA cross into a
        single 0-100 score. Returns (score, direction).
        """
        # RSI sub-score: 0 at RSI=0, 100 at RSI=100 but we invert extremes
        # Oversold (<30) is bullish, overbought (>70) is bearish.
        # Treat RSI linearly: map 0->0, 50->50, 100->100 as a raw thermometer.
        # A score of 50 is perfectly neutral (RSI=50 means no lean).
        rsi_score = max(0.0, min(100.0, sig.rsi))

        # MACD sub-score: focus on crossover direction and distance
        # macd - macd_signal: positive = bullish momentum.
        # We map to 0-100 with a soft cap at ±1.0 of raw MACD units.
        macd_diff = sig.macd - sig.macd_signal
        # Normalize: cap at ±2 standard 'units' then map to 0-100
        macd_capped = max(-2.0, min(2.0, macd_diff))
        macd_score = (macd_capped / 2.0) * 50.0 + 50.0  # 0-100

        # VWAP sub-score: above VWAP is bullish, below is bearish
        # vwap_dev: +0.02 = 2% above VWAP; cap at ±5%
        vwap_capped = max(-0.05, min(0.05, sig.vwap_dev))
        vwap_score = (vwap_capped / 0.05) * 50.0 + 50.0  # 0-100

        # EMA crossover sub-score
        ema_map = {"bullish": 75.0, "bearish": 25.0, "none": 50.0}
        ema_score = ema_map.get(str(sig.ema_cross).lower(), 50.0)

        # Normalize sub-weights
        total_sw = sig.rsi_weight + sig.macd_weight + sig.vwap_weight + sig.ema_weight
        if total_sw <= 0:
            total_sw = 1.0
        rw = sig.rsi_weight  / total_sw
        mw = sig.macd_weight / total_sw
        vw = sig.vwap_weight / total_sw
        ew = sig.ema_weight  / total_sw

        score = (rsi_score * rw + macd_score * mw +
                 vwap_score * vw + ema_score * ew)

        direction = "bullish" if score > 55 else ("bearish" if score < 45 else "neutral")
        return round(score, 2), direction

    @staticmethod
    def _norm_momentum(sig: MomentumSignal) -> Tuple[float, str]:
        """
        Breakout percentage and volume surge -> 0-100.

        breakout_pct: cap at ±10%. At 0% = 50, +3% ≈ 65, -3% ≈ 35.
        volume_ratio: >= 2.0 = maximum boost of +12 pts, no volume = no boost.
        """
        bp_capped = max(-10.0, min(10.0, sig.breakout_pct))
        bp_score  = (bp_capped / 10.0) * 40.0 + 50.0   # 10-90 range

        # Volume multiplier: only adds to the score (confirmation), doesn't subtract
        vr = sig.volume_ratio
        if vr >= 2.0:
            vol_boost = 12.0
        elif vr >= 1.5:
            vol_boost = 6.0
        elif vr >= 1.2:
            vol_boost = 2.0
        else:
            vol_boost = 0.0

        # Apply volume boost in the direction of the breakout
        if bp_score > 50:
            score = min(100.0, bp_score + vol_boost)
        elif bp_score < 50:
            score = max(0.0, bp_score - vol_boost)
        else:
            score = bp_score

        direction = "bullish" if score > 55 else ("bearish" if score < 45 else "neutral")
        return round(score, 2), direction

    @staticmethod
    def _norm_news(sig: NewsSignal) -> Tuple[float, str]:
        """
        VADER compound score (-1 … +1) -> 0-100.
        Low headline count applies a confidence penalty toward 50.
        """
        raw = max(-1.0, min(1.0, sig.score))
        base_score = raw * 50.0 + 50.0   # -1 -> 0, 0 -> 50, +1 -> 100

        # Confidence penalty: fade toward 50 when we have fewer headlines
        if sig.headline_count <= 0:
            score = 50.0          # no data → perfectly neutral
        elif sig.headline_count < 3:
            fade = 0.5            # 50% fade toward neutral
            score = base_score * (1.0 - fade) + 50.0 * fade
        else:
            score = base_score    # full confidence

        direction = "bullish" if score > 55 else ("bearish" if score < 45 else "neutral")
        return round(score, 2), direction

    @staticmethod
    def _norm_social(sig: SocialSignal) -> Tuple[float, str]:
        """
        StockTwits sentiment + momentum spike -> 0-100.
        Spike: +10 in the direction of sentiment (capped).
        Low mention count fades toward 50.
        """
        raw = max(-1.0, min(1.0, sig.sentiment))
        base_score = raw * 50.0 + 50.0

        # Confidence penalty for thin data
        if sig.mentions_2h < 3:
            fade = 0.6
            base_score = base_score * (1.0 - fade) + 50.0 * fade

        # Momentum spike: amplify the existing lean (not the direction)
        if sig.momentum_spike:
            if base_score > 50:
                base_score = min(100.0, base_score + 10.0)
            elif base_score < 50:
                base_score = max(0.0, base_score - 10.0)

        direction = "bullish" if base_score > 55 else ("bearish" if base_score < 45 else "neutral")
        return round(base_score, 2), direction

    @staticmethod
    def _norm_macro(sig: MacroSignal) -> Tuple[float, str]:
        """
        Regime string -> fixed 0-100 score.
        RISK_ON=70, NEUTRAL=50, RISK_OFF=30.
        """
        regime_map = {"RISK_ON": 70.0, "NEUTRAL": 50.0, "RISK_OFF": 30.0}
        score = regime_map.get(str(sig.regime).upper(), 50.0)
        direction = "bullish" if score > 55 else ("bearish" if score < 45 else "neutral")
        return score, direction

    # ── dynamic weight modulation ─────────────────────────────────────────────

    def _compute_effective_weights(
        self,
        tech_dir: str,
        mom_dir:  str,
        news_dir: str,
        soc_dir:  str,
        mac_dir:  str,
        news_sig: NewsSignal,
        soc_sig:  SocialSignal,
        macro_sig: MacroSignal,
    ) -> Dict[str, float]:
        """
        Apply dynamic adjustments on top of base weights.

        Rules applied in order (each operates on the running weight dict):
          1. Low-data penalty: news with < 3 headlines loses 40% of its weight.
             social with < 3 mentions loses 50% of its weight.
             Reclaimed weight flows proportionally to technical + momentum.
          2. RISK_OFF macro: macro weight doubles (up to a cap of 0.20).
             The extra weight comes equally from news and social.
          3. Momentum spike: social weight gains +50% of its own weight.
             Offset from news.

        Final weights are always re-normalized to sum to 1.0.
        """
        with self._lock:
            w = dict(self._base_weights)

        # 1. Low-data penalties
        penalty_pool = 0.0
        if news_sig.headline_count < 3:
            cut = w["news"] * 0.40
            w["news"] -= cut
            penalty_pool += cut
        if soc_sig.mentions_2h < 3:
            cut = w["social"] * 0.50
            w["social"] -= cut
            penalty_pool += cut
        if penalty_pool > 0:
            # Redistribute penalty to technical and momentum proportionally
            tm_total = w["technical"] + w["momentum"]
            if tm_total > 0:
                w["technical"] += penalty_pool * (w["technical"] / tm_total)
                w["momentum"]  += penalty_pool * (w["momentum"]  / tm_total)
            else:
                w["technical"] += penalty_pool * 0.6
                w["momentum"]  += penalty_pool * 0.4

        # 2. RISK_OFF macro amplification
        if macro_sig.regime == "RISK_OFF":
            gain = min(w["macro"] * 1.0, 0.20 - w["macro"])  # double, cap at 0.20
            if gain > 0:
                take_news   = gain * 0.5
                take_social = gain * 0.5
                take_news   = min(take_news,   w["news"])
                take_social = min(take_social, w["social"])
                w["macro"]  += take_news + take_social
                w["news"]   -= take_news
                w["social"] -= take_social

        # 3. Momentum spike social boost
        if soc_sig.momentum_spike:
            gain = w["social"] * 0.50
            take_news = min(gain, w["news"])
            w["social"] += take_news
            w["news"]   -= take_news

        return self._normalize_weights(w)

    # ── consensus check ───────────────────────────────────────────────────────

    @staticmethod
    def _count_agreement(
        directions: List[str], target: str
    ) -> int:
        """Count how many of the 5 directions match target ('bullish'/'bearish')."""
        return sum(1 for d in directions if d == target)

    # ── action label ─────────────────────────────────────────────────────────

    def _score_to_band(self, score: float) -> str:
        """Convert 0-100 score to band label (no consensus check here)."""
        if score >= self.STRONG_BUY_MIN:
            return "STRONG_BUY"
        if score >= self.BUY_MIN:
            return "WEAK_BUY"
        if score >= self.LEAN_BUY_MIN:
            return "LEAN_BUY"
        if score > self.LEAN_SELL_MAX:
            return "NEUTRAL"
        if score > self.SELL_MAX:
            return "LEAN_SELL"
        if score > self.STRONG_SELL_MAX:
            return "WEAK_SELL"
        return "STRONG_SELL"

    def _resolve_action(
        self,
        score: float,
        band:  str,
        bullish_agree: int,
        bearish_agree: int,
    ) -> str:
        """
        Map band + consensus into an actionable label.

        BUY  : score >= 65 AND bullish_agree >= CONSENSUS_REQUIRED
        SELL : score <= 35 AND bearish_agree >= CONSENSUS_REQUIRED
        Otherwise: return the band label (no execution action).
        """
        if score >= self.BUY_MIN and bullish_agree >= self.CONSENSUS_REQUIRED:
            return "STRONG_BUY" if score >= self.STRONG_BUY_MIN else "BUY"
        if score <= self.SELL_MAX and bearish_agree >= self.CONSENSUS_REQUIRED:
            return "STRONG_SELL" if score <= self.STRONG_SELL_MAX else "SELL"
        # Consensus not met — downgrade to the lean label so callers know
        # the score is there but the signal isn't confirmed.
        return band

    # ══════════════════════════════════════════════════════════════════════════
    #  Main entry point
    # ══════════════════════════════════════════════════════════════════════════

    def evaluate(
        self,
        ticker:    str,
        technical: TechnicalSignal,
        momentum:  MomentumSignal,
        news:      NewsSignal,
        social:    SocialSignal,
        macro:     MacroSignal,
    ) -> TradeSignal:
        """
        Fuse all five signal sources into a TradeSignal.

        Parameters
        ----------
        ticker    : stock symbol (used for logging and caching)
        technical : TechnicalSignal
        momentum  : MomentumSignal
        news      : NewsSignal
        social    : SocialSignal
        macro     : MacroSignal

        Returns
        -------
        TradeSignal with composite score, action, and full breakdown.
        """
        ticker = ticker.upper().strip()

        # Step 1 — Normalize each source to 0-100
        tech_score, tech_dir = self._norm_technical(technical)
        mom_score,  mom_dir  = self._norm_momentum(momentum)
        news_score, news_dir = self._norm_news(news)
        soc_score,  soc_dir  = self._norm_social(social)
        mac_score,  mac_dir  = self._norm_macro(macro)

        # Step 2 — Dynamic weight computation
        eff_w = self._compute_effective_weights(
            tech_dir, mom_dir, news_dir, soc_dir, mac_dir,
            news, social, macro,
        )

        # Step 3 — Weighted composite score
        tech_contrib = tech_score * eff_w["technical"]
        mom_contrib  = mom_score  * eff_w["momentum"]
        news_contrib = news_score * eff_w["news"]
        soc_contrib  = soc_score  * eff_w["social"]
        mac_contrib  = mac_score  * eff_w["macro"]

        composite = (tech_contrib + mom_contrib + news_contrib +
                     soc_contrib  + mac_contrib)
        composite = round(max(0.0, min(100.0, composite)), 2)

        # Step 4 — Consensus counting
        directions = [tech_dir, mom_dir, news_dir, soc_dir, mac_dir]
        bull_agree = self._count_agreement(directions, "bullish")
        bear_agree = self._count_agreement(directions, "bearish")
        dominant   = ("bullish" if bull_agree > bear_agree
                      else ("bearish" if bear_agree > bull_agree else "neutral"))

        # Step 5 — Band + action
        band   = self._score_to_band(composite)
        action = self._resolve_action(composite, band, bull_agree, bear_agree)

        # Step 6 — Build result
        result = TradeSignal(
            ticker=ticker,
            composite_score=composite,
            action=action,
            direction_agreement=max(bull_agree, bear_agree),
            dominant_direction=dominant,
            technical_score=tech_score,
            momentum_score=mom_score,
            news_score=news_score,
            social_score=soc_score,
            macro_score=mac_score,
            technical_contribution=round(tech_contrib, 3),
            momentum_contribution=round(mom_contrib, 3),
            news_contribution=round(news_contrib, 3),
            social_contribution=round(soc_contrib, 3),
            macro_contribution=round(mac_contrib, 3),
            effective_weights={k: round(v, 4) for k, v in eff_w.items()},
            raw_inputs={
                "technical": technical,
                "momentum":  momentum,
                "news":      news,
                "social":    social,
                "macro":     macro,
            },
            timestamp=datetime.utcnow().isoformat(timespec="seconds") + "Z",
        )

        # Step 7 — Log full breakdown
        self._log_signal(ticker, result, directions)

        # Step 8 — Cache for explain_signal()
        with self._lock:
            self._last_result[ticker] = result

        return result

    # ── logging ───────────────────────────────────────────────────────────────

    @staticmethod
    def _log_signal(ticker: str, r: TradeSignal, directions: List[str]):
        source_names = ["technical", "momentum", "news", "social", "macro"]
        scores  = [r.technical_score, r.momentum_score,
                   r.news_score, r.social_score, r.macro_score]
        contribs = [r.technical_contribution, r.momentum_contribution,
                    r.news_contribution, r.social_contribution, r.macro_contribution]
        weights = r.effective_weights

        logger.info(
            f"SIGNAL [{ticker}] composite={r.composite_score:.1f}/100 "
            f"action={r.action} | "
            f"consensus={r.direction_agreement}/5 {r.dominant_direction}"
        )
        for name, score, direction, contrib in zip(
                source_names, scores, directions, contribs):
            w = weights.get(name, 0.0)
            logger.info(
                f"  {name:<12} score={score:>6.1f}/100  "
                f"weight={w:.0%}  contrib={contrib:>5.1f}  "
                f"dir={direction}"
            )

    # ── explain_signal ────────────────────────────────────────────────────────

    def explain_signal(self, ticker: str) -> str:
        """
        Return a plain-English explanation of the most recent TradeSignal
        for the given ticker.

        If no signal has been evaluated yet for this ticker, returns a
        short message saying so.

        Example output
        --------------
        AAPL — STRONG_BUY (score: 81.4/100) [2026-04-09T14:32:01Z]

        Summary: A strong buy signal was generated with 4 of 5 sources
        agreeing on a bullish outlook.

        Source breakdown:
          ✅ Technical  (35%): 73.2/100 — Bullish.  RSI=54.1, MACD crossover
             positive (+0.35), price sitting 0.5% above VWAP, and EMA fast
             has crossed above slow.
          ✅ Momentum   (25%): 78.0/100 — Bullish.  Price broke out +2.3%
             above resistance on 1.8× average volume (confirmed surge).
          ✅ News       (20%): 72.0/100 — Bullish.  VADER sentiment score
             +0.44 from 12 headlines in the last 4 hours.
          ⚪ Social     (10%): 51.0/100 — Neutral.  Thin StockTwits data
             (2 mentions). Score faded toward neutral.
          ✅ Macro      (10%): 70.0/100 — Bullish.  Macro regime is RISK_ON,
             adding a mild tailwind to all positions.

        Why this fired: Composite score of 81.4 exceeds the 65-point BUY
        threshold, and 4 of 5 sources are directionally aligned (≥3 required).
        The signal is classified STRONG_BUY (≥75).
        """
        ticker = ticker.upper().strip()
        with self._lock:
            r = self._last_result.get(ticker)

        if r is None:
            return (
                f"{ticker} — No signal evaluated yet. "
                f"Call evaluate() for this ticker first."
            )

        if r._explanation:
            return r._explanation

        lines: List[str] = []

        # ── Header ───────────────────────────────────────────────────────────
        lines.append(
            f"{ticker} — {r.action} "
            f"(score: {r.composite_score:.1f}/100) [{r.timestamp}]"
        )
        lines.append("")

        # ── Summary ───────────────────────────────────────────────────────────
        agree_str  = f"{r.direction_agreement} of 5 sources"
        direction  = r.dominant_direction
        lines.append("Summary:")
        if r.action in ("BUY", "STRONG_BUY"):
            lines.append(
                f"  A {'strong ' if r.action == 'STRONG_BUY' else ''}buy signal was "
                f"generated with {agree_str} agreeing on a {direction} outlook."
            )
        elif r.action in ("SELL", "STRONG_SELL"):
            lines.append(
                f"  A {'strong ' if r.action == 'STRONG_SELL' else ''}sell signal "
                f"was generated with {agree_str} agreeing on a {direction} outlook."
            )
        else:
            lines.append(
                f"  The signal is {r.action} (no trade action). "
                f"{agree_str} agree directionally ({direction})."
            )
        lines.append("")

        # ── Per-source breakdown ──────────────────────────────────────────────
        lines.append("Source breakdown:")

        raw    = r.raw_inputs
        tech   = raw.get("technical")
        mom    = raw.get("momentum")
        news   = raw.get("news")
        soc    = raw.get("social")
        macro  = raw.get("macro")
        ew     = r.effective_weights

        def _bullet(name, score, direction_, weight, detail):
            icon = "✅" if direction_ == "bullish" else ("❌" if direction_ == "bearish" else "⚪")
            return (
                f"  {icon} {name:<12} ({weight:.0%}): "
                f"{score:.1f}/100 — {direction_.capitalize()}.  {detail}"
            )

        # Technical
        tech_dir   = "bullish" if r.technical_score > 55 else ("bearish" if r.technical_score < 45 else "neutral")
        if tech:
            ema_label = str(tech.ema_cross).lower()
            ema_text  = (f"EMA fast/slow cross is {ema_label}." if ema_label != "none"
                         else "No EMA cross detected.")
            macd_diff = tech.macd - tech.macd_signal
            vwap_pct  = tech.vwap_dev * 100
            tech_detail = (
                f"RSI={tech.rsi:.1f}, "
                f"MACD crossover {'+' if macd_diff >= 0 else ''}{macd_diff:.3f}, "
                f"price {'+' if vwap_pct >= 0 else ''}{vwap_pct:.2f}% vs VWAP, "
                f"{ema_text}"
            )
        else:
            tech_detail = "No raw technical data available."
        lines.append(_bullet("Technical", r.technical_score, tech_dir,
                              ew.get("technical", 0), tech_detail))

        # Momentum
        mom_dir = "bullish" if r.momentum_score > 55 else ("bearish" if r.momentum_score < 45 else "neutral")
        if mom:
            vol_label = (
                "strong surge" if mom.volume_ratio >= 2.0
                else ("moderate surge" if mom.volume_ratio >= 1.5
                      else ("slight uptick" if mom.volume_ratio >= 1.2
                            else "normal volume"))
            )
            if mom.breakout_pct > 0.1:
                bp_text = f"Price broke out +{mom.breakout_pct:.1f}% above resistance"
            elif mom.breakout_pct < -0.1:
                bp_text = f"Price broke down {mom.breakout_pct:.1f}% below support"
            else:
                bp_text = "No significant breakout or breakdown"
            mom_detail = (
                f"{bp_text} on {mom.volume_ratio:.1f}× avg volume ({vol_label})."
            )
        else:
            mom_detail = "No raw momentum data available."
        lines.append(_bullet("Momentum", r.momentum_score, mom_dir,
                              ew.get("momentum", 0), mom_detail))

        # News
        news_dir = "bullish" if r.news_score > 55 else ("bearish" if r.news_score < 45 else "neutral")
        if news:
            conf_note = (
                " (thin data — score faded toward neutral)"
                if news.headline_count < 3 else ""
            )
            news_detail = (
                f"VADER sentiment {'+' if news.score >= 0 else ''}{news.score:.2f} "
                f"from {news.headline_count} headline{'s' if news.headline_count != 1 else ''}"
                f"{conf_note}."
            )
        else:
            news_detail = "No news data available."
        lines.append(_bullet("News", r.news_score, news_dir,
                              ew.get("news", 0), news_detail))

        # Social
        soc_dir = "bullish" if r.social_score > 55 else ("bearish" if r.social_score < 45 else "neutral")
        if soc:
            spike_note = " Momentum spike detected (elevated mention rate)." if soc.momentum_spike else ""
            thin_note  = " Thin data — score faded." if soc.mentions_2h < 3 else ""
            soc_detail = (
                f"StockTwits sentiment {'+' if soc.sentiment >= 0 else ''}{soc.sentiment:.2f}, "
                f"{soc.mentions_2h} mention{'s' if soc.mentions_2h != 1 else ''} in 2h."
                f"{spike_note}{thin_note}"
            )
        else:
            soc_detail = "No social data available."
        lines.append(_bullet("Social", r.social_score, soc_dir,
                              ew.get("social", 0), soc_detail))

        # Macro
        mac_dir = "bullish" if r.macro_score > 55 else ("bearish" if r.macro_score < 45 else "neutral")
        if macro:
            regime_desc = {
                "RISK_ON":  "adding a mild tailwind to all positions",
                "RISK_OFF": "tightening position sizes and confidence thresholds",
                "NEUTRAL":  "no macro adjustment applied",
            }.get(str(macro.regime).upper(), "regime unknown")
            mac_detail = f"Macro regime is {macro.regime}, {regime_desc}."
        else:
            mac_detail = "No macro data available."
        lines.append(_bullet("Macro", r.macro_score, mac_dir,
                              ew.get("macro", 0), mac_detail))

        # ── Why it fired ──────────────────────────────────────────────────────
        lines.append("")
        lines.append("Why this fired:")

        if r.action in ("BUY", "STRONG_BUY"):
            threshold_text = (
                f"Composite score of {r.composite_score:.1f} exceeds the 65-point BUY "
                f"threshold, and {r.direction_agreement} of 5 sources are directionally "
                f"aligned (≥{self.CONSENSUS_REQUIRED} required)."
            )
            band_text = (
                f"The signal is classified {r.action} "
                f"({'≥75' if r.action == 'STRONG_BUY' else '65-74'})."
            )
            lines.append(f"  {threshold_text}")
            lines.append(f"  {band_text}")

        elif r.action in ("SELL", "STRONG_SELL"):
            threshold_text = (
                f"Composite score of {r.composite_score:.1f} falls below the 35-point SELL "
                f"threshold, and {r.direction_agreement} of 5 sources agree bearish "
                f"(≥{self.CONSENSUS_REQUIRED} required)."
            )
            band_text = (
                f"The signal is classified {r.action} "
                f"({'≤30' if r.action == 'STRONG_SELL' else '31-35'})."
            )
            lines.append(f"  {threshold_text}")
            lines.append(f"  {band_text}")

        else:
            # No action fired — explain why
            reasons = []
            if r.composite_score > self.SELL_MAX and r.composite_score < self.BUY_MIN:
                reasons.append(
                    f"score ({r.composite_score:.1f}) is in the no-trade zone "
                    f"({self.SELL_MAX+1}-{self.BUY_MIN-1})"
                )
            if r.dominant_direction == "bullish" and r.direction_agreement < self.CONSENSUS_REQUIRED:
                short = self.CONSENSUS_REQUIRED - r.direction_agreement
                reasons.append(
                    f"bullish consensus is {r.direction_agreement}/5 "
                    f"(need {self.CONSENSUS_REQUIRED}, missing {short} more)"
                )
            if r.dominant_direction == "bearish" and r.direction_agreement < self.CONSENSUS_REQUIRED:
                short = self.CONSENSUS_REQUIRED - r.direction_agreement
                reasons.append(
                    f"bearish consensus is {r.direction_agreement}/5 "
                    f"(need {self.CONSENSUS_REQUIRED}, missing {short} more)"
                )
            if reasons:
                lines.append("  No action generated because: " + "; and ".join(reasons) + ".")
            else:
                lines.append(
                    f"  Signal is {r.action}. Score={r.composite_score:.1f}, "
                    f"consensus={r.direction_agreement}/5."
                )

        explanation = "\n".join(lines)

        # Cache it on the result object
        with self._lock:
            cached = self._last_result.get(ticker)
            if cached is not None and cached.timestamp == r.timestamp:
                object.__setattr__(cached, "_explanation", explanation)

        return explanation

    # ── convenience helpers ───────────────────────────────────────────────────

    def get_last_signal(self, ticker: str) -> Optional[TradeSignal]:
        """Return the cached TradeSignal for a ticker without re-evaluating."""
        with self._lock:
            return self._last_result.get(ticker.upper().strip())

    def clear_cache(self, ticker: Optional[str] = None):
        """Clear cached signals. Pass a ticker to clear just one, or None for all."""
        with self._lock:
            if ticker:
                self._last_result.pop(ticker.upper().strip(), None)
            else:
                self._last_result.clear()

    def summary_table(self) -> str:
        """
        Return a compact multi-line table of all cached tickers — handy for
        a single log.info() call at the end of a scan cycle.
        """
        with self._lock:
            results = list(self._last_result.values())
        if not results:
            return "SignalEngine: no signals evaluated yet."
        header = (
            f"{'TICKER':<8} {'SCORE':>6} {'ACTION':<14} "
            f"{'TECH':>6} {'MOM':>6} {'NEWS':>6} {'SOC':>6} {'MAC':>6} {'AGREE':>6}"
        )
        sep    = "─" * len(header)
        rows   = [header, sep]
        for r in sorted(results, key=lambda x: x.composite_score, reverse=True):
            rows.append(
                f"{r.ticker:<8} {r.composite_score:>6.1f} {r.action:<14} "
                f"{r.technical_score:>6.1f} {r.momentum_score:>6.1f} "
                f"{r.news_score:>6.1f} {r.social_score:>6.1f} "
                f"{r.macro_score:>6.1f} {r.direction_agreement:>6}/5"
            )
        return "\n".join(rows)


# ══════════════════════════════════════════════════════════════════════════════
#  Standalone self-test
# ══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import sys

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
        stream=sys.stdout,
    )

    engine = SignalEngine()

    test_cases = [
        # (label, ticker, TechnicalSignal, MomentumSignal, NewsSignal, SocialSignal, MacroSignal)
        (
            "Strong bullish convergence",
            "NVDA",
            TechnicalSignal(rsi=58, macd=0.85, macd_signal=0.40, vwap_dev=0.008, ema_cross="bullish"),
            MomentumSignal(breakout_pct=3.1, volume_ratio=2.2),
            NewsSignal(score=0.52, headline_count=9),
            SocialSignal(sentiment=0.38, momentum_spike=True, mentions_2h=22),
            MacroSignal(regime="RISK_ON"),
        ),
        (
            "Bearish with thin social data",
            "COIN",
            TechnicalSignal(rsi=34, macd=-0.60, macd_signal=-0.10, vwap_dev=-0.012, ema_cross="bearish"),
            MomentumSignal(breakout_pct=-2.8, volume_ratio=1.6),
            NewsSignal(score=-0.45, headline_count=7),
            SocialSignal(sentiment=-0.22, momentum_spike=False, mentions_2h=1),
            MacroSignal(regime="RISK_OFF"),
        ),
        (
            "Mixed / no consensus",
            "AAPL",
            TechnicalSignal(rsi=51, macd=0.05, macd_signal=0.04, vwap_dev=0.001, ema_cross="none"),
            MomentumSignal(breakout_pct=0.4, volume_ratio=1.1),
            NewsSignal(score=-0.18, headline_count=5),
            SocialSignal(sentiment=0.25, momentum_spike=False, mentions_2h=8),
            MacroSignal(regime="NEUTRAL"),
        ),
        (
            "Score in BUY zone but only 2 agree",
            "TSLA",
            TechnicalSignal(rsi=68, macd=1.20, macd_signal=0.50, vwap_dev=0.010, ema_cross="bullish"),
            MomentumSignal(breakout_pct=1.8, volume_ratio=1.3),
            NewsSignal(score=-0.30, headline_count=12),
            SocialSignal(sentiment=-0.40, momentum_spike=False, mentions_2h=30),
            MacroSignal(regime="RISK_OFF"),
        ),
    ]

    for label, ticker, tech, mom, news, soc, mac in test_cases:
        print(f"\n{'═' * 70}")
        print(f"  TEST: {label} ({ticker})")
        print(f"{'═' * 70}")
        result = engine.evaluate(ticker, tech, mom, news, soc, mac)
        print(f"\n{engine.explain_signal(ticker)}")

    print(f"\n{'═' * 70}")
    print("  SUMMARY TABLE")
    print(f"{'═' * 70}")
    print(engine.summary_table())
