"""
AlphaBot Auto-Updater
Checks for new versions and applies updates automatically from a remote URL.
Your config.json, trades, models, and logs are always preserved.
"""

import os
import sys
import json
import shutil
import zipfile
import logging
import urllib.request
import urllib.error
import tempfile
from datetime import datetime

logger = logging.getLogger("alphabot.updater")

# -- Update source -------------------------------------------------------------
# MANIFEST_URL points to a small JSON file that describes the latest release.
# UPDATE_URL is where the zip is downloaded from.
#
# To host your own updates:
#   1. Put AlphaBot_vX.Y.Z.zip somewhere public (GitHub releases, Dropbox, etc.)
#   2. Put a manifest.json next to it with the structure shown below
#   3. Set MANIFEST_URL to point at that manifest.json
#
# manifest.json format:
# {
#   "version": "1.3.1",
#   "notes": "Fixed timezone bug",
#   "url": "https://example.com/AlphaBot_v1.3.1.zip"
# }
#
MANIFEST_URL = "https://raw.githubusercontent.com/your-username/alphabot/main/manifest.json"

VERSION_FILE = "VERSION.json"
BACKUP_DIR   = "backups"

PROTECTED_FILES = {"config.json"}
PROTECTED_DIRS  = {"models", "trades", "logs", "venv", "backups"}


# -----------------------------------------------------------------------------
# Version helpers
# -----------------------------------------------------------------------------

def get_current_version():
    if os.path.exists(VERSION_FILE):
        try:
            with open(VERSION_FILE) as f:
                data = json.load(f)
            return data.get("version", "1.0.0"), data
        except Exception:
            pass
    return "1.0.0", {"version": "1.0.0", "date": "2024-01-01"}


def write_version(version, notes=""):
    data = {
        "version": version,
        "date": datetime.now().strftime("%Y-%m-%d"),
        "notes": notes,
        "updated_at": datetime.now().isoformat()
    }
    with open(VERSION_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _version_tuple(v):
    """Convert '1.3.0' -> (1, 3, 0) for comparison."""
    try:
        return tuple(int(x) for x in str(v).split("."))
    except Exception:
        return (0, 0, 0)


# -----------------------------------------------------------------------------
# Remote update check
# -----------------------------------------------------------------------------

def check_for_update(manifest_url=None):
    """
    Fetch the remote manifest and compare versions.
    Returns (update_available: bool, manifest: dict, message: str)
    """
    url = manifest_url or MANIFEST_URL

    # If URL still has placeholder, tell the user
    if "your-username" in url:
        return False, {}, (
            "No update URL configured.\n"
            "Edit MANIFEST_URL in core/updater.py to point at your hosted manifest.json."
        )

    try:
        logger.info(f"Checking for updates at {url}")
        req = urllib.request.Request(url, headers={"User-Agent": "AlphaBot-Updater/1.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            manifest = json.loads(resp.read().decode())

        remote_version = manifest.get("version", "0.0.0")
        current_version, _ = get_current_version()

        if _version_tuple(remote_version) > _version_tuple(current_version):
            msg = (f"Update available: v{current_version} -> v{remote_version}\n"
                   f"Notes: {manifest.get('notes', 'No notes')}")
            logger.info(msg)
            return True, manifest, msg
        else:
            msg = f"Already up to date (v{current_version})"
            logger.info(msg)
            return False, manifest, msg

    except urllib.error.URLError as e:
        msg = f"Could not reach update server: {e.reason}"
        logger.warning(msg)
        return False, {}, msg
    except Exception as e:
        msg = f"Update check failed: {e}"
        logger.warning(msg)
        return False, {}, msg


# -----------------------------------------------------------------------------
# Download + apply
# -----------------------------------------------------------------------------

def download_and_apply_update(manifest, progress_callback=None):
    """
    Download the zip from manifest['url'] and apply it.
    progress_callback(message: str) is called with status updates.
    Returns (success: bool, message: str)
    """
    url = manifest.get("url", "")
    if not url:
        return False, "Manifest has no download URL."

    def progress(msg):
        logger.info(msg)
        if progress_callback:
            progress_callback(msg)

    try:
        with tempfile.TemporaryDirectory() as tmpdir:
            zip_path = os.path.join(tmpdir, "update.zip")

            # Download
            progress(f"Downloading update from {url} ...")
            req = urllib.request.Request(url, headers={"User-Agent": "AlphaBot-Updater/1.0"})
            with urllib.request.urlopen(req, timeout=60) as resp:
                total = int(resp.headers.get("Content-Length", 0))
                downloaded = 0
                chunk = 8192
                with open(zip_path, "wb") as f:
                    while True:
                        data = resp.read(chunk)
                        if not data:
                            break
                        f.write(data)
                        downloaded += len(data)
                        if total:
                            pct = downloaded / total * 100
                            progress(f"Downloading... {pct:.0f}%")

            progress("Download complete. Applying update...")
            success, msg = apply_zip_update(
                zip_path,
                new_version=manifest.get("version", ""),
                notes=manifest.get("notes", "")
            )
            return success, msg

    except urllib.error.URLError as e:
        return False, f"Download failed: {e.reason}"
    except Exception as e:
        return False, f"Update failed: {e}"


# -----------------------------------------------------------------------------
# Apply local zip
# -----------------------------------------------------------------------------

def backup_current():
    """Create a backup of current installation before applying update."""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = os.path.join(BACKUP_DIR, f"backup_{timestamp}.zip")

    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk("."):
            dirs[:] = [d for d in dirs if d not in PROTECTED_DIRS and not d.startswith(".")]
            for file in files:
                filepath = os.path.join(root, file)
                arcname = os.path.relpath(filepath, ".")
                try:
                    zf.write(filepath, arcname)
                except Exception:
                    pass

    logger.info(f"Backup created: {backup_path}")
    return backup_path


def apply_zip_update(zip_path, new_version="", notes=""):
    """
    Apply an update from a local ZIP file.
    Preserves config.json, trade history, models, and logs.
    Returns (success, message)
    """
    if not os.path.exists(zip_path):
        return False, f"Update file not found: {zip_path}"

    try:
        logger.info("Creating backup before update...")
        backup_path = backup_current()

        with tempfile.TemporaryDirectory() as tmpdir:
            logger.info(f"Extracting update...")
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(tmpdir)

            # Handle zip with a single root folder inside
            entries = os.listdir(tmpdir)
            if len(entries) == 1 and os.path.isdir(os.path.join(tmpdir, entries[0])):
                src_root = os.path.join(tmpdir, entries[0])
            else:
                src_root = tmpdir

            updated = []
            skipped = []

            for root, dirs, files in os.walk(src_root):
                dirs[:] = [d for d in dirs if d not in PROTECTED_DIRS]
                for file in files:
                    src_path = os.path.join(root, file)
                    rel_path = os.path.relpath(src_path, src_root)

                    if rel_path in PROTECTED_FILES:
                        skipped.append(rel_path)
                        continue

                    parts = rel_path.replace("\\", "/").split("/")
                    if any(p in PROTECTED_DIRS for p in parts):
                        skipped.append(rel_path)
                        continue

                    dst_dir = os.path.dirname(rel_path)
                    if dst_dir:
                        os.makedirs(dst_dir, exist_ok=True)

                    shutil.copy2(src_path, rel_path)
                    updated.append(rel_path)

        if new_version:
            write_version(new_version, notes)

        msg = (f"Update applied successfully!\n"
               f"  Files updated: {len(updated)}\n"
               f"  Files preserved: {len(skipped)}\n"
               f"  Backup saved: {backup_path}\n"
               f"  New version: {new_version or 'unknown'}")
        logger.info(msg)
        return True, msg

    except Exception as e:
        msg = f"Update failed: {e}\nYour files are unchanged."
        logger.error(msg)
        return False, msg


# -----------------------------------------------------------------------------
# Restore
# -----------------------------------------------------------------------------

def restore_backup(backup_path=None):
    if backup_path is None:
        if not os.path.exists(BACKUP_DIR):
            return False, "No backups found"
        backups = sorted([
            os.path.join(BACKUP_DIR, f)
            for f in os.listdir(BACKUP_DIR)
            if f.endswith(".zip")
        ], reverse=True)
        if not backups:
            return False, "No backup files found"
        backup_path = backups[0]

    if not os.path.exists(backup_path):
        return False, f"Backup not found: {backup_path}"

    try:
        with zipfile.ZipFile(backup_path, "r") as zf:
            for member in zf.namelist():
                parts = member.replace("\\", "/").split("/")
                if any(p in PROTECTED_DIRS for p in parts):
                    continue
                if member in PROTECTED_FILES:
                    continue
                zf.extract(member, ".")
        return True, f"Restored from: {backup_path}"
    except Exception as e:
        return False, f"Restore failed: {e}"


def list_backups():
    if not os.path.exists(BACKUP_DIR):
        return []
    backups = []
    for f in sorted(os.listdir(BACKUP_DIR), reverse=True):
        if f.endswith(".zip"):
            path = os.path.join(BACKUP_DIR, f)
            size = os.path.getsize(path)
            backups.append({
                "file": f,
                "path": path,
                "size_kb": round(size / 1024, 1),
                "date": f.replace("backup_", "").replace(".zip", "")
            })
    return backups
