"""
MacroIntelligence - Macro regime detection for AlphaBot
Pulls Fed funds rate, CPI, unemployment from FRED, scrapes economic calendar,
and computes a RISK_ON / RISK_OFF / NEUTRAL regime score.

Trading signals are adjusted based on the macro regime:
  - RISK_OFF: position size reduced 30%, high-beta stocks avoided
  - RISK_ON : normal sizing, growth/high-beta preferred
  - NEUTRAL : normal sizing, no filtering

Refreshes every 6 hours in a background thread. Fully Windows-compatible.
No API keys required - uses FRED's free public JSON endpoint and free RSS calendars.
"""

import os
import json
import logging
import threading
import time
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta

logger = logging.getLogger("alphabot.macro")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
FRED_BASE = "https://api.stlouisfed.org/fred/series/observations"

# FRED series IDs
SERIES_FED_RATE    = "DFF"         # Daily Effective Federal Funds Rate
SERIES_CPI         = "CPIAUCSL"    # CPI All Urban Consumers (monthly)
SERIES_UNEMPLOYMENT = "UNRATE"     # Unemployment rate (monthly)

# FRED has a free no-key fredgraph.csv endpoint we use as fallback
FRED_CSV_BASE = "https://fred.stlouisfed.org/graph/fredgraph.csv"

# Free economic calendar RSS (Investing.com public feed)
ECON_CALENDAR_RSS = "https://www.investing.com/rss/news_285.rss"

# High-impact keywords we flag in the calendar
HIGH_IMPACT_KEYWORDS = [
    "fed", "fomc", "powell", "rate decision", "interest rate",
    "cpi", "inflation", "ppi", "pce",
    "nonfarm", "nfp", "payroll", "unemployment", "jobless",
    "gdp", "retail sales", "ism", "pmi",
]

# High-beta tickers avoided in RISK_OFF regimes
HIGH_BETA_SYMBOLS = {
    "TSLA", "NVDA", "AMD", "COIN", "PLTR", "RBLX", "ROKU", "SHOP", "SQ",
    "AFRM", "UPST", "SOFI", "RIVN", "LCID", "HOOD", "IONQ", "SOUN",
    "SMCI", "ARM", "MRNA", "BNTX", "RUN", "ENPH", "FSLR", "ARKK",
    "MARA", "RIOT", "MSTR", "GME", "AMC",
}

CACHE_FILE = "models/macro_cache.json"
REFRESH_INTERVAL_HOURS = 6
HTTP_TIMEOUT = 12


# ---------------------------------------------------------------------------
# MacroIntelligence
# ---------------------------------------------------------------------------
class MacroIntelligence:
    """
    Background macro regime detector.
    Usage:
        macro = MacroIntelligence(config)
        macro.start()  # starts background refresh thread
        ctx = macro.get_macro_context()
        sized = macro.adjust_position_size(base_shares=100, symbol="NVDA")
    """

    def __init__(self, config=None):
        self.config = config
        self._lock = threading.Lock()
        self._thread = None
        self._running = False

        # Cached state
        self.fed_rate = None
        self.fed_rate_prev = None
        self.cpi_latest = None
        self.cpi_prev = None
        self.cpi_yoy = None
        self.unemployment = None
        self.next_major_event = None     # {"name": str, "date": str}
        self.upcoming_events = []        # list of dicts
        self.regime = "NEUTRAL"          # RISK_ON / RISK_OFF / NEUTRAL
        self.market_bias = "neutral"     # bullish / bearish / neutral
        self.last_refresh = None

        os.makedirs("models", exist_ok=True)
        self._load_cache()

    # -----------------------------------------------------------------------
    # Persistence
    # -----------------------------------------------------------------------
    def _load_cache(self):
        if not os.path.exists(CACHE_FILE):
            return
        try:
            with open(CACHE_FILE, "r") as f:
                data = json.load(f)
            self.fed_rate         = data.get("fed_rate")
            self.fed_rate_prev    = data.get("fed_rate_prev")
            self.cpi_latest       = data.get("cpi_latest")
            self.cpi_prev         = data.get("cpi_prev")
            self.cpi_yoy          = data.get("cpi_yoy")
            self.unemployment     = data.get("unemployment")
            self.next_major_event = data.get("next_major_event")
            self.upcoming_events  = data.get("upcoming_events", [])
            self.regime           = data.get("regime", "NEUTRAL")
            self.market_bias      = data.get("market_bias", "neutral")
            ts = data.get("last_refresh")
            if ts:
                self.last_refresh = datetime.fromisoformat(ts)
            logger.info(f"Loaded macro cache (regime={self.regime}, last_refresh={ts})")
        except Exception as e:
            logger.warning(f"Could not load macro cache: {e}")

    def _save_cache(self):
        try:
            data = {
                "fed_rate":         self.fed_rate,
                "fed_rate_prev":    self.fed_rate_prev,
                "cpi_latest":       self.cpi_latest,
                "cpi_prev":         self.cpi_prev,
                "cpi_yoy":          self.cpi_yoy,
                "unemployment":     self.unemployment,
                "next_major_event": self.next_major_event,
                "upcoming_events":  self.upcoming_events,
                "regime":           self.regime,
                "market_bias":      self.market_bias,
                "last_refresh":     self.last_refresh.isoformat() if self.last_refresh else None,
            }
            with open(CACHE_FILE, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            logger.warning(f"Could not save macro cache: {e}")

    # -----------------------------------------------------------------------
    # HTTP helper
    # -----------------------------------------------------------------------
    def _http_get(self, url, timeout=HTTP_TIMEOUT):
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "AlphaBot-MacroIntel/1.0"}
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.read().decode("utf-8", errors="replace")
        except urllib.error.URLError as e:
            logger.warning(f"HTTP GET failed ({url}): {e.reason}")
        except Exception as e:
            logger.warning(f"HTTP GET error ({url}): {e}")
        return None

    # -----------------------------------------------------------------------
    # FRED data fetchers
    # -----------------------------------------------------------------------
    def _fetch_fred_series(self, series_id, limit=25):
        """
        Fetch a FRED series using the free fredgraph.csv endpoint (no API key).
        Returns list of (date_str, value_float) tuples, most recent last.
        """
        url = f"{FRED_CSV_BASE}?id={series_id}"
        csv_text = self._http_get(url)
        if not csv_text:
            return []

        observations = []
        try:
            lines = csv_text.strip().splitlines()
            # First line is header: "observation_date,SERIES_ID" or "DATE,SERIES_ID"
            for line in lines[1:]:
                parts = line.split(",")
                if len(parts) < 2:
                    continue
                date_str = parts[0].strip()
                val_str = parts[1].strip()
                if val_str in (".", "", "NA"):
                    continue
                try:
                    observations.append((date_str, float(val_str)))
                except ValueError:
                    continue
        except Exception as e:
            logger.warning(f"Failed parsing FRED CSV for {series_id}: {e}")
            return []

        return observations[-limit:] if observations else []

    def _update_fed_rate(self):
        obs = self._fetch_fred_series(SERIES_FED_RATE, limit=10)
        if not obs:
            logger.warning("Fed rate fetch failed - keeping cached value")
            return
        self.fed_rate_prev = self.fed_rate
        self.fed_rate = obs[-1][1]
        logger.info(f"Fed funds rate: {self.fed_rate:.2f}% (prev cached: {self.fed_rate_prev})")

    def _update_cpi(self):
        obs = self._fetch_fred_series(SERIES_CPI, limit=15)
        if not obs:
            logger.warning("CPI fetch failed - keeping cached value")
            return
        self.cpi_prev = self.cpi_latest
        self.cpi_latest = obs[-1][1]

        # Year-over-year CPI change (12 months back if available)
        if len(obs) >= 13:
            yoy = (obs[-1][1] - obs[-13][1]) / obs[-13][1] * 100
            self.cpi_yoy = round(yoy, 2)
        elif len(obs) >= 2:
            # fallback: month-over-month annualized
            mom = (obs[-1][1] - obs[-2][1]) / obs[-2][1] * 100
            self.cpi_yoy = round(mom * 12, 2)
        logger.info(f"CPI latest: {self.cpi_latest:.2f} | YoY: {self.cpi_yoy}%")

    def _update_unemployment(self):
        obs = self._fetch_fred_series(SERIES_UNEMPLOYMENT, limit=5)
        if not obs:
            logger.warning("Unemployment fetch failed - keeping cached value")
            return
        self.unemployment = obs[-1][1]
        logger.info(f"Unemployment rate: {self.unemployment:.1f}%")

    # -----------------------------------------------------------------------
    # Economic calendar
    # -----------------------------------------------------------------------
    def _update_calendar(self):
        """
        Pull an RSS feed of economic news and flag high-impact events
        in the next 7 days by keyword matching on title/description.
        """
        xml_text = self._http_get(ECON_CALENDAR_RSS)
        events = []

        if xml_text:
            try:
                root = ET.fromstring(xml_text)
                now = datetime.now()
                cutoff = now + timedelta(days=7)

                for item in root.iter("item"):
                    title = (item.findtext("title") or "").strip()
                    desc = (item.findtext("description") or "").strip()
                    pub_date_str = (item.findtext("pubDate") or "").strip()

                    if not title:
                        continue

                    blob = (title + " " + desc).lower()
                    if not any(kw in blob for kw in HIGH_IMPACT_KEYWORDS):
                        continue

                    # Parse RFC 822 date; fall back to "now" if parsing fails
                    event_dt = None
                    for fmt in ("%a, %d %b %Y %H:%M:%S %z",
                                "%a, %d %b %Y %H:%M:%S GMT",
                                "%a, %d %b %Y %H:%M:%S"):
                        try:
                            event_dt = datetime.strptime(pub_date_str, fmt)
                            if event_dt.tzinfo is not None:
                                event_dt = event_dt.replace(tzinfo=None)
                            break
                        except Exception:
                            pass

                    if event_dt is None:
                        event_dt = now

                    # Only keep events in the forward 7-day window (allow 1 day back)
                    if event_dt < now - timedelta(days=1) or event_dt > cutoff:
                        continue

                    events.append({
                        "name": title[:120],
                        "date": event_dt.strftime("%Y-%m-%d %H:%M"),
                        "_dt":  event_dt,
                    })
            except ET.ParseError as e:
                logger.warning(f"Could not parse economic calendar XML: {e}")
            except Exception as e:
                logger.warning(f"Calendar parse error: {e}")
        else:
            logger.warning("Economic calendar fetch failed - using cached events")

        if events:
            events.sort(key=lambda e: e["_dt"])
            next_event = events[0]
            self.next_major_event = {"name": next_event["name"], "date": next_event["date"]}
            # Strip internal _dt before caching
            self.upcoming_events = [
                {"name": e["name"], "date": e["date"]} for e in events[:10]
            ]
            logger.info(f"Calendar: {len(events)} high-impact events | next: {next_event['name']} @ {next_event['date']}")
        elif not self.next_major_event:
            self.next_major_event = {"name": "No major events detected", "date": ""}

    # -----------------------------------------------------------------------
    # Regime computation
    # -----------------------------------------------------------------------
    def _compute_regime(self):
        """
        Score macro regime on a -5..+5 axis using rate environment,
        CPI trend, and unemployment. Map to RISK_ON / RISK_OFF / NEUTRAL.
        """
        score = 0
        reasons = []

        # Fed funds rate: historically >5% is restrictive, <2% is accommodative
        if self.fed_rate is not None:
            if self.fed_rate >= 5.0:
                score -= 2
                reasons.append(f"fed rate restrictive ({self.fed_rate:.2f}%)")
            elif self.fed_rate >= 4.0:
                score -= 1
                reasons.append(f"fed rate elevated ({self.fed_rate:.2f}%)")
            elif self.fed_rate <= 2.0:
                score += 2
                reasons.append(f"fed rate accommodative ({self.fed_rate:.2f}%)")
            elif self.fed_rate <= 3.0:
                score += 1
                reasons.append(f"fed rate moderate ({self.fed_rate:.2f}%)")

        # CPI YoY: Fed target is 2%. Above 4% is hot, below 2.5% is cooling.
        if self.cpi_yoy is not None:
            if self.cpi_yoy >= 4.0:
                score -= 2
                reasons.append(f"CPI hot ({self.cpi_yoy}%)")
            elif self.cpi_yoy >= 3.0:
                score -= 1
                reasons.append(f"CPI elevated ({self.cpi_yoy}%)")
            elif self.cpi_yoy <= 2.5:
                score += 1
                reasons.append(f"CPI cooling ({self.cpi_yoy}%)")
            if self.cpi_yoy <= 2.0:
                score += 1
                reasons.append("CPI at/below Fed target")

        # Unemployment: rising above 5% is a warning sign
        if self.unemployment is not None:
            if self.unemployment >= 5.0:
                score -= 1
                reasons.append(f"unemployment elevated ({self.unemployment:.1f}%)")
            elif self.unemployment <= 4.0:
                score += 1
                reasons.append(f"unemployment strong ({self.unemployment:.1f}%)")

        # Map score to regime
        if score >= 2:
            self.regime = "RISK_ON"
            self.market_bias = "bullish"
        elif score <= -2:
            self.regime = "RISK_OFF"
            self.market_bias = "bearish"
        else:
            self.regime = "NEUTRAL"
            self.market_bias = "neutral"

        logger.info(f"Macro regime: {self.regime} (score={score}) | bias={self.market_bias}")
        if reasons:
            logger.info(f"  Drivers: {'; '.join(reasons)}")

    # -----------------------------------------------------------------------
    # Refresh orchestration
    # -----------------------------------------------------------------------
    def refresh(self):
        """Force a full refresh of all macro data."""
        with self._lock:
            logger.info("Refreshing macro intelligence data...")
            try:
                self._update_fed_rate()
            except Exception as e:
                logger.error(f"Fed rate update failed: {e}")
            try:
                self._update_cpi()
            except Exception as e:
                logger.error(f"CPI update failed: {e}")
            try:
                self._update_unemployment()
            except Exception as e:
                logger.error(f"Unemployment update failed: {e}")
            try:
                self._update_calendar()
            except Exception as e:
                logger.error(f"Calendar update failed: {e}")

            self._compute_regime()
            self.last_refresh = datetime.now()
            self._save_cache()
            logger.info("Macro refresh complete")

    def _needs_refresh(self):
        if self.last_refresh is None:
            return True
        hours = (datetime.now() - self.last_refresh).total_seconds() / 3600
        return hours >= REFRESH_INTERVAL_HOURS

    # -----------------------------------------------------------------------
    # Background thread
    # -----------------------------------------------------------------------
    def start(self):
        """Start background refresh thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._background_loop,
                                        daemon=True, name="MacroIntelligence")
        self._thread.start()
        logger.info(f"MacroIntelligence background thread started (refresh every {REFRESH_INTERVAL_HOURS}h)")

    def stop(self):
        self._running = False
        logger.info("MacroIntelligence background thread stopping")

    def _background_loop(self):
        # Initial refresh if cache is stale
        if self._needs_refresh():
            try:
                self.refresh()
            except Exception as e:
                logger.error(f"Initial macro refresh failed: {e}")

        # Then poll every 15 minutes to see if 6h has elapsed
        while self._running:
            try:
                if self._needs_refresh():
                    self.refresh()
            except Exception as e:
                logger.error(f"Background macro refresh error: {e}")
            # Sleep in 1s increments for fast shutdown
            for _ in range(15 * 60):
                if not self._running:
                    return
                time.sleep(1)

    # -----------------------------------------------------------------------
    # Public API
    # -----------------------------------------------------------------------
    def get_macro_context(self):
        """
        Return the current macro context as a plain dict. Safe to call
        from any thread - returns a snapshot.
        """
        with self._lock:
            return {
                "regime":           self.regime,
                "fed_rate":         self.fed_rate,
                "cpi_latest":       self.cpi_latest,
                "cpi_yoy":          self.cpi_yoy,
                "unemployment":     self.unemployment,
                "next_major_event": self.next_major_event or {"name": "unknown", "date": ""},
                "market_bias":      self.market_bias,
                "last_refresh":     self.last_refresh.isoformat() if self.last_refresh else None,
            }

    # -----------------------------------------------------------------------
    # Trading integration hooks
    # -----------------------------------------------------------------------
    def adjust_position_size(self, base_shares, symbol=None):
        """
        Adjust a computed position size based on current regime.
        - RISK_OFF: -30% size, and veto entirely for high-beta symbols
        - RISK_ON : no adjustment (caller may upsize elsewhere)
        - NEUTRAL : no adjustment
        Returns an integer share count; 0 means "do not trade".
        """
        if base_shares is None or base_shares <= 0:
            return 0

        regime = self.regime or "NEUTRAL"

        if regime == "RISK_OFF":
            if symbol and symbol.upper() in HIGH_BETA_SYMBOLS:
                logger.info(f"Macro veto: {symbol} blocked in RISK_OFF regime (high beta)")
                return 0
            adjusted = int(base_shares * 0.7)
            if adjusted < base_shares:
                logger.info(f"Macro adjust: {symbol or 'position'} {base_shares} -> {adjusted} (RISK_OFF -30%)")
            return max(0, adjusted)

        return int(base_shares)

    def should_trade_symbol(self, symbol):
        """
        Quick boolean check - returns False if the symbol should be avoided
        given the current macro regime.
        """
        if self.regime == "RISK_OFF" and symbol and symbol.upper() in HIGH_BETA_SYMBOLS:
            return False
        return True

    def get_confidence_adjustment(self):
        """
        Return an additive confidence threshold adjustment the caller can
        apply to the ML confidence_threshold:
          RISK_OFF -> +0.05 (be pickier)
          RISK_ON  -> -0.02 (slightly looser)
          NEUTRAL  ->  0.00
        """
        if self.regime == "RISK_OFF":
            return 0.05
        if self.regime == "RISK_ON":
            return -0.02
        return 0.0


# ---------------------------------------------------------------------------
# Standalone self-test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%H:%M:%S",
    )
    macro = MacroIntelligence()
    macro.refresh()
    ctx = macro.get_macro_context()
    print("\n=== MACRO CONTEXT ===")
    for k, v in ctx.items():
        print(f"  {k:<18} {v}")
    print("\n=== POSITION SIZE TESTS ===")
    for sym in ["AAPL", "TSLA", "SPY", "NVDA"]:
        adj = macro.adjust_position_size(100, sym)
        print(f"  {sym:<6} base=100 -> {adj}")
